import { Component } from '@angular/core';

import { Ng2SmartTableModule, LocalDataSource } from '../table';

@Component({
  templateUrl: 'teaching.component.html'
})
export class TeachingComponent {


}
