import { NgModule } from '@angular/core';
import { TabsModule } from 'ng2-bootstrap/tabs';
import { Ng2SmartTableModule } from '../table';




import { TeachingComponent } from './teaching.component';
import { TeachingRoutingModule } from './teaching-routing.module';

@NgModule({
  imports: [
    TeachingRoutingModule,
    Ng2SmartTableModule,
    TabsModule.forRoot()
  ],
  declarations: [ TeachingComponent ]
})
export class TeachingModule { }
