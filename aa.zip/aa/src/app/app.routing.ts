import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AuthGuard } from './authentication/auth-guard.service';
import { AuthenticationService } from './authentication/authentication.service';

// Layouts
import { FullLayoutComponent } from './layouts/full-layout.component';

// Login
import { AuthenticationComponent } from './authentication/authentication.component';

// Worker
import { WorkerComponent } from './worker/worker.component';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full',
  },
  {
    path: '',
    redirectTo: 'worker',
    pathMatch: 'full',
  },
  {
    path: '',
    component: FullLayoutComponent,
    canActivate: [AuthGuard],
    data: {
      title: 'Home'
    },
    children: [
      {
        path: 'dashboard',
        loadChildren: './analytics/analytics.module#AnalyticsModule'
      },
      {
        path: 'components',
        loadChildren: './components/components.module#ComponentsModule'
      },
      {
        path: 'widgets',
        loadChildren: './widgets/widgets.module#WidgetsModule'
      },
      // {
      //   path: 'charts',
      //   loadChildren: './chartjs/chartjs.module#ChartJSModule'
      // },

      {
        path: 'assembly-management',
        loadChildren: './assembly-management/assembly-management.module#AssemblyManagementModule'
      },
      {
        path: 'order-management',
        loadChildren: './order-management/order-management.module#OrderManagementModule'
      },
      {
        path: 'device-management',
        loadChildren: './device-management/device-management.module#DeviceManagementModule'
      },
      {
        path: 'device-management-global',
        loadChildren: './device-management-global/device-management-global.module#DeviceManagementGlobalModule'
      },
      {
        path: 'device-management-local',
        loadChildren: './device-management-local/device-management-local.module#DeviceManagementLocalModule'
      },
      {
        path: 'licence-and-updates',
        loadChildren: './licence-management/licence-management.module#LicenceManagementModule'
      },
      {
        path: 'user-management',
        loadChildren: './user-management/user-management.module#UserManagementModule'
      },
      {
        path: 'teaching',
        loadChildren: './teaching/teaching.module#TeachingModule'
      },
      {
        path: 'userprofile/:userId',
        loadChildren: './user-profile/user-profile.module#UserProfileModule'
      }
    ]
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: [AuthGuard, AuthenticationService]
})
export class AppRoutingModule { }
