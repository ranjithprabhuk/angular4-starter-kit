import { Component, ViewChild, Injectable } from '@angular/core';

import { Ng2SmartTableModule, LocalDataSource } from '../smart-table';
import { ModalDirective } from 'ng2-bootstrap/modal';
import { TabsetComponent } from 'ng2-bootstrap';
import { TranslateService, TranslationChangeEvent } from '@ngx-translate/core';
import { DeviceManagementGlobalConfig } from './device-management-global.config';
import { DeviceManagementGlobalService } from './device-management-global.service';
import { AuthenticationService } from '../authentication/authentication.service';

import { ToastrService } from 'ngx-toastr';
import { ToastConfig } from 'ngx-toastr';
import { AppConfig } from '../app.config';

const customConfig: ToastConfig = { enableHtml: true };
const customCloneOpt: ToastConfig = { timeOut: 0, positionClass: 'toast-bottom-left', tapToDismiss: false, extendedTimeOut: 0 };
@Injectable()
@Component({
  templateUrl: 'device-management-global.component.html',
  styleUrls: ['./device-management-global.component.css'],
  providers: [DeviceManagementGlobalService]
})

export class DeviceManagementGlobalComponent {
  @ViewChild('BoxProjectionAreaModal') public BoxProjectionAreaModal: ModalDirective;
  @ViewChild('BRHandTrackingModal') public BRHandTrackingModal: ModalDirective;
  @ViewChild('RestoreModal') public RestoreModal: ModalDirective;
  @ViewChild('BackupModal') public BackupModal: ModalDirective;
  @ViewChild('CloneModal') public CloneModal: ModalDirective;
  @ViewChild('activeAssistDeleteModal') public activeAssistDeleteModal: ModalDirective;
  @ViewChild('materialDeleteModal') public materialDeleteModal: ModalDirective;
  @ViewChild('DeviceTypeDeleteModal') public DeviceTypeDeleteModal: ModalDirective;
  @ViewChild('boxTypeDeleteModal') public boxTypeDeleteModal: ModalDirective;
  @ViewChild('boxesRailsDeleteModal') public boxesRailsDeleteModal: ModalDirective;
  public selectedRowBoxesRails: any;
  constructor(private deviceManagementService: DeviceManagementGlobalService, private translate: TranslateService, private notificationService: ToastrService,private authService: AuthenticationService) {

    this.activeAssists = new LocalDataSource();
    this.boxesAndRails = new LocalDataSource();
    this.boxTypes = new LocalDataSource();
    this.material = new LocalDataSource;
    this.deviceType = new LocalDataSource;

    this.translate.onLangChange.subscribe((event: TranslationChangeEvent) => {
      this.doTranslate();
    });
  }
  public deviceManagementGlobalConfig = new DeviceManagementGlobalConfig(this.translate,this.authService);

  // ActiveAssistID DropDown
  public selectedActiveAssistId: String;
  public activeAssistIdList: Array<String>;


  // Clone/Restore/Backup
  public cloneIdSource:String;
  public restoreIdSource:String;
  public backupIdSource:String;

  public activeAssistCurrentPageForDelete:number;
  public deviceConfigCurrentPageForDelete:number;
  public materialCurrentPageForDelete:number;
  public materialCurrentPageForUpdate:number;
  public boxTypeCurrentPageForDelete:number; 
  public boxRailsCurrentPageForDelete:number;

  public show_box_projection_text: any;
  public show_handtracking_coordinates: any;
  public show_projection_text: any;

  public selectedTab: String = 'DEVICE_MANAGEMENT_GLOBAL.ACTIVE_ASSISTS';

  public settingsActiveAssists: any = this.deviceManagementGlobalConfig.ActiveAssistsSettings;
  public settingsMaterial: any = this.deviceManagementGlobalConfig.MaterialSettings;
  public settingsBoxTypes: any = this.deviceManagementGlobalConfig.BoxTypesSettings;
  public settingsBoxRails: any = this.deviceManagementGlobalConfig.BoxRailsSettings;
  public settingsDeviceConfig: any = this.deviceManagementGlobalConfig.DeviceConfigSettings;

  //Active Assist tab dropdown vars
  public supervisorList: any;

  //Activeassist ID dropdown in device config tab
  public activeAssistDeviceIdList: any;
  public DeviceTypeList: any;

  //Boxes and Rails Dropdown vars
  public activeAssistListBR: any;
  public materialListBR: any;
  public boxTypeListBR: any;

  public displayAADropdown: any;
  public displayPagination: any;
  // add a property to the component
  public activeAssists: LocalDataSource;
  public boxesAndRails: LocalDataSource;
  public boxTypes: LocalDataSource;
  public material: LocalDataSource;
  public deviceType: LocalDataSource;
  public maxSize = new AppConfig().maxSize;

  public showBoxProjectionAreaModal(): any {
    this.BoxProjectionAreaModal.show();
  }
  public showBRHandTrackingModalModal(): any {
    this.BRHandTrackingModal.show();
  }
  public onCellClickBoxesRails(event: any): void {
    console.log("checking event>>", event);
    if (event.column.id == "boxprojectionAreaDTO") {
      this.showBoxProjectionAreaModal();
    }
    if (event.column.id == "handtrackingCoordinatesDTO") {
      this.showBRHandTrackingModalModal();
    }
  };

  supervisorListAAID: Array<any> = [
    { value: '', title: '' }
  ];
  aaidListDC: Array<any> = [
    { value: '', title: '' }
  ];
  deviceTypeListDC: Array<any> = [
    { value: '', title: '' }
  ];
  aaidListBR: Array<any> = [
    { value: '', title: '', id: '' }
  ];
  materialDListBR: Array<any> = [
    { value: '', title: '', id: '' }
  ];
  boxTypesDListBR: Array<any> = [
    { value: '', title: '', id: '', boxheightOutside: '', boxlengthOutside: '', boxwidthOutside: '' }
  ];
  doTranslate() {
    this.deviceManagementGlobalConfig.updateSettings(this.supervisorListAAID, this.aaidListDC, this.deviceTypeListDC, this.aaidListBR, this.materialListBR, this.boxTypeListBR);
    //this.material.refresh();    
  }


  // Active Assist Tab Buttons
  public onButtonClick(event): void {
    let columnTitle = event.getColumn().title;

    switch (columnTitle) {
      case "Clone":
        this.CloneModal.show();
        this.cloneIdSource = event.row.data.activeAssistId;
        // to spot ActiveAssistID
        console.log(event.row.data.activeAssistId);
        break;
      case "Restore":
        this.restoreIdSource = event.row.data.activeAssistId;
        this.RestoreActiveAssistId(this.restoreIdSource);
        break;
      case "Backup":
        this.backupIdSource = event.row.data.activeAssistId;
        this.backupActiveAssistId(this.restoreIdSource);
        break;
    }
  };

  //  Clone an Active Assist to its destination ActiveAssist 
  public updateActiveAssistIdClone(): void {
    this.CloneModal.hide();
    let cloneActiveAssistIdDest = this.selectedActiveAssistId;
    let cloneActiveAssistIdSource = this.cloneIdSource;
    console.log("clone source", cloneActiveAssistIdSource);
    let data = {
      "activeAssistIDOrigin": cloneActiveAssistIdSource,
      "activeAssistIDDestination": cloneActiveAssistIdDest,
    }
    console.log("idsource & dest>>", data);

    this.notificationService.warning("Cloning in Progress...", "", customCloneOpt);
    this.deviceManagementService.saveActiveAssistIdClone(data).then(res => {
      this.notificationService.clear();
      this.notificationService.success("Cloned Successfully!");
      console.log("res", res);
    });
  }



  // to get all active assist ID - Clone dropdown
  public getAllActiveAssistID(): void {
    this.deviceManagementService.getAllActiveAssistIDData().then(res => {
      // list of active asssit id
      this.activeAssistIdList = res;
    });
  };


  //to Restore an Active Assist ID 
  public RestoreActiveAssistId(id): void {

    this.deviceManagementService.restoreActiveAssist(this.restoreIdSource).then(res => {
      this.notificationService.warning(" Successfully restored ");
      //   this.activeAssists.load(res);
    }).catch(err => { console.log("Error: ", err); });
    // this.assignOrders.reset();
    //this._getOrdersToAssign();
    //to close the modal on click of cancel
  }
  //Backup an active assist ID
  public backupActiveAssistId(id): void {
    this.deviceManagementService.backupActiveAssist(this.backupIdSource).then(res => {
      this.notificationService.warning("Backup is Successfull ");
      //   this.activeAssists.load(res);
    }).catch(err => { console.log("Error: ", err); });
  }

  //Active Assist Tab Data
  /**
  * Active Assist Table - CRUD and CLONE OPERATIONS
  * getActiveassist() - to get the list of Activeassist
  * createActiveAssist() - to save/create an activeassist
  **/


  //  to get the list of Activeassist
  public getActiveassist(pagination): void {
    let _pagination = pagination || this.settingsActiveAssists.serverSidePagination;
    console.log("count aa table data", this.activeAssists.count());
    console.log("aa pagination page", _pagination.page);
    if (this.activeAssists.count() == 0 || _pagination.page != this.settingsActiveAssists.serverSidePagination.page) {
      this.deviceManagementService.getActiveassistData(_pagination).then(res => {
        this.settingsActiveAssists.serverSidePagination.totalItems = res.size;
        console.log("pagination activeassist: ", pagination);
        this.activeAssists.load(res.content);
        if (!this.activeAssists.count()) {
          this.deviceManagementService.getActiveassistData().then(res => {
            this.activeAssists.load(res);
          });
        }
      }).catch(err => { console.log("Error: ", err); });
    }
  };
  //Pagination for Device Config tab
  public pageChangedActiveAssist(pagination): void {
    this.activeAssistCurrentPageForDelete = pagination.page;
    this.getActiveassist(pagination);
    console.log("pagination activeassist: ", pagination);
  };



    // to create an activeassist entry
  public createActiveAssist(row: any): void {
    console.log("new row created: ", row.newData);
    let activeAssistTable = row.newData;
    let _activeAssistTable = {
      "activeAssistId": activeAssistTable["activeAssistId"],
      "ip": activeAssistTable["ip"],
      "company": activeAssistTable["company"],
      "plant": activeAssistTable["plant"],
      "department": activeAssistTable["department"],
      "releaseVersion": activeAssistTable["releaseVersion"],
      "line": activeAssistTable["line"],
      "supervisor": activeAssistTable["supervisor"],
      "portNumber": activeAssistTable["portNumber"],
      "restoreConfigFiles": activeAssistTable["restoreConfigFiles"],
      "backupConfigFiles": activeAssistTable["backupConfigFiles"],
      "cloneActiveAssist": activeAssistTable["cloneActiveAssist"],
    }
    //  if (_activeAssistTable.ip == "" && _activeAssistTable.activeAssistId == "") 
    //     this.notificationService.warning("Kindly fill the mandatory fields -  AA ID & IP Address");
    let flag_AA = false;
     for (let col in _activeAssistTable) {
        if(col=="ip")
        {
            if(_activeAssistTable[col]=="")
            {
              flag_AA =true;
              this.notificationService.warning("Kindly fill the IP Address");
            }
            else
            {
                let checkIPFormat=new RegExp("^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$");
                let correctIP=checkIPFormat.test(_activeAssistTable[col]);
                console.log("ip val",_activeAssistTable[col]);
                //console.log("value of checkIPFormat",checkIPFormat);
                if(!correctIP)
                {
                    flag_AA=true;
                    this.notificationService.warning("Kindly give a valid IP address");
                }
            }
        }
        if(col=="activeAssistId")
        {
             if(_activeAssistTable[col]=="")
              {
                flag_AA =true;
                this.notificationService.warning("Kindly fill the AA ID");
              }
        }
        if(col=="line")
        {
             if(_activeAssistTable[col]=="")
              {
                  _activeAssistTable[col]=null;
              }
        }
        if(col=="portNumber")
        {
            let portnolength=_activeAssistTable[col].toString().length; 
            console.log("port number",portnolength);
             console.log("port number",_activeAssistTable[col]);
            if(_activeAssistTable[col]=="")
            {
               flag_AA=true;
               this.notificationService.warning("Kindly fill the Port Number");
            }
            if(_activeAssistTable[col]>65535)
             {
                    flag_AA=true;
                    this.notificationService.warning("Kindly fill Port Number in the range 0-65535");
             }
        }
     }
     if (!flag_AA) {
      this.deviceManagementService.saveActiveAssist(_activeAssistTable).then(res => {
        //add the data to the table
        row.confirm.resolve(res);
        this.settingsActiveAssists.serverSidePagination.page=1;
        this.activeAssists.empty();
        this.getActiveassist({ itemsPerPage: 10,page: 1});
      }).catch(err => { console.log("Error: ", err); });
    }
  };


  public copyActiveAssist(row: any): void {
    //construct the data to post it to the back end
    // let selecteActiveAssistData = row.newData;
    //console.log("copy", selecteActiveAssistData);
    row.newData.id = 0;
    this.deviceManagementService.saveActiveAssist(row.newData).then(res => {
      //add the data to the table
      row.confirm.resolve(res);
    }).catch(err => { console.log("Error: ", err); });
  };


 // to update/edit an activeassist entry
  public updateActiveAssist(row: any): void {
    //check all the required data are added
    //call the api and update the data
    //row.newData.id=0;
   // let selecteActiveAssistData = row.newData;
    let activeAssistTable = row.newData;
    console.log("edited row",activeAssistTable);
    let flag_AA = false;
     for (let col in activeAssistTable) {
        if(col=="ip")
        {
            if(activeAssistTable[col]=="")
            {
              flag_AA =true;
              this.notificationService.warning("Kindly fill the IP Address");
            }
           else
            {
                let checkIPFormat=new RegExp("^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$");
                let correctIP=checkIPFormat.test(activeAssistTable[col]);
                console.log("ip val",activeAssistTable[col]);
                //console.log("value of checkIPFormat",checkIPFormat);
                if(!correctIP)
                {
                    flag_AA=true;
                    this.notificationService.warning("Kindly give a valid IP address");
                }
            }
        }
        if(col=="activeAssistId")
        {
             if(activeAssistTable[col]=="")
              {
                flag_AA =true;
                this.notificationService.warning("Kindly fill the AA ID");
              }
        }
        if(col=="portNumber")
        {
            let portnolength=activeAssistTable[col].toString().length; 
            console.log("port number",portnolength);
             console.log("port number",activeAssistTable[col]);
            if(activeAssistTable[col]=="")
            {
               flag_AA=true;
               this.notificationService.warning("Kindly fill the Port Number");
            }
            if(activeAssistTable[col]>65535)
             {
                    flag_AA=true;
                    this.notificationService.warning("Kindly fill Port Number in the range 0-65535");
             }
        }
     }
     if (!flag_AA) {
          this.deviceManagementService.updateActiveAssistData(activeAssistTable).then(res => {
            //update the data to the table
            row.confirm.resolve(res);
          }).catch(err => { console.log("Error: ", err); });
    }
    
  };


  // to delete an activeassist entry
  public deleteActiveAssist(row: any): void {
    if (row && row.data) {
      this.activeAssistDeleteModal.hide();
      //call the assembly service api and pass the product type id to delete the data
      console.log(row.data.activeAssistId, "row.data.activeAssistId aadelete")
      this.deviceManagementService.deleteActiveAssist(row.data.activeAssistId).then(res => {
        //delete the data from the table
        row.confirm.resolve();
        this.activeAssists.empty();
        this.getActiveassist({itemsPerPage:10,page:this.activeAssistCurrentPageForDelete});
        //hide the delete modal pop up
      }).catch(err => { console.log("Error: ", err); });
    }
  };

  public loadListAASupervisor(): void {
    this.deviceManagementService.getSupervisor().then(res => {
      this.supervisorList = res;
      this.supervisorListAAID = [];
      for (let i = 0; i < this.supervisorList.length; i++) {
        this.supervisorListAAID.push({ value: this.supervisorList[i].username, title: this.supervisorList[i].username })
      }
      console.log("supervisor list", this.supervisorListAAID)
      this.deviceManagementGlobalConfig.updateSettings(this.supervisorListAAID, this.aaidListDC, this.deviceTypeListDC, this.aaidListBR, this.materialDListBR, this.boxTypesDListBR);
      // this.settingsActiveAssists.columns.supervisor.editor.config.list=this.supervisorList.map((list)=>{  
      //   return { value: list.username,title:list.username};
      // });
      // this.settingsActiveAssists=Object.assign({},this.settingsActiveAssists);
    }).catch(err => { console.log("Error: ", err); });
  }
  //Material Tab Data

  /**
  * Material Table - CRUD OPERATIONS
  * getMaterial() - to get the list of Material
  * createMaterial() - to save a new Material
  * copyMaterial() - to copy a material entry
  * updateMaterial() - to copy a material entry
 
  **/
  /**
   * Material:
      Material Id – material number, mandatory
      Material Name
      Description
      Create Date – timestamp, disabled in Frontend
   */

  //  to get the list of Activeassist - works
  public getMaterial(pagination): void {
    let _pagination = pagination || this.settingsMaterial.serverSidePagination;
    //call the device management service to get the data
    console.log("count material table data", this.material.count());
    console.log("pagination page", _pagination.page);
    if (this.material.count() == 0 || _pagination.page != this.settingsMaterial.serverSidePagination.page) {
      this.deviceManagementService.getMaterialData(_pagination).then(res => {
        this.settingsMaterial.serverSidePagination.totalItems = res.size;
        this.material.load(res.content);
        if (!this.material.count()) {
          this.deviceManagementService.getMaterialData().then(res => {
            this.material.load(res);
          });
        }
      }).catch(err => { console.log("Error: ", err); });
    }
  };
  public pageChangedMaterial(pagination): void {
    this.materialCurrentPageForDelete=pagination.page;
    this.materialCurrentPageForUpdate=pagination.page;
    this.getMaterial(pagination);
  };



  // to create an Material entry - works
  public createMaterial(row: any): void {
    console.log("new row created: ", row.newData);
    let activeAssistTable = row.newData;
    let _materialTable = {
      "materialNumber": activeAssistTable["materialNumber"],
      "materialName": activeAssistTable["materialName"],
      "description": activeAssistTable["description"],
      "timestamp": activeAssistTable["timestamp"],
    }
    if (_materialTable.materialNumber == "") {
      this.notificationService.warning("Kindly fill the Material Number");
    }
    else {
      this.deviceManagementService.saveMaterial(_materialTable).then(res => {
        row.confirm.resolve(res);
        this.settingsMaterial.serverSidePagination.page = 1;
        this.material.empty();
        this.getMaterial({ itemsPerPage: 10, page: 1 });
      }).catch(err => { console.log("Error: ", err); });
    }
  };


  //to copy a material entry - works
  public copyMaterial(row: any): void {
    // let selecteMaterialData = row.newData;
    // let _newMaterialData = {
    //   "materialNumber": selecteMaterialData["materialNumber"],
    //   "materialName": selecteMaterialData["materialName"],
    //   "description": selecteMaterialData["description"],
    //   "timestamp": selecteMaterialData["timestamp"],
    // }
    // console.log("copy orders", _newMaterialData);
    row.newData.id = 0;
    this.deviceManagementService.saveMaterial(row.newData).then(res => {
      row.confirm.resolve(res);
      // this.getMaterial({ itemsPerPage: 10,page: 1});
    }).catch(err => { console.log("Error: ", err); });
  };


  // to update/edit an material entry
  public updateMaterial(row: any): void {
     let material = row.newData;
     console.log("update material",material);
      let _materialTable = {
        "id":material["id"],
        "materialNumber": material["materialNumber"],
        "materialName": material["materialName"],
        "description": material["description"],
        "timestamp": material["timestamp"],
      }
      if (_materialTable.materialNumber == "") {
        this.notificationService.warning("Kindly fill the Material ID");
      }
      else {
          this.deviceManagementService.updateMaterialData(row.newData).then(res => {
            row.confirm.resolve(res);
             this.getMaterial({ itemsPerPage: 10, page: this.materialCurrentPageForUpdate });
          }).catch(err => { console.log("Error: ", err); });
      }
  };


  public deleteMaterial(row: any): void {
    if (row && row.data) {
      //hide the delete modal pop up
      this.materialDeleteModal.hide();
      //call the material service api and pass the id to delete the data
      this.deviceManagementService.deleteMaterial(row.data.id).then(res => {
        //delete the data from the table
        row.confirm.resolve();
        this.material.empty();
        this.getMaterial({ itemsPerPage: 10, page: this.materialCurrentPageForDelete });
      }).catch(err => { console.log("Error: ", err); });
    }
  };


  /** 
     * Box Types Table
     * getBoxTypes()-to get the list of Box Types
     * createBoxTypes($event)-creates a single entry of a new Box Type
     * copyBoxTypes($event)-copies a single record of Box Type 
     * updateBoxType($event)-updates existing record of a Box Type
     * deleteBoxType($event)-deletes an existing record of a Box Type
     * **/
  /**
   *  Every name has to be unique, there cant be two boxes with the same name
   *  Unit of dimensions has to be millimetre.
   */
  /**
   * 
      Box Types:
      Box Type Name – mandatory
      Length – mandatory
      Width – mandatory
      Height – mandatory
      Create Date – timestamp, disabled in Frontend
   */
  public getBoxTypes(pagination): void {
    let _pagination = pagination || this.settingsBoxTypes.serverSidePagination;
    console.log("count box types table data", this.boxTypes.count());
    console.log("pagination page", _pagination.page);
    if (this.boxTypes.count() == 0 || _pagination.page != this.settingsBoxTypes.serverSidePagination.page) {
      this.deviceManagementService.getBoxTypes(_pagination).then(res => {
        this.settingsBoxTypes.serverSidePagination.totalItems = res.size;
        this.boxTypes.load(res.content);
        if (!this.boxTypes.count()) {
          this.deviceManagementService.getBoxTypes().then(res => {
            this.boxTypes.load(res);
          });
        }
      }).catch(err => { console.log("Error: ", err); });
    }
  };

  public pageChangedBoxTypes(pagination): void {
    this.boxTypeCurrentPageForDelete = pagination.page;
    this.getBoxTypes(pagination);
  };

  public createBoxTypes(row: any): void {
    console.log("entered data", row.newData);
    console.log("row during create", row);
    let boxTypeFlag = this.boxTypeValidations(row.newData);
    console.log("box type flag", boxTypeFlag);
    if (boxTypeFlag) {
      row.newData.id = 0;
      this.deviceManagementService.saveBoxType(row.newData).then(res => {
        row.confirm.resolve(res);
        this.settingsBoxTypes.serverSidePagination.page = 1;
        this.boxTypes.empty();
        this.getBoxTypes({ itemsPerPage: 10, page: 1 });
      }).catch(err => { console.log("Error: ", err); });
    }
  };
  public boxTypeValidations(rowObject: any): boolean {
    let val = true;
    console.log("inside method data", rowObject);
    if (rowObject["boxType"] == "" && rowObject["heightOutside"] == "" && rowObject["lengthOutside"] == "" && rowObject["widthOutside"] == "") {
      val = false;
      this.notificationService.warning("Kindly fill the -</br>1)Box Type Name</br>2)Length</br>3)Width</br>4)Height", "", customConfig);
    }
    else {
      for (let col in rowObject) {
        switch (col) {
          case "boxType":
            if (rowObject[col] == "") {
              this.notificationService.warning("Kindly fill the Box Type Name");
              val = false;
            }

            break;
          case "heightOutside":
            // if(rowObject[col]=="")
            // {
            //     this.notificationService.warning("Kindly fill the Height");
            //     val=false;
            // }
            if (rowObject[col] <= 0) {
              console.log("value height outside", rowObject[col]);
              this.notificationService.warning("Kindly fill the Height greater than 0");
              val = false;
            }
            break;
          case "lengthOutside":
            // if(rowObject[col]=="")
            //   {
            //       this.notificationService.warning("Kindly fill the Length");
            //       val=false;
            //   }
            if (rowObject[col] <= 0) {
              this.notificationService.warning("Kindly fill the Length greater than 0");
              val = false;
            }
            break;
          case "widthOutside":
            // if(rowObject[col]=="")
            //   {
            //         this.notificationService.warning("Kindly fill the Width");
            //         val=false;
            //   }
            if (rowObject[col] <= 0) {
              this.notificationService.warning("Kindly fill the Width greater than 0");
              val = false;
            }
            break;
        }
      }
    }

    return val;
  }
  public copyBoxTypes(row: any): void {
    console.log("copy box types", row.newData);
    this.deviceManagementService.saveBoxType(row.newData).then(res => {
      row.confirm.resolve(res);
    }).catch(err => { console.log("Error: ", err); });
  };
  public updateBoxType(row: any): void {
    let boxTypeFlag = this.boxTypeValidations(row.newData);
    if (boxTypeFlag) {
      this.deviceManagementService.updateBoxType(row.newData).then(res => {
        row.confirm.resolve(res);
      }).catch(err => { console.log("Error: ", err); });
    }
  };
  public deleteBoxType(row: any): void {
    if (row && row.data) {
      this.boxTypeDeleteModal.hide();
      this.deviceManagementService.deleteBoxType(row.data.id).then(res => {
        row.confirm.resolve();
        this.boxTypes.empty();
        this.getBoxTypes({ itemsPerPage: 10, page: this.boxTypeCurrentPageForDelete });
      }).catch(err => { console.log("Error: ", err); });
    }
  };
  /** 
   * Box & Rails Table
   * getBoxesRails()-to get the list of Boxes & Rails 
   * createBoxesRails($event)-creates a single entry of a new Boxes & Rails
   * copyBoxesRails($event)-copies a single record of Boxes & Rails
   * updateBoxesRails($event)-updates existing record of a particular Boxes & Rails
   * deleteBoxType($event)-deletes an existing record of a particular Boxes & Rails
   * **/
  /**
   * AA ID - activeassistName
   * Material - materialName
   * Box Type - boxtype
   * Box Name - 
   * Box Tracking Mode - boxTrackingmode
   * Pos Nr - position
   * Box Projection Area - boxprojectionAreaDTO
   * Hand Tracking Coordinates - handtrackingCoordinatesDTO
   */
  /**
   * 
   * Boxes & Rails:validations
   * AA ID – mandatory, ActiveAssistID dropdown list
   * Material – mandatory, material drowpdown list
   * Tracking Mode – enum (virtual box, Pick2Light) dropdown list
   * Pos Nr – mandatory if Pick2Light selected
   * Box Projection Area – mandatory if virtual box selected
   * Hand Tracking Coordinates - mandatory if virtual box selected
   */

  public callGetAPIBR(newValue): void {
    this.selectedActiveAssistId = newValue;
    console.log("selected aa:", newValue);
    if (newValue == "all") {
      console.log("selected aa:", this.selectedActiveAssistId.toString());
      this.getBoxesRails({ itemsPerPage: 10, page: 1 });
      this.displayPagination = "show-pagination";
      console.log("serverside pagination", this.settingsBoxRails.serverSidePagination);
    }
    else {
      this.getBoxesRailsWithAAID(this.selectedActiveAssistId);
      this.displayPagination = "hide-pagination";
      console.log("serverside pagination", this.settingsBoxRails.serverSidePagination);
    }
  };
  public getBoxesRailsWithAAID(aaid): void {
    this.deviceManagementService.getBoxesRailsAAID(aaid).then(res => {
      console.log("get drpd res", res);
      let parsedData = res;

      for (let i = 0; i < res.length; i++) {
        if (parsedData[i]["boxprojectionAreaDTO"] != null) {
          parsedData[i]["boxprojectionAreaDTO"] = "x=" + res[i]["boxprojectionAreaDTO"]["x"] + "," + "y=" + res[i]["boxprojectionAreaDTO"]["y"] + "," + "z=" + res[i]["boxprojectionAreaDTO"]["z"] + "," + "width=" + res[i]["boxprojectionAreaDTO"]["width"] + "," + "height=" + res[i]["boxprojectionAreaDTO"]["height"];
        }
        if (parsedData[i]["handtrackingCoordinatesDTO"] != null) {
          parsedData[i]["handtrackingCoordinatesDTO"] = "x=" + res[i]["handtrackingCoordinatesDTO"]["x"] + "," + "y=" + res[i]["handtrackingCoordinatesDTO"]["y"] + "," + "z=" + res[i]["handtrackingCoordinatesDTO"]["z"];
        }
      }

      console.log("get parsed res", parsedData);
      this.boxesAndRails.load(parsedData);
    }).catch(err => { console.log("Error: ", err); });
  };


  public getBoxesRails(pagination): void {
    this.displayPagination = "show-pagination";
    let _pagination = pagination || this.settingsBoxRails.serverSidePagination;
    console.log("count box rails table data", this.boxesAndRails.count());
    console.log("pagination page", _pagination.page);
    if (this.boxesAndRails.count() == 0 || _pagination.page != this.settingsBoxRails.serverSidePagination.page) {
      this.deviceManagementService.getBoxesRails(_pagination).then(res => {
        console.log("res BR", res)
        this.settingsBoxRails.serverSidePagination.totalItems = res.size;
        this.boxesAndRails.load(res.content);
        if (!this.boxesAndRails.count()) {
          this.deviceManagementService.getBoxesRails().then(res => {
            this.boxesAndRails.load(res);
          });
        }
        console.log("get box types", res);
      }).catch(err => { console.log("Error: ", err); });
    }
  };
  public pageChangedBoxRails(pagination): void {
    this.boxRailsCurrentPageForDelete = pagination.page;
    this.getBoxesRails(pagination);
    console.log("pagination br", pagination);
  };
  public createBoxesRails(row: any): void {
    console.log("entered data br", row.newData);
    console.log("row during create br", row);
    let enteredData = row.newData;
    let aaidList = this.settingsBoxRails.columns.activeassistName.editor.config.list;
    let boxtypeList = this.settingsBoxRails.columns.boxtype.editor.config.list;
    let materialList = this.settingsBoxRails.columns.materialName.editor.config.list;

    let aaidID, boxTypeID, materialID;
    let bBoxheightOutside, bBoxlengthOutside, bBoxwidthOutside;
    console.log("boxtype list", boxtypeList);
    for (let i = 0; i < aaidList.length; i++) {
      if (enteredData["activeassistName"] == aaidList[i].title) {
        aaidID = aaidList[i].id;
      }
    }
    for (let i = 0; i < boxtypeList.length; i++) {
      if (enteredData["boxtype"] == boxtypeList[i].title) {
        boxTypeID = boxtypeList[i].id;
        bBoxheightOutside = boxtypeList[i].boxheightOutside;
        bBoxlengthOutside = boxtypeList[i].boxlengthOutside;
        bBoxwidthOutside = boxtypeList[i].boxwidthOutside;
      }
    }
    for (let i = 0; i < materialList.length; i++) {
      if (enteredData["materialName"] == materialList[i].title) {
        materialID = materialList[i].id;
      }
    }

    console.log("aaid list", aaidList);

    console.log("material list", materialList);
    let newDTOBR = {
      "activeassistName": enteredData["activeassistName"],
      "activeassistId": aaidID,
      "boxName": enteredData["boxName"],
      "boxTrackingmode": enteredData["boxTrackingmode"],
      "boxprojectionAreaDTO": enteredData["boxprojectionAreaDTO"],
      "boxtype": enteredData["boxtype"],
      "boxtypeId": boxTypeID,
      "handtrackingCoordinatesDTO": enteredData["handtrackingCoordinatesDTO"],
      "ioportName": enteredData["ioportName"],
      "materialName": enteredData["materialName"],
      "materialId": materialID,
      "boxheightOutside": bBoxheightOutside,
      "boxlengthOutside": bBoxlengthOutside,
      "boxwidthOutside": bBoxwidthOutside
    }

    console.log("new dto sent", newDTOBR);
    let boxesRailsFlag = this.boxesRailsValidations(newDTOBR);
    console.log("box rails flag", boxesRailsFlag);
    if (boxesRailsFlag) {
      let strBPA = newDTOBR["boxprojectionAreaDTO"];
      let strHTC = newDTOBR["handtrackingCoordinatesDTO"];

      let strBPAsplit1 = strBPA.split(",");
      let strHTCsplit1 = strHTC.split(",");

      let strBPAJSON = {}; let strHTCJSON = {};
      for (let i = 0; i < strBPAsplit1.length; i++) {
        let t = strBPAsplit1[i].split("=");
        strBPAJSON[t[0]] = t[1];
      }
      for (let i = 0; i < strHTCsplit1.length; i++) {
        let temp = strHTCsplit1[i].split("=");
        strHTCJSON[temp[0]] = temp[1];
      }
      strBPAJSON["color"] = "";
      strBPAJSON["form"] = "";
      strBPAJSON["id"] = enteredData["boxName"];
      strBPAJSON["type"] = "Rail";
      strHTCJSON["type"] = "Rail";
      strHTCJSON["id"] = enteredData["boxName"];

      newDTOBR["boxprojectionAreaDTO"] = strBPAJSON;
      newDTOBR["handtrackingCoordinatesDTO"] = strHTCJSON;
      console.log("new json sent", newDTOBR);
      this.deviceManagementService.saveBoxRails(newDTOBR).then(res => {
        row.confirm.resolve(res);
        this.boxesAndRails.empty();
        this.getBoxesRails({ itemsPerPage: 10, page: 1 });
      }).catch(err => { console.log("Error: ", err); });
    }
  };
  public boxesRailsValidations(rowObject: any): boolean {
    let val = true;
    for (let col in rowObject) {
      switch (col) {
        case "activeassistName":
          if (rowObject[col] == "") {
            this.notificationService.warning("Kindly fill the Active Assist ID");
            val = false;
          }
          break;
        case "materialName":
          if (rowObject[col] == "") {
            this.notificationService.warning("Kindly fill the Material Name");
            val = false;
          }
          break;
        case "boxtype":
          if (rowObject[col] == "") {
            this.notificationService.warning("Kindly fill the Box Type");
            val = false;
          }
          break;
        case "boxName":
          if (rowObject[col] == "") {
            this.notificationService.warning("Kindly fill the Box Name");
            val = false;
          }
          break;
        case "boxTrackingmode":
          if (rowObject[col] == "") {
            this.notificationService.warning("Kindly select the Box Tracking Mode");
            val = false;
          }
          break;
        case "ioportName":
          if (rowObject["boxTrackingmode"] == "Pick-To-Light") {
            if (rowObject[col] == "") {
              this.notificationService.warning("Kindly fill the Pos Nr");
              val = false;
            }
          }
          break;
        case "handtrackingCoordinatesDTO":
          if (rowObject["boxTrackingmode"] == "Virtual Box") {
            var reBPA = new RegExp("^(x=\\d{1,},y=\\d{1,},z=\\d{1,})$");
            if (!reBPA.test(rowObject[col])) {
              this.notificationService.warning("Kindly fill the coordinates in the format : x=0,y=0,z=0");
              val = false;
            }
            if (rowObject[col] == "") {
              this.notificationService.warning("Kindly fill the Hand Tracking Coordinates");
              val = false;
            }
          }
          break;
        case "boxprojectionAreaDTO":
          if (rowObject["boxTrackingmode"] == "Virtual Box") {
            var reBPA = new RegExp("^(x=\\d{1,},y=\\d{1,},z=\\d{1,},width=\\d{1,},height=\\d{1,})$");
            if (!reBPA.test(rowObject[col])) {
              this.notificationService.warning("Kindly fill the coordinates in the format : x=0,y=0,z=0,width=0,height=0");
              val = false;
            }
            if (rowObject[col] == "") {
              this.notificationService.warning("Kindly fill the Box Projection Area");
              val = false;
            }
          }
          break;
      }
    }
    return val;
  }
  public loadListBoxesRails(): void {
    // let BRList=this.settingsBoxRails.columns.activeassistName.editor.config.list;
    // let MList=this.settingsBoxRails.columns.materialName.editor.config.list;
    // let BTList= this.settingsBoxRails.columns.boxtype.editor.config.list;

    this.deviceManagementService.getActiveassistDropdown().then(res => {
      this.activeAssistListBR = res.content;
      console.log("reponse dropdown aaid", res);
      this.aaidListBR = [];
      for (let i = 0; i < this.activeAssistListBR.length; i++) {
        this.aaidListBR.push({ value: this.activeAssistListBR[i].activeAssistId, title: this.activeAssistListBR[i].activeAssistId, id: this.activeAssistListBR[i].id });
      }
      this.deviceManagementGlobalConfig.updateSettings(this.supervisorListAAID, this.aaidListDC, this.deviceTypeListDC, this.aaidListBR, this.materialDListBR, this.boxTypesDListBR);
      // this.settingsBoxRails.columns.activeassistName.editor.config.list =  this.activeAssistListBR.map((list)=> {
      //     return { value: list.activeAssistId, title: list.activeAssistId, id:list.id };
      //   });
      //   this.settingsBoxRails = Object.assign({}, this.settingsBoxRails);
      //   console.log("reponse dropdown aaid",this.settingsBoxRails.columns.activeassistName.editor.config.list);
    }).catch(err => { console.log("Error: ", err); });

    this.deviceManagementService.getMaterialDropdown().then(res => {
      this.materialListBR = res.content;
      console.log("reponse dropdown material", this.materialListBR);
      this.materialDListBR = [];
      for (let i = 0; i < this.materialListBR.length; i++) {
        this.materialDListBR.push({ value: this.materialListBR[i].materialName, title: this.materialListBR[i].materialName, id: this.materialListBR[i].id });
      }
      this.deviceManagementGlobalConfig.updateSettings(this.supervisorListAAID, this.aaidListDC, this.deviceTypeListDC, this.aaidListBR, this.materialDListBR, this.boxTypesDListBR);

      // this.settingsBoxRails.columns.materialName.editor.config.list =  this.materialListBR.map((list)=> {
      //     return { value: list.materialName, title: list.materialName, id:list.id };
      //   });
      //   this.settingsBoxRails = Object.assign({}, this.settingsBoxRails);
      //   console.log("reponse dropdown material",this.settingsBoxRails);
    }).catch(err => { console.log("Error: ", err); });

    this.deviceManagementService.getBoxType().then(res => {
      this.boxTypeListBR = res;
      console.log("reponse dropdown boxtype", res);
      this.boxTypesDListBR = [];
      for (let i = 0; i < this.boxTypeListBR.length; i++) {
        this.boxTypesDListBR.push({ value: this.boxTypeListBR[i].boxType, title: this.boxTypeListBR[i].boxType, id: this.boxTypeListBR[i].id, boxheightOutside: this.boxTypeListBR[i].heightOutside, boxlengthOutside: this.boxTypeListBR[i].lengthOutside, boxwidthOutside: this.boxTypeListBR[i].widthOutside });
      }
      this.deviceManagementGlobalConfig.updateSettings(this.supervisorListAAID, this.aaidListDC, this.deviceTypeListDC, this.aaidListBR, this.materialDListBR, this.boxTypesDListBR);
      // this.settingsBoxRails.columns.boxtype.editor.config.list =  this.boxTypeListBR.map((list)=> {
      //     return { value: list.boxType, title: list.boxType, id:list.id,boxheightOutside:list.heightOutside,boxlengthOutside:list.lengthOutside,boxwidthOutside:list.widthOutside };
      //   });
      //   this.settingsBoxRails = Object.assign({}, this.settingsBoxRails);
    }).catch(err => { console.log("Error: ", err); });
  };
  public copyBoxesRails(row: any): void {
    let enteredData = row.newData;
    let copyDTOBR = {
      "activeassistName": enteredData["activeassistName"],
      "activeassistId": enteredData["activeassistId"],
      "boxName": enteredData["boxName"],
      "boxTrackingmode": enteredData["boxTrackingmode"],
      "boxheightOutside": enteredData["boxheightOutside"],
      "boxlengthOutside": enteredData["boxlengthOutside"],
      "boxprojectionAreaDTO": JSON.parse(enteredData["boxprojectionAreaDTO"]),
      "boxtype": enteredData["boxtype"],
      "boxtypeId": enteredData["boxtypeId"],
      "boxwidthOutside": enteredData["boxwidthOutside"],
      "handtrackingCoordinatesDTO": JSON.parse(enteredData["handtrackingCoordinatesDTO"]),
      "ioportName": enteredData["ioportName"],
      "materialName": enteredData["materialName"],
      "materialNumber": enteredData["materialNumber"],
      "materialId": enteredData["materialId"]
    };

    this.deviceManagementService.saveBoxRails(copyDTOBR).then(res => {
      row.confirm.resolve(res);
    }).catch(err => { console.log("Error: ", err); });
  };
  public updateBoxesRails(row: any): void {
    let enteredData = row.newData;
    let aaidList = this.settingsBoxRails.columns.activeassistName.editor.config.list;
    let boxtypeList = this.settingsBoxRails.columns.boxtype.editor.config.list;
    let materialList = this.settingsBoxRails.columns.materialName.editor.config.list;

    let aaidID, boxTypeID, materialID;
    for (let i = 0; i < aaidList.length; i++) {
      if (enteredData["activeassistName"] == aaidList[i].title) {
        aaidID = aaidList[i].id;
      }
    }
    for (let i = 0; i < boxtypeList.length; i++) {
      if (enteredData["boxtype"] == boxtypeList[i].title) {
        boxTypeID = boxtypeList[i].id;
      }
    }
    for (let i = 0; i < materialList.length; i++) {
      if (enteredData["materialName"] == materialList[i].title) {
        materialID = materialList[i].id;
      }
    }
    let updateDTOBR = {
      "activeAssistMaterialBoxId": enteredData["activeAssistMaterialBoxId"],
      "activeassistName": enteredData["activeassistName"],
      "activeassistId": aaidID,
      "boxName": enteredData["boxName"],
      "boxTrackingmode": enteredData["boxTrackingmode"],
      "boxheightOutside": enteredData["boxheightOutside"],
      "boxlengthOutside": enteredData["boxlengthOutside"],
      "boxprojectionAreaDTO": JSON.parse(enteredData["boxprojectionAreaDTO"]),
      "boxtype": enteredData["boxtype"],
      "boxtypeId": boxTypeID,
      "boxwidthOutside": enteredData["boxwidthOutside"],
      "handtrackingCoordinatesDTO": JSON.parse(enteredData["handtrackingCoordinatesDTO"]),
      "ioportName": enteredData["ioportName"],
      "materialName": enteredData["materialName"],
      "materialNumber": enteredData["materialNumber"],
      "materialId": materialID
    };
    console.log("update DTO BR row data", enteredData);
    console.log("update DTO BR", updateDTOBR);
    let boxesRailsFlag = this.boxesRailsValidations(updateDTOBR);
    if (boxesRailsFlag) {
      this.deviceManagementService.updateBoxRails(updateDTOBR).then(res => {
        row.confirm.resolve(res);
      }).catch(err => { console.log("Error: ", err); });
    }
  };
  public deleteBoxRails(row: any): void {
    if (row && row.data) {
      this.boxTypeDeleteModal.hide();
      this.deviceManagementService.deleteBoxRails(row.data.activeassistId).then(res => {
        row.confirm.resolve();
        this.boxesAndRails.empty();
        this.getBoxesRails({ itemsPerPage: 10, page: this.boxRailsCurrentPageForDelete });
      }).catch(err => { console.log("Error: ", err); });
    }
  };
  public eventStartTeaching($event): void {
    console.log("event start teaching", $event);
    // let a=$event.data;
    // a["boxPosition"]=2;
    // a["boxProjectionArea"]="x=40,y=80,width=100,height=480";
    // a["boxtypeName"]="Type 3";
    // a["handTrackingCoordinates"]="x=45,y=50,z=15";
    // a["material"]="2432 000 222";
    // a["p2lPosNr"]="20";
  }

  public eventOk($event): void {
    console.log("event ok", $event);
  }
  public globalDMSTabChange(selectedTab): void {
    console.log("selecetd tab", selectedTab);
    if (selectedTab == "DEVICE_MANAGEMENT_GLOBAL.ACTIVE_ASSISTS" || selectedTab == "DEVICE_MANAGEMENT_GLOBAL.BOX_TYPES" || selectedTab == "DEVICE_MANAGEMENT_GLOBAL.MATERIAL" || selectedTab == "DEVICE_MANAGEMENT_GLOBAL.DEVICE_CONFIG") {
      this.displayAADropdown = "aaid-dropdown-hide";
    }
    else {
      this.displayAADropdown = "aaid-dropdown-show";
    }
  }



  public listDevice: any;
  public getAllActiveAssistDevice(pagination): void {
    let _pagination = pagination || this.settingsDeviceConfig.serverSidePagination;
    console.log("count device table data", this.deviceType.count());
    console.log("pagination page", _pagination.page);
    if (this.deviceType.count() == 0 || _pagination.page != this.settingsDeviceConfig.serverSidePagination.page) {
      this.deviceManagementService.getAllActiveAssistDevice(_pagination).then(res => {
        this.listDevice = res;
        this.settingsDeviceConfig.serverSidePagination.totalItems = res.size;
        //call the device management service to get the data       
        this.deviceType.load(res.content);
        if (!this.deviceType.count()) {
          this.deviceManagementService.getAllActiveAssistDevice().then(res => {
            this.deviceType.load(res);
          });
        }
      }).catch(err => { console.log("Error: ", err); });
    }
  };
  //Pagination for Device Config tab
  public pageChangedActiveAssistDevice(pagination): void {
    this.deviceConfigCurrentPageForDelete = pagination.page;
    this.getAllActiveAssistDevice(pagination);
  };

  // Onclick of device config tab get device ID
  deviceConfigTabClickDeviceID() {
    this.deviceManagementService.getActiveAssistId().then(res => {

      this.activeAssistDeviceIdList = res;
      console.log("reponse dropdown aaid", res);
      this.aaidListDC = [];
      for (let i = 0; i < this.activeAssistDeviceIdList.length; i++) {
        this.aaidListDC.push({ value: this.activeAssistDeviceIdList[i].activeAssistId, title: this.activeAssistDeviceIdList[i].activeAssistId });
      }
      console.log("aaid dc arr", this.aaidListDC);
      this.deviceManagementGlobalConfig.updateSettings(this.supervisorListAAID, this.aaidListDC, this.deviceTypeListDC, this.aaidListBR, this.materialDListBR, this.boxTypesDListBR);

      // this.settingsDeviceConfig.columns.activeAssistActiveAssistId.editor.config.list = this.activeAssistDeviceIdList.map((list) => {
      //   return { value: list.activeAssistId, title: list.activeAssistId };
      // });
      // this.settingsDeviceConfig = Object.assign({}, this.settingsDeviceConfig);
    }).catch(err => { console.log("Error: ", err); });
  }
  //to get device ID 
  public setActiveAssistDeviceId(data: any): any {
    let deviceList = this.activeAssistDeviceIdList;
    for (let i = 0; i < deviceList.length; i++) {
      if (data == deviceList[i].activeAssistId) {
        return deviceList[i].id;
      }
    }
  }

  //onclick of device config tab device type
  deviceConfigTabClickDeviceType() {
    this.deviceManagementService.getDeviceType().then(res => {
      this.DeviceTypeList = res;
      this.deviceTypeListDC = [];
      for (let i = 0; i < this.DeviceTypeList.length; i++) {
        this.deviceTypeListDC.push({ value: this.DeviceTypeList[i].name, title: this.DeviceTypeList[i].name, id: this.DeviceTypeList[i].typeId });
      }
      this.deviceManagementGlobalConfig.updateSettings(this.supervisorListAAID, this.aaidListDC, this.deviceTypeListDC, this.aaidListBR, this.materialDListBR, this.boxTypesDListBR);
      // this.settingsDeviceConfig.columns.deviceTypeName.editor.config.list = this.DeviceTypeList.map((list) => {
      //   return { value: list.name, title: list.name, id: list.typeId };

      // });
      // this.settingsDeviceConfig = Object.assign({}, this.settingsDeviceConfig);
    }).catch(err => { console.log("Error: ", err); });
  }


  //Device type validation
  public validateDeviceTypeData(data: any): boolean {
    let flagDC = false;
    for (let col in data) {
      if (col == "activeAssistActiveAssistId") {
        if (data[col] == "") {
          flagDC = true;
          this.notificationService.warning("Kindly select an AA ID");
        }
      }
      if (col == "deviceTypeName") {
        if (data[col] == "") {
          flagDC = true;
          this.notificationService.warning("Kindly select a Device Type");
        }
      }
    }
    return flagDC;
  }

  public setDeviceTypeId(data: any): any {
    let deviceList = this.DeviceTypeList;
    for (let i = 0; i < deviceList.length; i++) {
      if (data == deviceList[i].name) {
        return deviceList[i].id;
      }
    }
  }

  //Save device type service 
  public saveActiveAssistDevice(row: any): void {
    if (!this.validateDeviceTypeData(row.newData)) {

      let deviceId = this.setDeviceTypeId(row.newData.deviceTypeName);
      let activeAssistID = this.setActiveAssistDeviceId(row.newData.activeAssistActiveAssistId);
      console.log(activeAssistID, "activeAssistIDactiveAssistIDactiveAssistIDactiveAssistID");

      this.deviceManagementService.getActiveAssistDeviceTypeById(deviceId).then(res => {
        console.log("devce detILS", res);
        if (res) {
          let deviceTable = row.newData;
          let _deviceTableTable = {
            "activeAssistActiveAssistId": deviceTable["activeAssistActiveAssistId"],
            "activeAssistDeviceActiveAssistId": activeAssistID,
            "activeAssistDeviceDeviceTypeId": res.id,
            "activeAssistDeviceId": 0,
            "deviceTypeCategory": res.category,
            "deviceTypeDescription": res.description,
            "deviceTypeName": res.name,
            "deviceTypeTypeId": res.typeId,
          }
          this.deviceManagementService.createActiveAssistDevice(_deviceTableTable).then(res => {
            row.confirm.resolve(res);
            this.settingsDeviceConfig.serverSidePagination.page = 1;
            this.deviceType.empty();
            this.getAllActiveAssistDevice({ itemsPerPage: 10, page: 1 });
          }).catch(err => { console.log("Error: ", err); });
        }
      }).catch(err => { console.log("Error: ", err); });
    }
  };

  // //Copy device type service 
  public copyActiveAssistDevice(row: any): void {
    //let selecteDeviceData = row.newData;
    row.newData.id = 0;
    this.deviceManagementService.createActiveAssistDevice(row.newData).then(res => {
      row.confirm.resolve(res);
    }).catch(err => { console.log("Error: ", err); });
  };


  // //update device type service 
  public updateActiveAssistDevice(row: any): void {
    if (!this.validateDeviceTypeData(row.newData)) {
      let deviceId = this.setDeviceTypeId(row.newData.deviceTypeName);
      let activeAssistID = this.setActiveAssistDeviceId(row.newData.activeAssistActiveAssistId);
      this.deviceManagementService.getActiveAssistDeviceTypeById(deviceId).then(res => {
        console.log("devce detILS", res);
        if (res) {
          let deviceTable = row.newData;
          let _deviceTableTable = {
            "activeAssistActiveAssistId": deviceTable["activeAssistActiveAssistId"],
            "activeAssistDeviceActiveAssistId": activeAssistID,
            "activeAssistDeviceDeviceTypeId": res.id,
            "activeAssistDeviceId": deviceTable["activeAssistDeviceId"],
            "deviceTypeCategory": res.category,
            "deviceTypeDescription": res.description,
            "deviceTypeName": res.name,
            "deviceTypeTypeId": res.typeId,
          }
          this.deviceManagementService.updateActiveAssistDevice(_deviceTableTable).then(res => {
            row.confirm.resolve(res);
            //this.getActiveassist({ itemsPerPage: 10,page: 1});
          }).catch(err => { console.log("Error: ", err); });
        }
      }).catch(err => { console.log("Error: ", err); });

    }
  };

  //Delete device type service 
  public deleteActiveAssistDevice(row: any): void {
    let deviceTypeId = row.data.activeAssistDeviceId
    this.deviceManagementService.deleteActiveAssistDevice(deviceTypeId).then(res => {
      row.confirm.resolve();
      this.DeviceTypeDeleteModal.hide();
    }).catch(err => { console.log("Error: ", err); });
  };



  
  ngOnInit() {
    this.selectedActiveAssistId="all";
    this.displayPagination="show-pagination";
    this.getAllActiveAssistID();
    this.getActiveassist({itemsPerPage:10, page:1});
    //this.getAllActiveAssistDevice({itemsPerPage: 10, page: 1});
    //this.getMaterial({itemsPerPage: 10, page: 1});
    //this.getBoxTypes({ itemsPerPage: 10, page: 1 });
    //this.getBoxesRails({itemsPerPage:10, page:1});
    console.log("selected tab", this.selectedTab);
    this.loadListAASupervisor();
    this.loadListBoxesRails();
    this.deviceConfigTabClickDeviceID(); 
    this.deviceConfigTabClickDeviceType();
    if (this.selectedTab == "DEVICE_MANAGEMENT_GLOBAL.ACTIVE_ASSISTS" || this.selectedTab == "DEVICE_MANAGEMENT_GLOBAL.BOX_TYPES" || this.selectedTab == "DEVICE_MANAGEMENT_GLOBAL.MATERIAL"  ||this.selectedTab == "DEVICE_MANAGEMENT_GLOBAL.DEVICE_CONFIG") {
      this.displayAADropdown = "aaid-dropdown-hide";
    }
    else {
      this.displayAADropdown = "aaid-dropdown-show";
    }
  }
}
