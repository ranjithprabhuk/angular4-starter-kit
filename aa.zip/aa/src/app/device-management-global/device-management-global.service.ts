import { Injectable } from '@angular/core';
import { URLSearchParams } from '@angular/http';
import { ApiService } from '../app.service';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class DeviceManagementGlobalService {

    constructor(private apiService: ApiService) {
        //this.getDetails();
     }
    //protected apiEndPoint: string = this.apiService.baseUrl.deviceManagementServicePort +"/";
    protected apiEndPoint: string = "";

    public host = "deviceManagementService";

    getDetails(): void {
        this.getExternalProperties().then((res) => {
            this.apiEndPoint = res.deviceManagementServicePort + "/";
        });
    }

    getExternalProperties(): Promise<any> {
        return this.apiService.getExternalApplicationProperties().then(res => { return Promise.resolve(res) });
    }

    //to get the Active Assist ID - DropDown
    getAllActiveAssistIDData(parameter?: any): Promise<any> {
        let params: URLSearchParams = new URLSearchParams();
        return this.apiService.get(this.host, this.apiEndPoint + "getAllActiveAssistID")
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }
    //to get the Active Assist table data 
    getActiveassistData(parameter?: any): Promise<any> {
        let params: URLSearchParams = new URLSearchParams();
        parameter.page = parameter.page - 1;
        params.append("page", parameter.page);
        params.append("size", parameter.itemsPerPage);
        return this.apiService.get(this.host, this.apiEndPoint + "getAllActiveassist?" + params)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    getActiveassistDropdown(parameter?: any): Promise<any> {
        let params: URLSearchParams = new URLSearchParams();
        return this.apiService.get(this.host, this.apiEndPoint + "getAllActiveassist?" + params)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    // to save a new Active Assist (create)
    saveActiveAssist(parameter?: any): Promise<any> {
        return this.apiService.create(this.host, this.apiEndPoint + "createActiveassist", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }


    //to update an Active Assist (edit)
    updateActiveAssistData(parameter?: any): Promise<any> {
        return this.apiService.update(this.host, this.apiEndPoint + "updateActiveassist", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    //to delete a Active Assist
    deleteActiveAssist(parameter?: any): Promise<any> {
        let params = "?activeAssistId=" + parameter;
        return this.apiService.delete(this.host, this.apiEndPoint + "deleteActiveassist" + params)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }


    // to restore an Active Assist
    restoreActiveAssist(parameter?: any): Promise<any> {
        // let params: URLSearchParams = new URLSearchParams();
        // params.append("?activeAssistId=", parameter);
        let params = "?activeAssistId=" + parameter;
        console.log("inside service", this.apiEndPoint);
        return this.apiService.createWithURParam(this.host, this.apiEndPoint + "restoreConfigFiles" + params)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });

    }


    // to backup an Active Assist
    backupActiveAssist(parameter?: any): Promise<any> {
        let params = "?activeAssistId=" + parameter;
         console.log("inside service",params );
        return this.apiService.createWithURParam(this.host,this.apiEndPoint+"backupConfigFiles"+params)
            .then(res => { return Promise.resolve(res)})
            .catch(err => { return Promise.reject(err)});
    }

 
   // to clone an Active Assist
  saveActiveAssistIdClone(parameter?:any): Promise<any> {
        return this.apiService.createWithoutLoader(this.host,this.apiEndPoint+"cloneActiveAssist",parameter)
            .then(res => { return Promise.resolve(res)})
            .catch(err => { return Promise.reject(err)});
    }

    getSupervisor(parameter?:any): Promise<any> {   
        let params: URLSearchParams = new URLSearchParams();
        return this.apiService.get(this.host,this.apiEndPoint+"/allUsers?"+params)
            .then(res => { return Promise.resolve(res)})
            .catch(err => { return Promise.reject(err)});
    }
    /**
    * Box Types API calls
    * saveBoxTypes()-/createBoxtype
    * deleteBoxTypes()-/deleteBoxtype
    * getBoxTypes()-/getAllBoxtype
    * /getBoxtype 
    * updateBoxType()-/updateBoxtype
    */
    getBoxTypesForValidation(parameter?: any): Promise<any> {
        let params: URLSearchParams = new URLSearchParams();
        return this.apiService.get(this.host, this.apiEndPoint + "getAllBoxtype?" + params)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    getBoxType(parameter?: any): Promise<any> {
        let params: URLSearchParams = new URLSearchParams();
        return this.apiService.get(this.host, this.apiEndPoint + "getBoxtype?" + params)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }
    getBoxTypes(parameter?: any): Promise<any> {
        let params: URLSearchParams = new URLSearchParams();
        parameter.page = parameter.page - 1;
        params.append("page", parameter.page);
        params.append("size", parameter.itemsPerPage);
        return this.apiService.get(this.host, this.apiEndPoint + "getAllBoxtype?" + params)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    saveBoxType(parameter?: any): Promise<any> {
        return this.apiService.create(this.host, this.apiEndPoint + "createBoxtype", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }
    updateBoxType(parameter?: any): Promise<any> {
        return this.apiService.update(this.host, this.apiEndPoint + "updateBoxtype", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }
    deleteBoxType(parameter?: any): Promise<any> {
        let params = "?id=" + parameter;
        return this.apiService.delete(this.host, this.apiEndPoint + "deleteBoxtype" + params)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    // Materials
    // getMaterialData()
    // saveMaterial() 

    //to get the Material table data
    getMaterialData(parameter?: any): Promise<any> {
        let params: URLSearchParams = new URLSearchParams();
        parameter.page = parameter.page - 1;
        params.append("page", parameter.page);
        params.append("size", parameter.itemsPerPage);
        return this.apiService.get(this.host, this.apiEndPoint + "getAllMaterial?" + params)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    getMaterialDropdown(parameter?: any): Promise<any> {
        let params: URLSearchParams = new URLSearchParams();
        return this.apiService.get(this.host, this.apiEndPoint + "getAllMaterial?" + params)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    // to save a new Material (create)
    saveMaterial(parameter?: any): Promise<any> {
        return this.apiService.create(this.host, this.apiEndPoint + "createMaterial", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }


    //to update an Material (edit)
    updateMaterialData(parameter?: any): Promise<any> {
        return this.apiService.update(this.host, this.apiEndPoint + "updateMaterial", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    // deleteMaterial(parameter?:any): Promise<any> {
    //       let params = "?activeAssistId=" + parameter;
    //     return this.apiService.delete(this.apiEndPoint+"deleteMaterial" + params)
    //         .then(res => { return Promise.resolve(res)})
    //         .catch(err => { return Promise.reject(err)});
    // }

    deleteMaterial(parameter?: any): Promise<any> {
        return this.apiService.delete(this.host, this.apiEndPoint + "deleteMaterial/" + parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    /**
     * Active Assist Dropdown API
     * getActiveassistList()-/getAllActiveAssistID
     */
    getActiveassistList(parameter?: any): Promise<any> {
        let params: URLSearchParams = new URLSearchParams();
        return this.apiService.get(this.host, this.apiEndPoint + "getAllActiveAssistID")
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }
    /**
     * Boxes and Rails API calls
     * getBoxesRails() - /getAllActiveAssistMaterialBox
     * saveBoxRails()-/saveActiveAssistMaterialBox
     * updateBoxRails()-/updateActiveAssistMaterialBox
     * deleteBoxRails()-/deleteActiveAssistMaterialBox
     */
    getBoxesRails(parameter?: any): Promise<any> {
        let params: URLSearchParams = new URLSearchParams();
        parameter.page = parameter.page - 1;
        params.append("page", parameter.page);
        params.append("size", parameter.itemsPerPage);
        return this.apiService.get(this.host, this.apiEndPoint + "getAllActiveAssistMaterialBox?" + params)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }
    getBoxesRailsAAID(parameter?: any): Promise<any> {
        let params = "?activeAssistId=" + parameter;
        return this.apiService.get(this.host, this.apiEndPoint + "getActiveAssistMaterialBox" + params)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }
    saveBoxRails(parameter?: any): Promise<any> {
        return this.apiService.create(this.host, this.apiEndPoint + "saveActiveAssistMaterialBox", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }
    updateBoxRails(parameter?: any): Promise<any> {
        return this.apiService.update(this.host, this.apiEndPoint + "updateActiveAssistMaterialBox", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }
    deleteBoxRails(parameter?: any): Promise<any> {
        let params = "?activeassistMaterialBoxId=" + parameter;
        return this.apiService.delete(this.host, this.apiEndPoint + "deleteActiveAssistMaterialBox" + params)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }


    /**
       * Device Config  API calls
       * 
       * 
       */

    /* Device config getActiveassistDevice */
    getActiveAssistId(parameter?: any): Promise<any> {
        let params: URLSearchParams = new URLSearchParams();
        return this.apiService.get(this.host, this.apiEndPoint + "getAllActiveAssistID")
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }
    /* Device config getActiveassistDevice type */
    getDeviceType(parameter?: any): Promise<any> {
        //  let params: URLSearchParams = new URLSearchParams();
        return this.apiService.get(this.host, this.apiEndPoint + "getDeviceTypes")
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }
    /* Device config getActiveassistDevice type */
    getAllActiveAssistDevice(parameter?: any): Promise<any> {
        let params: URLSearchParams = new URLSearchParams();
        parameter.page = parameter.page - 1;
        params.append("page", parameter.page);
        params.append("size", parameter.itemsPerPage);
        return this.apiService.get(this.host, this.apiEndPoint + "getAllActiveAssistDevices?" + params)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }


    /* Device config getActiveassistDevice information bsed on device type */
    getActiveAssistDeviceTypeById(parameter?: any): Promise<any> {
        //  let params: URLSearchParams = new URLSearchParams();
        return this.apiService.get(this.host, this.apiEndPoint + "getDeviceTypeById/" + parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }


    //      // to save a new Device data (create)
    createActiveAssistDevice(parameter?: any): Promise<any> {
        return this.apiService.create(this.host, this.apiEndPoint + "createActiveAssistDevices", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }


    //to update  Device Type (edit)
    updateActiveAssistDevice(parameter?: any): Promise<any> {
        return this.apiService.update(this.host, this.apiEndPoint + "updateActiveAssistDevices", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }


    // Delete  device Type
    deleteActiveAssistDevice(parameter?: any): Promise<any> {
        let params = "?activeAssistDeviceId=" + parameter;
        return this.apiService.delete(this.host, this.apiEndPoint + "deleteActiveAssistDevices" + params)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

}
