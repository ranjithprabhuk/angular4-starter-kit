import { TranslateService, TranslationChangeEvent } from '@ngx-translate/core';
import { AuthenticationService } from '../authentication/authentication.service';

export class DeviceManagementGlobalConfig {

    constructor(private translate: TranslateService, private authService: AuthenticationService) {
        this.checkPermissions();
    }
    public tablePermissions: boolean = true;

    public checkPermissions(): void {
        if (this.authService.appPermissions == undefined) {
            this.authService.logout();
        }
    }

    public getMaterialPermissions(): boolean {
        if (this.authService.appPermissions != undefined) {
            return this.authService.appPermissions["Create/Change/Delete Material"];
        } else {
            this.authService.logout();
        }
    }

    public getBoxPermissions(): boolean {
        if (this.authService.appPermissions != undefined) {
            return this.authService.appPermissions["Create/Change/Delete Boxes"];
        } else {
            this.authService.logout();
        }
    }

    public getWorkplacePermissions(): boolean {
        if (this.authService.appPermissions != undefined) {
            return this.authService.appPermissions["Create/Change/Delete Workplaces"];
        } else {
            this.authService.logout();
        }
    }

    //pagination  settings
    public paginationSettings: Object = {
        display: false,
        perPage: 10
    };
    //table configuration for Active Assist Tab
    public ActiveAssistsSettings: Object = {
        actions: {
            columnTitle: 'Actions',
            add: this.getWorkplacePermissions(),
            edit: this.getWorkplacePermissions(),
            delete: this.getWorkplacePermissions(),
            copy: this.getWorkplacePermissions(),
            move: false,
            position: 'left', // left|right
        },
        columns: {
            activeAssistId: {
                title: 'AA_ID',
                filter: true,
                minWidth: "200px"
            },
            ip: {
                title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.IP_ADDRESS_COL"),
                filter: true,
                minWidth: "200px"
            },
            company: {
                title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.COMPANY_COL"),
                filter: true,
                minWidth: "200px"
            },
            plant: {
                title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.PLANT_COL"),
                filter: true,
                minWidth: "100px"
            },
            department: {
                title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.DEPARTMENT_COL"),
                filter: true,
                minWidth: "100px"
            },
            releaseVersion: {
                title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.RELEASE_VERSION_COL"),
                filter: true,
                minWidth: "150px"
            },
            line: {
                title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.LINE_COL"),
                filter: true,
                minWidth: "100px"
            },
            supervisor: {
                title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.SUPERVISOR_COL"),
                filter: true,
                minWidth: "200px",
                editor: {
                    type: 'list',
                    config: {
                        selectText: 'Select...',
                        list: [
                            { value: '', title: '' }
                        ],
                    }
                }
            },
            portNumber: {
                title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.PORT_NUMBER_COL"),
                type: 'number',
                filter: true,
                minWidth: "100px"
            },
            restore: {
                title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.RESTORE_COL"),
                filter: false,
                minWidth: "50px",
                type: "button",
                buttonText: "Restore",

            },
            backup: {
                title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.BACKUP_COL"),
                filter: false,
                minWidth: "50px",
                type: "button",
                buttonText: "Backup",

            },
            clone: {
                title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.CLONE_COL"),
                filter: false,
                minWidth: "50px",
                type: "button",
                buttonText: "Clone",

            },

        },
        pager: this.paginationSettings,
        serverSidePagination: {
            itemsPerPage: 10,
            page: 1,
            totalItems: 0
        }
    };


    //table configuration for Material Tab
    public MaterialSettings: Object = {
        actions: {
            columnTitle: 'Actions',
            add: this.getMaterialPermissions(),
            edit: this.getMaterialPermissions(),
            delete: this.getMaterialPermissions(),
            copy: this.getMaterialPermissions(),
            move: false,
            position: 'left', // left|right
        },
        columns: {
            materialNumber: {
                title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.MATERIAL_NUMBER_COL"),

                filter: true,
                minWidth: "200px"
            },
            materialName: {
                title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.MATERIAL_NAME"),
                filter: true,
                minWidth: "200px"
            },
            description: {
                title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.DESCRIPTION_COL"),
                filter: true,
                minWidth: "200px"
            },
            timestamp: {
                title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.CREATE_DATE_COL"),
                filter: true,
                minWidth: "70px",
                disabled: true,
            },
        },
        pager: this.paginationSettings,
        serverSidePagination: {
            itemsPerPage: 10,
            page: 1,
            totalItems: 0
        }
    };


    public BoxTypesSettings: Object = {
        actions: {
            columnTitle: '',
            add: true,
            edit: true,
            delete: true,
            copy: true,
            move: false,
            position: 'left', // left|right
        },
        columns: {
            boxType: {
                title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.BOX_TYPE_NAME_COL"),
                filter: true,
                minWidth: "180px"
            },
            lengthOutside: {
                title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.LENGTH_COL"),
                filter: true,
                minWidth: "106px",
                type: 'number'
            },
            widthOutside: {
                title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.WIDTH_COL"),
                filter: true,
                minWidth: "50px",
                type: 'number'
            },
            heightOutside: {
                title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.HEIGHT_COL"),
                filter: true,
                minWidth: "200px",
                type: 'number'
            }
        },
        pager: this.paginationSettings,
        serverSidePagination: {
            itemsPerPage: 10,
            page: 1,
            totalItems: 0
        }
    };
    public BoxRailsSettings: Object = {
        actions: {
            columnTitle: '',
            add: this.getBoxPermissions(),
            edit: this.getBoxPermissions(),
            delete: this.getBoxPermissions(),
            copy: this.getBoxPermissions(),
            move: false,
            position: 'left', // left|right
        },
        columns: {
            activeassistName: {
                title: 'AA ID',
                filter: true,
                minWidth: "100px",
                editor: {
                    type: 'list',
                    config: {
                        selectText: 'Select...',
                        list: [
                            { value: '', title: '', id: '' }
                        ],
                    }
                }
            },
            materialName: {
                title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.BOX_MATERIAL_COL"),
                filter: true,
                minWidth: "100px",
                editor: {
                    type: 'list',
                    config: {
                        selectText: 'Select...',
                        list: [
                            { value: '', title: '', id: '' }
                        ],
                    }
                }
            },
            boxtype: {
                title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.BOX_TYPE_COL"),
                filter: true,
                minWidth: "106px",
                editor: {
                    type: 'list',
                    config: {
                        selectText: 'Select...',
                        list: [
                            { value: '', title: '', id: '', boxheightOutside: '', boxlengthOutside: '', boxwidthOutside: '' }
                        ],
                    }
                }
            },
            boxName: {
                title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.BOX_NAME_COL"),
                filter: true,
                minWidth: "106px"
            },
            boxTrackingmode: {
                title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.BOX_TRACKING_MODE_COL"),
                filter: true,
                minWidth: "140px",
                editor: {
                    type: 'list',
                    config: {
                        selectText: 'Select...',
                        list: [
                            { value: 'Virtual Box', title: 'Virtual Box' },
                            { value: 'Pick-To-Light', title: 'Pick-To-Light' },
                        ],
                    }
                }
            },
            ioportName: {
                title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.BOX_POS_NUMBER_COL"),
                filter: true,
                minWidth: "100px"
            },
            boxprojectionAreaDTO: {
                title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.BOX_PROJECTION_AREA_COL"),
                filter: true,
                minWidth: "300px",
                projectionAreaIcon: true
            },
            handtrackingCoordinatesDTO: {
                title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.BOX_HAND_TRACKING_COORD_COL"),
                filter: true,
                minWidth: "250px",
                projectionAreaIcon: true
            }
        },
        pager: this.paginationSettings,
        serverSidePagination: {
            itemsPerPage: 10,
            page: 1,
            totalItems: 0
        }
    };


    public DeviceConfigSettings: Object = {
        actions: {
            columnTitle: 'Actions',
            add: true,
            edit: true,
            delete: true,
            copy: true,
            move: false,
            position: 'left', // left|right
        },
        columns: {
            activeAssistActiveAssistId: {
                title: 'AA ID',
                filter: true,
                minWidth: "100px",
                editor: {
                    type: 'list',
                    config: {

                        selectText: 'select..',
                        list: [

                            { value: '', title: '' }

                        ],
                    }
                }
            },

            activeAssistDeviceDeviceTypeId: {
                title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.DEVICE_NUMBER_COL"),
                filter: true,
                minWidth: "106px",
                disabled: true
            },
            deviceTypeCategory: {
                title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.DEVICE_CATEGORY_COL"),
                filter: true,
                minWidth: "50px",
                disabled: true
            },
            deviceTypeName: {
                title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.DEVICE_TYPE_COL"),
                filter: true,
                minWidth: "200px",
                editor: {
                    type: 'list',
                    config: {

                        selectText: 'select..',
                        list: [

                            { value: '', title: '' }

                        ],
                    }
                }
            },
            deviceTypeDescription: {
                title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.DESCRIPTION_COL"),
                filter: true,
                minWidth: "200px",
                disabled: true
            }
        },
        pager: this.paginationSettings,
        serverSidePagination: {
            itemsPerPage: 10,
            page: 1,
            totalItems: 0
        }
    };

    public updateSettings(supervisorListAAID, aaidListDC, deviceTypeListDC, aaidListBR, materialListBR, boxTypeListBR) {
        this.ActiveAssistsSettings = {
            actions: {
                columnTitle: 'Actions',
                add: true,
                edit: true,
                delete: true,
                copy: true,
                move: false,
                position: 'left', // left|right
            },
            columns: {
                activeAssistId: {
                    title: 'AA_ID',
                    filter: true,
                    minWidth: "200px"
                },
                ip: {
                    title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.IP_ADDRESS_COL"),
                    filter: true,
                    minWidth: "200px"
                },
                company: {
                    title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.COMPANY_COL"),
                    filter: true,
                    minWidth: "200px"
                },
                plant: {
                    title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.PLANT_COL"),
                    filter: true,
                    minWidth: "100px"
                },
                department: {
                    title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.DEPARTMENT_COL"),
                    filter: true,
                    minWidth: "100px"
                },
                releaseVersion: {
                    title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.RELEASE_VERSION_COL"),
                    filter: true,
                    minWidth: "150px"
                },
                line: {
                    title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.LINE_COL"),
                    filter: true,
                    minWidth: "100px"
                },
                supervisor: {
                    title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.SUPERVISOR_COL"),
                    filter: true,
                    minWidth: "200px",
                    editor: {
                        type: 'list',
                        config: {
                            selectText: 'Select...',
                            list: supervisorListAAID,
                        }
                    }
                },
                portNumber: {
                    title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.PORT_NUMBER_COL"),
                    type: 'number',
                    filter: true,
                    minWidth: "100px"
                },
                restore: {
                    title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.RESTORE_COL"),
                    filter: false,
                    minWidth: "50px",
                    type: "button",
                    buttonText: "Restore",

                },
                backup: {
                    title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.BACKUP_COL"),
                    filter: false,
                    minWidth: "50px",
                    type: "button",
                    buttonText: "Backup",

                },
                clone: {
                    title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.CLONE_COL"),
                    filter: false,
                    minWidth: "50px",
                    type: "button",
                    buttonText: "Clone",

                },

            },
            pager: this.paginationSettings,
            serverSidePagination: {
                itemsPerPage: 10,
                page: 1,
                totalItems: 0
            }
        };

        this.MaterialSettings = {
            actions: {
                columnTitle: 'Actions',
                add: true,
                edit: true,
                delete: true,
                copy: true,
                move: false,
                position: 'left', // left|right
            },
            columns: {
                materialNumber: {
                    title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.MATERIAL_NUMBER_COL"),

                    filter: true,
                    minWidth: "200px"
                },
                materialName: {
                    title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.MATERIAL_NAME"),
                    filter: true,
                    minWidth: "200px"
                },
                description: {
                    title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.DESCRIPTION_COL"),
                    filter: true,
                    minWidth: "200px"
                },
                timestamp: {
                    title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.CREATE_DATE_COL"),
                    filter: true,
                    minWidth: "70px",
                    disabled: true,
                },
            },
            pager: this.paginationSettings,
            serverSidePagination: {
                itemsPerPage: 10,
                page: 1,
                totalItems: 0
            }
        };

        this.BoxTypesSettings = {
            actions: {
                columnTitle: '',
                add: true,
                edit: true,
                delete: true,
                copy: true,
                move: false,
                position: 'left', // left|right
            },
            columns: {
                boxType: {
                    title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.BOX_TYPE_NAME_COL"),
                    filter: true,
                    minWidth: "180px"
                },
                lengthOutside: {
                    title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.LENGTH_COL"),
                    filter: true,
                    minWidth: "106px",
                    type: 'number'
                },
                widthOutside: {
                    title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.WIDTH_COL"),
                    filter: true,
                    minWidth: "50px",
                    type: 'number'
                },
                heightOutside: {
                    title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.HEIGHT_COL"),
                    filter: true,
                    minWidth: "200px",
                    type: 'number'
                }
            },
            pager: this.paginationSettings,
            serverSidePagination: {
                itemsPerPage: 10,
                page: 1,
                totalItems: 0
            }
        };

        this.DeviceConfigSettings = {
            actions: {
                columnTitle: 'Actions',
                add: true,
                edit: true,
                delete: true,
                copy: true,
                move: false,
                position: 'left', // left|right
            },
            columns: {
                activeAssistActiveAssistId: {
                    title: 'AA ID',
                    filter: true,
                    minWidth: "100px",
                    editor: {
                        type: 'list',
                        config: {

                            selectText: 'select..',
                            list: aaidListDC,
                        }
                    }
                },

                activeAssistDeviceDeviceTypeId: {
                    title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.DEVICE_NUMBER_COL"),
                    filter: true,
                    minWidth: "106px",
                    disabled: true
                },
                deviceTypeCategory: {
                    title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.DEVICE_CATEGORY_COL"),
                    filter: true,
                    minWidth: "50px",
                    disabled: true
                },
                deviceTypeName: {
                    title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.DEVICE_TYPE_COL"),
                    filter: true,
                    minWidth: "200px",
                    editor: {
                        type: 'list',
                        config: {

                            selectText: 'select..',
                            list: deviceTypeListDC,
                        }
                    }
                },
                deviceTypeDescription: {
                    title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.DESCRIPTION_COL"),
                    filter: true,
                    minWidth: "200px",
                    disabled: true
                }
            },
            pager: this.paginationSettings,
            serverSidePagination: {
                itemsPerPage: 10,
                page: 1,
                totalItems: 0
            }
        };

        this.BoxRailsSettings = {
            actions: {
                columnTitle: '',
                add: true,
                edit: true,
                delete: true,
                copy: true,
                move: false,
                position: 'left', // left|right
            },
            columns: {
                activeassistName: {
                    title: 'AA ID',
                    filter: true,
                    minWidth: "100px",
                    editor: {
                        type: 'list',
                        config: {
                            selectText: 'Select...',
                            list: aaidListBR,
                        }
                    }
                },
                materialName: {
                    title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.BOX_MATERIAL_COL"),
                    filter: true,
                    minWidth: "100px",
                    editor: {
                        type: 'list',
                        config: {
                            selectText: 'Select...',
                            list: materialListBR,
                        }
                    }
                },
                boxtype: {
                    title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.BOX_TYPE_COL"),
                    filter: true,
                    minWidth: "106px",
                    editor: {
                        type: 'list',
                        config: {
                            selectText: 'Select...',
                            list: boxTypeListBR,
                        }
                    }
                },
                boxName: {
                    title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.BOX_NAME_COL"),
                    filter: true,
                    minWidth: "106px"
                },
                boxTrackingmode: {
                    title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.BOX_TRACKING_MODE_COL"),
                    filter: true,
                    minWidth: "140px",
                    editor: {
                        type: 'list',
                        config: {
                            selectText: 'Select...',
                            list: [
                                { value: 'Virtual Box', title: 'Virtual Box' },
                                { value: 'Pick-To-Light', title: 'Pick-To-Light' },
                            ],
                        }
                    }
                },
                ioportName: {
                    title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.BOX_POS_NUMBER_COL"),
                    filter: true,
                    minWidth: "100px"
                },
                boxprojectionAreaDTO: {
                    title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.BOX_PROJECTION_AREA_COL"),
                    filter: true,
                    minWidth: "300px",
                    projectionAreaIcon: true
                },
                handtrackingCoordinatesDTO: {
                    title: this.translate.instant("DEVICE_MANAGEMENT_GLOBAL.BOX_HAND_TRACKING_COORD_COL"),
                    filter: true,
                    minWidth: "250px",
                    projectionAreaIcon: true
                }
            },
            pager: this.paginationSettings,
            serverSidePagination: {
                itemsPerPage: 10,
                page: 1,
                totalItems: 0
            }
        };
    }
}