import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { TabsModule,ModalModule,PaginationModule } from 'ng2-bootstrap';
import { Ng2SmartTableModule } from '../smart-table';
import { TranslateModule } from '@ngx-translate/core';

import { DeviceManagementGlobalComponent } from './device-management-global.component';
import { DeviceManagementGlobalRoutingModule } from './device-management-global-routing.module';


//Components
// import { ProductIdentificationComponent } from './expert-setting/product-identification/product-identification';
// import { CameraComponent } from './expert-setting/camera/camera';
// import { BeamerComponent } from './expert-setting/beamer/beamer';
// import { HandTrackingComponent } from './expert-setting/hand-tracking/hand-tracking';

@NgModule({
  imports: [
    DeviceManagementGlobalRoutingModule,
    CommonModule,
    FormsModule,
    Ng2SmartTableModule,
    TranslateModule,
    TabsModule.forRoot(),
    ModalModule.forRoot(),
    PaginationModule.forRoot()
  ],
  declarations: [ DeviceManagementGlobalComponent ]
})
export class DeviceManagementGlobalModule { }
