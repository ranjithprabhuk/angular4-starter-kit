import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DeviceManagementGlobalComponent } from './device-management-global.component';

const routes: Routes = [
  {
    path: '',
    component: DeviceManagementGlobalComponent,
    data: {
      title: 'Device Management Global'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DeviceManagementGlobalRoutingModule {}
