import { Component, Input, Output, EventEmitter } from '@angular/core';

import { Grid } from '../../../lib/grid';

@Component({
  selector: 'ng2-st-actions',
  template: `
    <a href="#" class="ng2-smart-action ng2-smart-action-add-create"
        [innerHTML]="grid.getSetting('add.createButtonContent')"
        (click)="$event.preventDefault();create.emit($event)"></a>
    <a href="#" class="ng2-smart-action ng2-smart-action-add-cancel"
        [innerHTML]="grid.getSetting('add.cancelButtonContent')"
        (click)="$event.preventDefault();grid.createFormShown = false;grid.resetData();"></a>
  `,
})
export class ActionsComponent {

  @Input() grid: Grid;
  @Output() create = new EventEmitter<any>();

  ngAfterViewChecked() {
    this.customiseNumberField();
  }

  customiseNumberField(){
     //console.log("checking event",event);
    /* adding code to restrict input field with type number (excluding e,.,+,-) */
    let inputHTMLComponent=document.getElementsByTagName("input");
    //console.log("list input control",inputHTMLComponent);
    let newCopy=inputHTMLComponent;

    //console.log("calling method",inputHTMLComponent);
    //console.log("copied array method",newCopy);
    for(let i=0;i<newCopy.length;i++)
    {
      //console.log("checking loop",newCopy[i]);
        if(newCopy[i].type=="number"){
           // console.log("condition check");
            newCopy[i].min="0";
            newCopy[i].onkeypress=function(event){
              return event.charCode >= 48 && event.charCode <= 57;
            }
        }
    }
  }
}
