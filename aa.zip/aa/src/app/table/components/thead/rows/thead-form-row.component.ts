import { Component, Input, Output, EventEmitter } from '@angular/core';

import { Grid } from '../../../lib/grid';
import { Row } from '../../../lib/data-set/row';

@Component({
  selector: '[ng2-st-thead-form-row]',
  template: `
      <td *ngIf="grid.isMultiSelectVisible()"></td>
      <td  *ngIf= "grid.showActionColumn('left') && grid.getSetting('actions.actions')"  class="ng2-smart-actions">
        <ng2-st-actions [grid]="grid" (create)="onCreate($event)"></ng2-st-actions>
      </td>
      <td *ngFor="let cell of grid.getNewRow().getCells()">
        <ng2-smart-table-cell [cell]="cell"
                              [grid]="grid"
                              [isNew]="true"
                              [createConfirm]="createConfirm"
                              [inputClass]="grid.getSetting('add.inputClass')"
                              [isInEditing]="grid.getNewRow().isInEditing"
                              (edited)="onCreate($event)"
                              (CellClick)="onCellClick($event)">
        </ng2-smart-table-cell>
      </td>
      <td  *ngIf= "grid.showActionColumn('right') && grid.getSetting('actions.actions')"  class="ng2-smart-actions">
        <ng2-st-actions [grid]="grid" (create)="onCreate($event)"></ng2-st-actions>
      </td>
  `,
})
export class TheadFormRowComponent {

  @Input() grid: Grid;
  @Input() row: Row;
  @Input() createConfirm: EventEmitter<any>;

  @Output() create = new EventEmitter<any>();
  @Output() CellClick = new EventEmitter<any>();

  onCellClick(event) {
    this.CellClick.emit(event);
  };

  onCreate(event: any) {
    event.stopPropagation();

    this.grid.create(this.grid.getNewRow(), this.createConfirm);
  }

}
