export interface ViewCell {
  value: string | number;
}
