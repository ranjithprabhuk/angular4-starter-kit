import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ModalDirective } from 'ng2-bootstrap/modal';
import { TabsetComponent } from 'ng2-bootstrap';
import { Ng2SmartTableModule, LocalDataSource } from '../table';
import { TranslateService,TranslationChangeEvent } from '@ngx-translate/core';
import { AnalyticsConfig } from './analytics-config';
import { AnalyticsService } from './analytics.service';
import { AppConfig } from '../app.config';

declare var $: any;

import { ToastrService } from 'ngx-toastr';
import { ToastConfig } from 'ngx-toastr';

@Component({
  templateUrl: 'analytics.component.html',
  styleUrls: ['./analytics.component.css'],
  providers: [AnalyticsService]
})

export class AnalyticsComponent {
   public analyticsConfig = new AnalyticsConfig();
   public appConfig=new AppConfig();
   public settingsOrderOverView: any = this.analyticsConfig.OrderOverViewSettings;
   public settingsProductAssembly: any = this.analyticsConfig.ProductAssemblySettings;
   public settingsHeatMap: any = this.analyticsConfig.HeatMapSettings;
   
   public selectedTab: String = 'ANALITICS.DASHBOARD';
   public listOrderOverViewData: LocalDataSource;

     constructor(private analyticsService: AnalyticsService, private translate: TranslateService, private notificationService: ToastrService) {
          this.listOrderOverViewData = new LocalDataSource();
          this.translate.onLangChange.subscribe((event: TranslationChangeEvent) => {
        //  this.doTranslate();
    });
  }
  ngAfterViewInit() {
    
    $(".from_datetime").datetimepicker({
        format: this.appConfig.dateFormat,
        autoclose: true,
        todayBtn: true,
        minuteStep: 10,
        pickerPosition: "bottom-left"
    });
  }
  // ActiveAssistID DropDown
  public selectedActiveAssistIdLG: String;
  public selectedActiveAssistIdBC: String;
  public selectedProductionLine: String;
  public activeAssistIdListLG: Array<String>;
  public activeAssistIdListBC: Array<String>;
  public productionLine: Array<String>;

  // lineChart
  public orderLineChartQuantity: Array<any> = [];
  public orderLineChartTime: Array<any> = [];
  public lineDataReady=false;
  public lineChartData: Array<any> = [
    {data: [65, 59, 80, 81, 56, 55, 40]}
    // {data: [28, 48, 40, 19, 86, 27, 90], label: 'Series B'},
    // {data: [18, 48, 77, 9, 100, 27, 40], label: 'Series C'}
  ];
  public lineChartLabels: Array<any> = ['January', 'February', 'March', 'April', 'May', 'June', 'July'];
  public lineChartOptions: any = {
    animation: false,
    responsive: true
  };
  public lineChartColours: Array<any> = [
    // { // grey
    //   backgroundColor: 'rgba(148,159,177,0.2)',
    //   borderColor: 'rgba(148,159,177,1)',
    //   pointBackgroundColor: 'rgba(148,159,177,1)',
    //   pointBorderColor: '#fff',
    //   pointHoverBackgroundColor: '#fff',
    //   pointHoverBorderColor: 'rgba(148,159,177,0.8)'
    // },
    { // dark grey
      backgroundColor: 'rgba(77,83,96,0.2)',
      borderColor: 'rgba(77,83,96,1)',
      pointBackgroundColor: 'rgba(77,83,96,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(77,83,96,1)'
    }
    //,
    // { // grey
    //   backgroundColor: 'rgba(148,159,177,0.2)',
    //   borderColor: 'rgba(148,159,177,1)',
    //   pointBackgroundColor: 'rgba(148,159,177,1)',
    //   pointBorderColor: '#fff',
    //   pointHoverBackgroundColor: '#fff',
    //   pointHoverBorderColor: 'rgba(148,159,177,0.8)'
    // }
  ];
  public lineChartLegend: boolean = false;
  public lineChartType: string = 'line';

  // barChart
  public barChartOptions: any = {
    scaleShowVerticalLines: false,
    responsive: true
  };
  public barChartLabels: string[] = ['2006', '2007', '2008', '2009', '2010', '2011', '2012'];
  public barChartType: string = 'bar';
  public barChartLegend: boolean = true;

  public barChartData: any[] = [
    {data: [65, 59, 80, 81, 56, 55, 40], label: 'Series A'},
    {data: [28, 48, 40, 19, 86, 27, 90], label: 'Series B'}
  ];

  public barChartDataHeatMap: any[] = [
 //   {data: [65, 59, 80, 81, 56, 55, 40], label: 'Series B'},
    {data: [28, 48, 40, 19, 86, 27, 90], label: 'Series A'}
  ];


  // Radar
  public radarChartLabels: string[] = ['Eating', 'Drinking', 'Sleeping', 'Designing', 'Coding', 'Cycling', 'Running'];

  public radarChartData: any = [
    {data: [65, 59, 90, 81, 56, 55, 40], label: 'Series A'},
    {data: [28, 48, 40, 19, 96, 27, 100], label: 'Series B'}
  ];
  public radarChartType: string = 'radar';

  // events
  public chartClicked(e: any): void {
    console.log(e);
  }

  public chartHovered(e: any): void {
    console.log(e);
  }

   public callGetAPILG(newValue):void{
      this.selectedActiveAssistIdLG=newValue;
  };
   public callGetAPIBC(newValue):void{
      this.selectedActiveAssistIdBC=newValue;
  };
  public callGetAPIPL(newValue):void{
      this.selectedProductionLine=newValue;
  };
//Static data
//Virtual Areas Tab Data
  // public _orderOverViewData = [
  //   {
  //     activeAssistName: "A1",
  //     customerorder: "1111",
  //       productionorder:"22333",
  //       productionnumber: "34566",
  //       quantity: 1,
  //       priorityNumber: "23445",
  //       productionline:"7899",
  //       schedulestarttime:"10/10/2015, 00,04.03" ,
  //       scheduleendtime: "10/10/2015, 00,04.03" ,
  //       actualstarttime: "10/10/2015, 00,04.03" ,
  //           actualendtime: "10/10/2015, 00,04.03" ,
  //         progressstatus: "online"
  //   },
  //    {
  //     activeAssistName: "A1",
  //     customerorder: "1111",
  //       productionorder:"22333",
  //       productionnumber: "34566",
  //       quantity: 1,
  //       priorityNumber: "23445",
  //       productionline:"7899",
  //       schedulestarttime:"10/10/2015, 00,04.03" ,
  //       scheduleendtime: "10/10/2015, 00,04.03" ,
  //       actualstarttime: "10/10/2015, 00,04.03" ,
  //           actualendtime: "10/10/2015, 00,04.03" ,
  //         progressstatus: "online"
  //   },
  //   {
  //     activeAssistName: "A1",
  //     customerorder: "1111",
  //       productionorder:"22333",
  //       productionnumber: "34566",
  //       quantity: 1,
  //       priorityNumber: "23445",
  //       productionline:"7899",
  //       schedulestarttime:"10/10/2015, 00,04.03" ,
  //       scheduleendtime: "10/10/2015, 00,04.03" ,
  //       actualstarttime: "10/10/2015, 00,04.03" ,
  //           actualendtime: "10/10/2015, 00,04.03" ,
  //         progressstatus: "online"
  //   },
  //    {
  //     activeAssistName: "A1",
  //     customerorder: "1111",
  //       productionorder:"22333",
  //       productionnumber: "34566",
  //       quantity: 1,
  //       priorityNumber: "23445",
  //       productionline:"7899",
  //       schedulestarttime:"10/10/2015, 00,04.03" ,
  //       scheduleendtime: "10/10/2015, 00,04.03" ,
  //       actualstarttime: "10/10/2015, 00,04.03" ,
  //           actualendtime: "10/10/2015, 00,04.03" ,
  //         progressstatus: "online"
  //   }
  // ];

  public productOverViewData=[
    {
        productordernumber:"12333",
        aaid: "2345",
        productnumber: "2345",     
        productserialnumber:"4567",
        materialname: "MM6",
        stepname:"www",
        stepdescription: "description",
        reasoncode: "009",
        starttime:"10/10/2015, 00,04.03",
        endtime: "10/10/2015, 00,04.03",
          
    },
       {
        productordernumber:"12333",
        aaid: "2345",
        productnumber: "2345",     
        productserialnumber:"4567",
        materialname: "MM6",
        stepname:"www",
        stepdescription: "description",
        reasoncode: "009",
        starttime:"10/10/2015, 00,04.03",
        endtime: "10/10/2015, 00,04.03",
          
    },
       {
        productordernumber:"12333",
        aaid: "2345",
        productnumber: "2345",     
        productserialnumber:"4567",
        materialname: "MM6",
        stepname:"www",
        stepdescription: "description",
        reasoncode: "009",
        starttime:"10/10/2015, 00,04.03",
        endtime: "10/10/2015, 00,04.03",
          
    },
       {
        productordernumber:"12333",
        aaid: "2345",
        productnumber: "2345",     
        productserialnumber:"4567",
        materialname: "MM6",
        stepname:"www",
        stepdescription: "description",
        reasoncode: "009",
        starttime:"10/10/2015, 00,04.03",
        endtime: "10/10/2015, 00,04.03",
          
    }
  ];
  public hetMapOverViewData=[
    {
        aaid:"AA45",
        customerorder: "10",
        productionorderno:"008",          
        productnumber: "56",
        railno: "67",
        boxno:"76",
        material: "push button",
        noofpicks: "12",
        timeofpick: "6"         
    },
       {
        aaid:"AA45",
        customerorder: "10",
        productionorderno:"008",          
        productnumber: "56",
        railno: "67",
        boxno:"76",
        material: "push button",
        noofpicks: "12",
        timeofpick: "6"         
    },
       {
        aaid:"AA45",
        customerorder: "10",
        productionorderno:"008",          
        productnumber: "56",
        railno: "67",
        boxno:"76",
        material: "push button",
        noofpicks: "12",
        timeofpick: "6"         
    },
  ];

  public  fromDate:String;
  public  toDate:String;
 
  //Get orderoverview Report data
   public getOrderOverViewReport(pagination): void {
 console.log(this.fromDate,this.toDate, "from date and to date");
    let _pagination = pagination || this.settingsOrderOverView.serverSidePagination;
   
    console.log("pagination page",_pagination.page);
        this.analyticsService.getOrderOverViewReport(_pagination, this.fromDate,this.toDate).then(res => {
           this.listOrderOverViewData.load(res.content);
          this.settingsOrderOverView.serverSidePagination.totalItems = res.size;
        }).catch(err => { console.log("Error: ", err); });
     }




     //Get order over view Excel 
public getOrderOverViewExcelReport(): void {
 console.log(this.fromDate,this.toDate, "from date and to date");
        this.analyticsService.getOrderOverViewExcel( "",this.fromDate,this.toDate).then(res => {
          this.listOrderOverViewData=res;
        }).catch(err => { console.log("Error: ", err); });
     }
     


     //Pagination for orderoverview Report
    public pageChangedOrderOverView(pagination): void {
      console.log("UID pagination ", pagination);
      this.getOrderOverViewReport(pagination);
    };

    //Get List of Active Assist
      public getAllActiveAssistID(): void {
        this.analyticsService.getAllActiveassist().then(res => {
          this.activeAssistIdListBC = res;
          this.activeAssistIdListLG = res;
        });
      };
    //Get List of Production Line
    public getAllProductionLine(): void {
      this.analyticsService.getAllProductionLines().then(res => {
        this.productionLine=res;
      });
    };
    //Get Line Graph Overview
     public getLineGraphData(): void {
      this.analyticsService.getLineGraph().then(res => {
        console.log("line chart",res);
        let resdata=res;
        let q=[];
        for(let i=0;i<resdata.length;i++)
        {
            q[i]=resdata[i].quantity;
            let d=new Date(resdata[i].date);
            let month=this.getMonthName(d.getMonth()+1);
            this.orderLineChartTime.push(month);
        }
        this.orderLineChartQuantity[0]={data:q};
        console.log("checkkkk",this.orderLineChartQuantity[0]);
        this.lineDataReady=true;
        console.log("data ready",this.lineDataReady);
      });
    };
    public getMonthName(num):String{
       //['January', 'February', 'March', 'April', 'May', 'June', 'July']
      switch(num)
      {
          case 1: return "January";
          case 2: return "February";
          case 3: return "March";
          case 4: return "April";
          case 5: return "May";
          case 6: return "June";
          case 7: return "July";
          case 8: return "August";
          case 9: return "September";
          case 10: return "October";
          case 11: return "November";
          case 12: return "December";
      }
      return "";
    }
    ngOnInit(){
       this.selectedActiveAssistIdBC="all";
       this.selectedActiveAssistIdLG="all";
       this.selectedProductionLine="allPL";
       this.getAllActiveAssistID();
       this.getAllProductionLine();
       this.getLineGraphData();
       console.log("arr",this.orderLineChartQuantity,this.orderLineChartTime);
    }
  };

