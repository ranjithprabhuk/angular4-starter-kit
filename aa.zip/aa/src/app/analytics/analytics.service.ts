import { Injectable } from '@angular/core';
import { URLSearchParams } from '@angular/http';
import { ApiService } from '../app.service';

import 'rxjs/add/operator/toPromise';


@Injectable()
export class AnalyticsService {

    constructor(private apiService: ApiService) {
     //  this.getDetails();
    }

    //protected apiEndPoint: string = this.apiService.baseUrl.assemblyManagementServicePort +"/";
    protected apiEndPoint: string = "";

    public host = "dataAnalyticsService";

    getDetails(): void {
        this.getExternalProperties().then((res) => {
            this.apiEndPoint = res.dataAnalyticsServicePort + "/";
        });
    }

    getExternalProperties(): Promise<any> {
        return this.apiService.getExternalApplicationProperties().then(res => { return Promise.resolve(res) });
    }

/*  Get order over view report  */
    getOrderOverViewReport(parameter?:any, from?:any, to?:any ): Promise<any> {
        let params: URLSearchParams = new URLSearchParams();
        parameter.page = parameter.page - 1;
        params.append("page", parameter.page);
        params.append("size", parameter.itemsPerPage);
        params.append("from",from);
        params.append("to",to);
        return this.apiService.get(this.host, this.apiEndPoint + "getOrderOverviewReport?" + params)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    /*  Get order over view Excel  */
    getOrderOverViewExcel(parameter?: any, fromDate?:any, toDate?:any ): Promise<any> {
        let params: URLSearchParams = new URLSearchParams();
        //parameter.page = parameter.page - 1;
    //    params.append("page", parameter.page);
      //  params.append("size", parameter.itemsPerPage);
        params.append("from",fromDate);
        params.append("to",toDate);
        return this.apiService.get(this.host, this.apiEndPoint + "getOrderOverviewReportExcel?" + params)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }
    /**
     * Dashboard API's 
     * getAllActiveassist - get all AAID for dropdown
     * getAllProductionLines - get all Production Lines
     * getLineGraph - get line graph data
     * 
     */
    getAllActiveassist(parameter?: any): Promise<any> {
        let params: URLSearchParams = new URLSearchParams();
        return this.apiService.get(this.host, this.apiEndPoint + "getAllActiveAssists")
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }
    getAllProductionLines(parameter?: any): Promise<any> {
        let params: URLSearchParams = new URLSearchParams();
        return this.apiService.get(this.host, this.apiEndPoint + "getAllProductionLines")
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }
    getLineGraph(parameter?: any): Promise<any> {
        let params: URLSearchParams = new URLSearchParams();
        return this.apiService.get(this.host, this.apiEndPoint + "lineGraphDefaultOverview")
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }
}