    export class AnalyticsConfig {

    //pagination  settings
    public paginationSettings: Object = {
            display: false,
            perPage: 10
    };
    //table configuration for Active Assist Tab
    public OrderOverViewSettings: Object = {
    actions: {
        columnTitle: 'Actions',
        add: false,
        edit: false,
        delete: false,
        copy: false,
        move: false,
        position: 'left', // left|right
    },
     columns: {
         activeAssistId: {
            title: 'AA Name ',
            minWidth: "200px"
        },
        customerOrderNumber: {
            title: 'Customer Order',
            minWidth: "200px"
        },
        productionOrderNumber: {
            title: 'Production Order',
            minWidth: "100px"
        },
           
        name: {
            title: 'Product No',
            minWidth: "100px"
        },
        quantity: {
            title: 'Quantity',
            minWidth: "150px",
             type:'number'
        },
       
        line: {
            title: 'Production Line',            
            minWidth: "100px"
        }, 
        plannedStartDate: {
            title: 'schedule Start Time (DD/MM/YYYY, HH,MM,SS)',
           
            minWidth: "100px"
        }, 
        plannedEndDate: {
            title: 'Schedule End Time (DD/MM/YYYY, HH,MM,SS)',
            minWidth: "50px",
          
           
        },
        productionOrderStartDate: {
            title: 'Actual Start Time (DD/MM/YYYY, HH,MM,SS)',
            minWidth: "50px",         
        }, 
            productionOrderEndDate: {
            title: 'Actual End Time (DD/MM/YYYY, HH,MM,SS)',
            minWidth: "50px",     
        },
          productStatus: {
            title: 'Progress Status',
            minWidth: "50px",                      
        },
           
     },   
        pager: this.paginationSettings,
        serverSidePagination: {
            itemsPerPage: 10,
            page: 1,
            totalItems: 0
        }
    };

     public ProductAssemblySettings: Object = {
    actions: {
        columnTitle: 'Actions',
        add: false,
        edit: false,
        delete: false,
        copy: false,
        move: false,
        position: 'left', // left|right
    },
     columns: {
         productordernumber: {
            title: 'Product Order No. ',
            minWidth: "200px"
        },
        aaid: {
            title: 'AA ID/AA Name',
            minWidth: "200px"
        },
        productnumber: {
            title: 'Product No',
            minWidth: "100px"
        },
            plant: {
            title: 'Plant',
            minWidth: "70px"
        },
        productserialnumber: {
            title: 'Product Serial No.',
            minWidth: "100px"
        },
        materialname: {
            title: 'Material Name',
            minWidth: "150px",
             type:'number'
        },
        stepname: {
            title: 'Step Name',
             type:'number',
            minWidth: "70px"
        },
        stepdescription: {
            title: 'Step Description',            
            minWidth: "100px"
        }, 
        reasoncode: {
            title: 'Reason Code',
           
            minWidth: "100px"
        }, 
        starttime: {
            title: 'Start Time (DD/MM/YYYY, HH,MM,SS)',
            minWidth: "50px",
          
           
        },
        endtime: {
            title: 'End Time (DD/MM/YYYY, HH,MM,SS)',
            minWidth: "50px",         
        }, 
            
     },   
        pager: this.paginationSettings,
        serverSidePagination: {
            itemsPerPage: 10,
            page: 1,
            totalItems: 0
        }
    };
      public HeatMapSettings: Object = {
    actions: {
        columnTitle: 'Actions',
        add: false,
        edit: false,
        delete: false,
        copy: false,
        move: false,
        position: 'left', // left|right
    },
     columns: {
         aaid: {
            title: 'AA ID ',
            minWidth: "200px"
        },
        customerorder: {
            title: 'Customer Order',
            minWidth: "200px"
        },
        productionorderno: {
            title: 'Production Order No. ',
            minWidth: "100px"
        },
            plant: {
            title: 'Plant',
            minWidth: "70px"
        },
        productnumber: {
            title: 'Product Number',
            minWidth: "100px"
        },
        railno: {
            title: 'Rail Number',
            minWidth: "150px",
             type:'number'
        },
        boxno: {
            title: 'Box Number',
             type:'number',
            minWidth: "70px"
        },
        material: {
            title: 'Material',            
            minWidth: "100px"
        }, 
        noofpicks: {
            title: 'Number Of Picks',
           
            minWidth: "100px"
        }, 
        timeofpick: {
            title: 'Time Of Picks',
            minWidth: "50px",
          
           
        },
        
           
     },   
        pager: this.paginationSettings,
        serverSidePagination: {
            itemsPerPage: 10,
            page: 1,
            totalItems: 0
        }
    };
    }