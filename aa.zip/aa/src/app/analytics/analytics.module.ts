
import { ChartsModule } from 'ng2-charts/ng2-charts';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
//import { TabsModule,ModalModule } from 'ng2-bootstrap';
import { Ng2SmartTableModule } from '../table';
import { TranslateModule } from '@ngx-translate/core';
import { TabsModule,ModalModule, PaginationModule } from 'ng2-bootstrap';

import { AnalyticsComponent } from './analytics.component';
import { AnalyticsRoutingModule } from './analytics-routing.module';

@NgModule({
  imports: [
    AnalyticsRoutingModule,
    ChartsModule,
    CommonModule,
    FormsModule,
    Ng2SmartTableModule,
    TranslateModule,
    TabsModule.forRoot(),
    ModalModule.forRoot(),
    PaginationModule.forRoot()
  ],
  declarations: [ AnalyticsComponent ]
})
export class AnalyticsModule { }
