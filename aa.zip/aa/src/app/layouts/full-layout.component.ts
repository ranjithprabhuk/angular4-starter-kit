import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppConfig } from '../app.config';
import { TranslateService, TranslationChangeEvent } from '@ngx-translate/core';
import { AuthenticationService } from '../authentication/authentication.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './full-layout.component.html',
  styleUrls: ['./full-layout.component.css']
})
export class FullLayoutComponent implements OnInit {

  public appConfig = new AppConfig();
  public selectedLanguage: String = this.appConfig.languageName;
  public selectedLanguageCode: String = this.appConfig.languageCode;
  public userPermissions : boolean = false;
  public callForHelpPermissions : boolean = false;
  public viewSystemFailure : boolean = false;
  public userId: number = 0;

  constructor(private translate: TranslateService, private router: Router, private authService: AuthenticationService) {
    this.checkPermissions();
    translate.addLangs(["en", "de"]);
    translate.setDefaultLang(this.appConfig.languageCode);

    let browserLang = translate.getBrowserLang();
    translate.use(browserLang.match(/en|de/) ? browserLang : this.appConfig.languageCode);
    this.userId = parseInt(localStorage.getItem('userId'));
  }

  public languagesList: Array<Object> = [];

  public disabled: boolean = false;
  public status: { isopen: boolean } = { isopen: false };

  public toggled(open: boolean): void {
    console.log('Dropdown is now: ', open);
    //this.doTranslate();
  }

  public toggleDropdown($event: MouseEvent): void {
    $event.preventDefault();
    $event.stopPropagation();
    this.status.isopen = !this.status.isopen;
  }

  //to logou from the system
  public logout(): void {
    localStorage.removeItem('auth_token');
    this.router.navigate(['/login']);
  }

  ngOnInit(): void {
    this.doTranslate();
    this.translate.onLangChange.subscribe((event: TranslationChangeEvent) => {
      this.doTranslate();
    });
  }

  doTranslate() {
    this.languagesList = [];
    this.languagesList.push({ "key": "en", "name": this.translate.instant("LANGUAGES.ENGLISH") });
    this.languagesList.push({ "key": "de", "name": this.translate.instant("LANGUAGES.GERMAN") });
    this.selectedLanguage = this.getSelectedLanguage(this.selectedLanguageCode);
  }

  getSelectedLanguage(key): string {
    for (let i = 0; i < this.languagesList.length; i++) {
      let language: any = this.languagesList[i];
      if (language.key == key) {
        return language.name;
      }
    }
  }

  //navigate to user profile
  navigateToUserProfile(): void {
    if(this.userPermissions){
      this.router.navigate(['/userprofile/'+this.userId]);
    }
  }

  public checkPermissions(): void {
    if (this.authService.appPermissions != undefined) {
      this.userPermissions = this.authService.appPermissions["Change Personal Settings"];
      this.callForHelpPermissions = this.authService.appPermissions["Call for help"];
      this.viewSystemFailure = this.authService.appPermissions["View Systemfailures and infos"];
    } else {
      this.authService.logout();
    }
  }
}
