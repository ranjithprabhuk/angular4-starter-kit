import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { LocationStrategy, HashLocationStrategy } from '@angular/common';
import { HttpModule, Http } from '@angular/http';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';

import { AppComponent } from './app.component';
import { LoaderComponent, LoaderService } from './shared/loader';
import { DropdownModule } from 'ng2-bootstrap/dropdown';
import { TabsModule } from 'ng2-bootstrap/tabs';
import { ModalModule } from 'ng2-bootstrap/modal';
import { NAV_DROPDOWN_DIRECTIVES } from './shared/nav-dropdown.directive';
import { PaginationModule } from 'ng2-bootstrap';


import { ChartsModule } from 'ng2-charts/ng2-charts';
import { SIDEBAR_TOGGLE_DIRECTIVES } from './shared/sidebar.directive';
import { AsideToggleDirective } from './shared/aside.directive';
import { BreadcrumbsComponent } from './shared/breadcrumb.component';

//Authentication Module
import { AuthenticationModule } from './authentication/authentication.module'

//Device Management Module
import { DeviceManagementModule } from './device-management/device-management.module'

//Device Management Global Module
import { DeviceManagementGlobalModule } from './device-management-global/device-management-global.module'

//Device Management Global Module
import { DeviceManagementLocalModule } from './device-management-local/device-management-local.module'
//Worker Module
import { WorkerModule } from './worker/worker.module'

//shared Module
import { SharedModule } from './shared/shared.module';

// Routing Module
import { AppRoutingModule } from './app.routing';

// Layouts
import { FullLayoutComponent } from './layouts/full-layout.component';

//Service
import { ApiService } from './app.service';

// AoT requires an exported function for factories
export function HttpLoaderFactory(http: Http) {
  return new TranslateHttpLoader(http);
}

@NgModule({
  imports: [
    BrowserModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [Http]
      }
    }),
    HttpModule,
    AppRoutingModule,
    DropdownModule.forRoot(),
    TabsModule.forRoot(),
    ModalModule.forRoot(),
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
    PaginationModule.forRoot(),
    ChartsModule,
    AuthenticationModule,
    WorkerModule,
    DeviceManagementModule,
    DeviceManagementGlobalModule,
    DeviceManagementLocalModule,
    SharedModule
  ],
  declarations: [
    AppComponent,
    LoaderComponent,
    FullLayoutComponent,
    BreadcrumbsComponent
  ],
  exports: [SharedModule  ],
  providers: [{
    provide: LocationStrategy,
    useClass: HashLocationStrategy
  }, ApiService, LoaderService],
  bootstrap: [AppComponent]
})
export class AppModule { }
