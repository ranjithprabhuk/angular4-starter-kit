import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { TabsModule,ModalModule } from 'ng2-bootstrap';





import { AuthenticationComponent } from './authentication.component';
import { AuthenticationRoutingModule } from './authentication-routing.module';

@NgModule({
  imports: [
    FormsModule,
    AuthenticationRoutingModule,
     ModalModule.forRoot()
  ],
  declarations: [ AuthenticationComponent ]
})
export class AuthenticationModule { }