import { Injectable } from '@angular/core';
import { ApiService } from '../app.service';
import { ToastrService } from 'ngx-toastr';
import { AppConfig } from '../app.config';

import { TranslateService, TranslationChangeEvent } from '@ngx-translate/core';
import { Router } from '@angular/router';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/delay';

@Injectable()
export class AuthenticationService {

    constructor(private apiService: ApiService, private notificationService: ToastrService, private translate: TranslateService, public router: Router) {
        //this.appPermissions = new AppConfig().permissions;
        this.appPermissions = JSON.parse(localStorage.getItem('permissions')) || undefined;
    }

    //protected apiEndPoint: string = this.apiService.baseUrl.userManagementServicePort +"/";
    protected apiEndPoint: string = "";

    public host = "userManagementService";
    //public appPermissions: any = undefined;
    public appPermissions: any = undefined;
    public userDetails: any = undefined;

    getDetails(): void {
        this.getExternalProperties().then((res) => {
            this.apiEndPoint = res.userManagementServicePort + "/";
        });
    }

    getExternalProperties(): Promise<any> {
        return this.apiService.getExternalApplicationProperties().then(res => { return Promise.resolve(res) });
    }

    //to save a new Product Type
    login(parameter?: any): Promise<any> {
        return this.apiService.create(this.host, this.apiEndPoint + "authenticateUser", parameter)
            .then(res => {
                if (res == "LOGIN_SUCCESS") {
                    localStorage.setItem('auth_token', res.data);
                    return Promise.resolve(res);
                } else {
                    this.notificationService.error("Kindly check your credentials")
                    return Promise.reject(res);
                }
            })
            .catch(err => { return Promise.reject(err) });
    }

    //to authenticate the user
    authenticateService(parameter?: any): Promise<any> {
        return this.apiService.create(this.host, this.apiEndPoint + "authenticateUserAndFetchPermissionMatrix", parameter)
            .then(res => {
                if (res.loginResult == "LOGIN_SUCCESS") {
                    if (this.isObjectEmpty(res.permissions)) {
                        if (res.permissions["User-Login"]) {
                            this.appPermissions = res.permissions;
                            console.log("permissions>>", this.appPermissions);
                            this.userDetails = res.user;

                            //store the required data in local storage
                            localStorage.setItem('permissions', JSON.stringify(res.permissions));
                            localStorage.setItem('auth_token', res);
                            localStorage.setItem('userId', res.user != null ? res.user.id : '0');
                            return Promise.resolve(res);
                        }else{
                            this.notificationService.error("You dont have permission to login into the application");
                        }
                    } else {
                        this.notificationService.error("Permissions are not available, kindly check with your administrator");
                        return Promise.reject(res);
                    }
                } else {
                    this.notificationService.error("Kindly check your credentials");
                    return Promise.reject(res);
                }
            })
            .catch(err => { return Promise.reject(err) });
    }

    //check empty object
    public isObjectEmpty(data): boolean {
        if (JSON.stringify(data) == '{}')
            return false;
        else
            return true;
    }

    //to save a new Product Type
    resetPassword(parameter?: any): Promise<any> {
        return this.apiService.create(this.host, this.apiEndPoint + "resetpassword", parameter)
            .then(res => {
                if (res == "RESET_SUCCESS") {
                    this.notificationService.success(res);
                    return Promise.resolve(res);
                } else {
                    this.notificationService.warning(res);
                    return Promise.reject(res);
                }
            })
            .catch(err => { return Promise.reject(err) });
    }

    //to logou from the system
    logout(): void {
        localStorage.removeItem('auth_token');
        localStorage.removeItem('permissions');
        localStorage.removeItem('userId');
        this.router.navigate(['/login']);
    }

    //to check the login status
    checkLogin(): boolean {
        //return true; //for demo purpose
        return !!localStorage.getItem('auth_token');
    }
}