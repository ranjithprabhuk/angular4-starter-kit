
import { Component, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from './authentication.service';
import { TranslateService } from '@ngx-translate/core';
import { ModalDirective } from 'ng2-bootstrap/modal';
import { Ng2SmartTableModule, LocalDataSource } from '../table';


@Component({
  templateUrl: 'authentication.component.html',
  styleUrls: ['./authentication.component.css'],
  providers: [AuthenticationService]
})
export class AuthenticationComponent {

  @ViewChild('resetPwdModal') public resetPwdModal: ModalDirective;
  constructor(private authService: AuthenticationService, public router: Router) { }

  private login: Object = {};
  private reset: Object = {};
  public isRemember: boolean = true;

  public options = {
    position: ["bottom", "left"],
    timeOut: 5000,
    lastOnBottom: true
  }

  //method to handle the sigin in
  public signIn(data: any): void {
    if (data && data.username && data.password) {
      //call the authService to chekc the credentials
      this.authService.authenticateService(data).then(res => {
        console.log("response>>", res);
        this.router.navigate(['/dashboard']);
      }).catch(err => { console.log("Error: ", err); });
    }
  }

  public showResetPassword(): void {

    this.resetPwdModal.show();
  }

  public hideChildModal(): void {
    this.resetPwdModal.hide();
    this.reset = {};
  }

  public resetPassword(data): void {
    if (data) {
      this.authService.resetPassword(data).then(res => {
        if (res == "RESET_SUCCESS") {
          this.hideChildModal();
        } 
      }).catch(err => { console.log("Error: ", err); });
    }
  }

  ngOnInit() {
    if (!!localStorage.getItem("auth_token")) {
      this.router.navigate(['/dashboard']);
    }
  }
}
