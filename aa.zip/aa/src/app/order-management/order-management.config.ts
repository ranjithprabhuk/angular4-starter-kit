import { TranslateService, TranslationChangeEvent } from '@ngx-translate/core';

import { AuthenticationService } from '../authentication/authentication.service';

export class OrderManagementConfig {
    constructor(private translate: TranslateService, private authService: AuthenticationService) {
        this.checkPermissions();
    }
    public tablePermissions: boolean = true;

    public checkPermissions(): void {
        if (this.authService.appPermissions == undefined) {
            this.authService.logout();
        }
    }

    public getOrderPermissions(): boolean {
        if (this.authService.appPermissions != undefined) {
            return this.authService.appPermissions["Change Orders"];
        } else {
            this.authService.logout();
        }
    }

    //pagination  settings
    public paginationSettings: Object = {
        display: false,
        perPage: 10
    };

    //table configuration for Orders Tab
    public OrdersSettings: Object = {
        actions: {
            columnTitle: '',
            add: this.getOrderPermissions(),
            edit: this.getOrderPermissions(),
            delete: this.getOrderPermissions(),
            copy: this.getOrderPermissions(),
            move: false,
            position: 'left', // left|right
        },
        columns: {
            customerOrderNumber: {
                title: this.translate.instant("ORDER_MANAGEMENT.ORDER_NUMBER"),
                filter: true,
                minWidth: "200px"
            },
            status: {
                title: this.translate.instant("ORDER_MANAGEMENT.ORDER_STATUS"),
                filter: true,
                minWidth: "200px",
                // editor: {
                //     type: 'list',
                //     config: {
                //         selectText: 'Select...',
                //         list: [
                //             { value: 'in_progress', title: 'in_progress' },
                //             { value: 'cancelled', title: 'cancelled' },
                //             { value: 'stopped', title: 'stopped' },
                //             { value: 'completed', title: 'completed' },
                //             { value: 'open', title: 'open' }
                //         ]
                //     }
                // },
                disabled: true
            },
            pos: {
                title: this.translate.instant("ORDER_MANAGEMENT.POS"),
                filter: true,
                minWidth: "100px",
                type: "number",
            },
            productionOrderNumber: {
                title: this.translate.instant("ORDER_MANAGEMENT.PRODUCTION_ORDER_NUMBER"),
                filter: true,
                minWidth: "200px"
            },
            productTypeNumber: {
                title: this.translate.instant("ORDER_MANAGEMENT.PRODUCT_TYPE_NUMBER"),
                filter: true,
                minWidth: "200px",
                editor: {
                    type: 'list',
                    config: {
                        selectText: "Select...",
                        list: [
                            { value: '', title: '' }
                        ]
                    }
                }
            },
            // name: {
            //     title: 'Product',
            //     filter: true,
            //     minWidth: "100px",
            //     editor: {
            //         type: 'list',
            //         config: {
            //             selectText: 'Select...',
            //             list: [
            //                 { value: '', title: '' }
            //             ],
            //         }
            //     }
            // },
            quantity: {
                title: this.translate.instant("ORDER_MANAGEMENT.QUANTITY"),
                filter: true,
                minWidth: "100px",
                type: "number"
            },
            unit: {
                title: this.translate.instant("ORDER_MANAGEMENT.UNIT"),
                filter: true,
                minWidth: "100px",
                editor: {
                    type: 'list',
                    config: {
                        selectText: 'Select...',
                        list: [
                            { value: 'piece', title: 'piece' }
                        ],
                    }
                }

            },
            plannedStartDate: {
                title: this.translate.instant("ORDER_MANAGEMENT.START_PLAN"),
                filter: true,
                minWidth: "200px",
                class: "startDatePicker",
                editor: {
                    type: "calendar"
                }
            },
            plannedEndDate: {
                title: this.translate.instant("ORDER_MANAGEMENT.END_PLAN"),
                filter: true,
                minWidth: "200px",
                class: "endDatePicker",
                editor: {
                    type: "calendar"
                }
            },
            productionOrderStartDate: {
                title: this.translate.instant("ORDER_MANAGEMENT.START"),
                filter: true,
                minWidth: "200px",
                disabled: true
            },
            productionOrderEndDate: {
                title: this.translate.instant("ORDER_MANAGEMENT.END"),
                filter: true,
                minWidth: "200px",
                disabled: true
            },
            activeAssistId: {
                title: 'AA ID',
                filter: true,
                minWidth: "200px",
                editor: {
                    type: 'list',
                    config: {
                        selectText: 'Select...',
                        list: [
                            { value: '', title: '' }
                        ],
                    }
                }
            },
            quantityCompleted: {
                title: this.translate.instant("ORDER_MANAGEMENT.CURRENT_QUANTITY"),
                filter: true,
                minWidth: "100px",
                disabled: true
            },
            stepInProgress: {
                title: this.translate.instant("ORDER_MANAGEMENT.STEP"),
                filter: true,
                minWidth: "100px",
                disabled: true
            },
            productStatus: {
                title: this.translate.instant("ORDER_MANAGEMENT.PRODUCT_ORDER_STATUS"),
                filter: true,
                minWidth: "200px",
                disabled: true
            }
        },
        pager: this.paginationSettings,
        serverSidePagination: {
            itemsPerPage: 10,
            page: 1,
            totalItems: 0
        }
    };

    //table configuration for UID Orders Tab
    public UidProductsSettings: Object = {
        actions: {
            columnTitle: '',
            add: this.getOrderPermissions(),
            edit: this.getOrderPermissions(),
            delete: this.getOrderPermissions(),
            copy: this.getOrderPermissions(),
            move: false,
            position: 'left', // left|right
        },
        columns: {
            productTypeNumber: {
                title: this.translate.instant("ORDER_MANAGEMENT.PRODUCT_TYPE_ID"),
                filter: true,
                editor: {
                    type: 'list',
                    config: {
                        selectText: "Select...",
                        list: [
                            { value: '', title: '' }
                        ]
                    }
                }
            },
            uid: {
                title: 'UID',
                filter: true
            },
            startDate: {
                title: this.translate.instant("ORDER_MANAGEMENT.START_DATE"),
                filter: true,
                class: "startDatePicker1",
                minWidth: "200px",
                editor: {
                    type: "calendar"
                }
            },
            endDate: {
                title: this.translate.instant("ORDER_MANAGEMENT.END_DATE"),
                filter: true,
                class: "endDatePicker1",
                minWidth: "200px",
                editor: {
                    type: "calendar"
                }
            }
        },
        pager: this.paginationSettings,
        serverSidePagination: {
            itemsPerPage: 10,
            page: 1,
            totalItems: 0

        }
    };

    //table configuration for Assign Orders Tab
    public AssignOrdersSettings: Object = {
        actions: {
            columnTitle: '',
            add: false,
            edit: false,
            delete: false,
            copy: false,
            move: false,
            position: 'left', // left|right
        },
        columns: {
            productionOrderNumber: {
                title: this.translate.instant("ORDER_MANAGEMENT.PRODUCTION_ORDER_NUMBER"),
                filter: true,
                disabled: true,
            },
            productTypeNumber: {
                title: this.translate.instant("ORDER_MANAGEMENT.PRODUCT_TYPE_NUMBER"),
                filter: true,
                disabled: true,

            },
            activeAssistId: {
                title: 'ActiveAssist ID',
                filter: true
            },
        },
        pager: this.paginationSettings,
        serverSidePagination: {
            totalItems: 0,
            page: 1,
            itemsPerPage: 10
        }
    }

    public updateSettings(productTypeNumberList,productTypeNumberListForUID,activeAssistList) {
        this.OrdersSettings = {
            actions: {
                columnTitle: '',
                add: true,
                edit: true,
                delete: true,
                copy: true,
                move: false,
                position: 'left', // left|right
            },
            columns: {
                customerOrderNumber: {
                    title: this.translate.instant("ORDER_MANAGEMENT.ORDER_NUMBER"),
                    filter: true,
                    minWidth: "200px"
                },
                status: {
                    title: this.translate.instant("ORDER_MANAGEMENT.ORDER_STATUS"),
                    filter: true,
                    minWidth: "200px",
                    // editor: {
                    //     type: 'list',
                    //     config: {
                    //         selectText: 'Select...',
                    //         list: [
                    //             { value: 'in_progress', title: 'in_progress' },
                    //             { value: 'cancelled', title: 'cancelled' },
                    //             { value: 'stopped', title: 'stopped' },
                    //             { value: 'completed', title: 'completed' },
                    //             { value: 'open', title: 'open' }
                    //         ]
                    //     }
                    // },
                    disabled: true
                },
                pos: {
                    title: this.translate.instant("ORDER_MANAGEMENT.POS"),
                    filter: true,
                    minWidth: "100px",
                    type: "number",
                },
                productionOrderNumber: {
                    title: this.translate.instant("ORDER_MANAGEMENT.PRODUCTION_ORDER_NUMBER"),
                    filter: true,
                    minWidth: "200px"
                },
                productTypeNumber: {
                    title: this.translate.instant("ORDER_MANAGEMENT.PRODUCT_TYPE_NUMBER"),
                    filter: true,
                    minWidth: "200px",
                    editor: {
                        type: 'list',
                        config: {
                            selectText: "Select...",
                            list: productTypeNumberList
                        }
                    }
                },
                // name: {
                //     title: 'Product',
                //     filter: true,
                //     minWidth: "100px",
                //     editor: {
                //         type: 'list',
                //         config: {
                //             selectText: 'Select...',
                //             list: [
                //                 { value: '', title: '' }
                //             ],
                //         }
                //     }
                // },
                quantity: {
                    title: this.translate.instant("ORDER_MANAGEMENT.QUANTITY"),
                    filter: true,
                    minWidth: "100px",
                    type: "number"
                },
                unit: {
                    title: this.translate.instant("ORDER_MANAGEMENT.UNIT"),
                    filter: true,
                    minWidth: "100px",
                    editor: {
                        type: 'list',
                        config: {
                            selectText: 'Select...',
                            list: [
                                { value: 'piece', title: 'piece' }
                            ],
                        }
                    }

                },
                plannedStartDate: {
                    title: this.translate.instant("ORDER_MANAGEMENT.START_PLAN"),
                    filter: true,
                    minWidth: "200px",
                    class: "startDatePicker",
                    editor: {
                        type: "calendar"
                    }
                },
                plannedEndDate: {
                    title: this.translate.instant("ORDER_MANAGEMENT.END_PLAN"),
                    filter: true,
                    minWidth: "200px",
                    class: "endDatePicker",
                    editor: {
                        type: "calendar"
                    }
                },
                productionOrderStartDate: {
                    title: this.translate.instant("ORDER_MANAGEMENT.START"),
                    filter: true,
                    minWidth: "200px",
                    disabled: true
                },
                productionOrderEndDate: {
                    title: this.translate.instant("ORDER_MANAGEMENT.END"),
                    filter: true,
                    minWidth: "200px",
                    disabled: true
                },
                activeAssistId: {
                    title: 'AA ID',
                    filter: true,
                    minWidth: "200px",
                    editor: {
                        type: 'list',
                        config: {
                            selectText: 'Select...',
                            list: activeAssistList,
                        }
                    }
                },
                quantityCompleted: {
                    title: this.translate.instant("ORDER_MANAGEMENT.CURRENT_QUANTITY"),
                    filter: true,
                    minWidth: "100px",
                    disabled: true
                },
                stepInProgress: {
                    title: this.translate.instant("ORDER_MANAGEMENT.STEP"),
                    filter: true,
                    minWidth: "100px",
                    disabled: true
                },
                productStatus: {
                    title: this.translate.instant("ORDER_MANAGEMENT.PRODUCT_ORDER_STATUS"),
                    filter: true,
                    minWidth: "200px",
                    disabled: true
                }
            },
            pager: this.paginationSettings,
            serverSidePagination: {
                itemsPerPage: 10,
                page: 1,
                totalItems: 0
            }
        };

        this.UidProductsSettings = {

            columns: {
                productTypeNumber: {
                    title: this.translate.instant("ORDER_MANAGEMENT.PRODUCT_TYPE_ID"),
                    filter: true,
                    editor: {
                        type: 'list',
                        config: {
                            selectText: "Select...",
                            list: productTypeNumberListForUID,
                        }
                    }
                },
                uid: {
                    title: 'UID',
                    filter: true
                },
                startDate: {
                    title: this.translate.instant("ORDER_MANAGEMENT.START_DATE"),
                    filter: true,
                    class: "startDatePicker1",
                    minWidth: "200px",
                    editor: {
                        type: "calendar"
                    }
                },
                endDate: {
                    title: this.translate.instant("ORDER_MANAGEMENT.END_DATE"),
                    filter: true,
                    class: "endDatePicker1",
                    minWidth: "200px",
                    editor: {
                        type: "calendar"
                    }
                }
            },
            pager: this.paginationSettings,
            serverSidePagination: {
                itemsPerPage: 10,
                page: 1,
                totalItems: 0

            }
        };

        this.AssignOrdersSettings = {
            actions: {
                columnTitle: '',
                add: false,
                edit: false,
                delete: false,
                copy: false,
                move: false,
                position: 'left', // left|right
            },
            columns: {
                productionOrderNumber: {
                    title: this.translate.instant("ORDER_MANAGEMENT.PRODUCTION_ORDER_NUMBER"),
                    filter: true,
                    disabled: true,
                },
                productTypeNumber: {
                    title: this.translate.instant("ORDER_MANAGEMENT.PRODUCT_TYPE_NUMBER"),
                    filter: true,
                    disabled: true,

                },
                activeAssistId: {
                    title: 'ActiveAssist ID',
                    filter: true
                },
            },
            pager: this.paginationSettings,
            serverSidePagination: {
                totalItems: 0,
                page: 1,
                itemsPerPage: 10
            }
        }
    }

}