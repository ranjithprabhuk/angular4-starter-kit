import { NgModule } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

import { TabsModule,ModalModule, PaginationModule } from 'ng2-bootstrap';
import { Ng2SmartTableModule } from '../smart-table';

import { TranslateModule } from '@ngx-translate/core';


import { OrderManagementComponent } from './order-management.component';
import { OrderManagementRoutingModule } from './order-management-routing.module';

@NgModule({
  imports: [
    OrderManagementRoutingModule,
    CommonModule,
    FormsModule,
    Ng2SmartTableModule,
    TranslateModule,
    TabsModule.forRoot(),
    ModalModule.forRoot(),
    PaginationModule.forRoot()
  ],
  declarations: [ OrderManagementComponent ]
})
export class OrderManagementModule { }
