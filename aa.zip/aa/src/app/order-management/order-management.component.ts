import { Component, ViewChild } from '@angular/core';

import { Ng2SmartTableModule, LocalDataSource } from '../smart-table';
import { ModalDirective } from 'ng2-bootstrap/modal';
import { TranslateService ,TranslationChangeEvent} from '@ngx-translate/core';
import { OrderManagementConfig } from './order-management.config';
import { OrderManagementService } from './order-management.service';
import { AuthenticationService } from '../authentication/authentication.service';

import { ToastrService } from 'ngx-toastr';
import { ToastConfig } from 'ngx-toastr';
import { AppConfig } from '../app.config';

const customConfig: ToastConfig = { enableHtml: true };
const customTimeOutMsg: ToastConfig={ timeOut: 8000 };
@Component({
  templateUrl: 'order-management.component.html',
  styleUrls: ['./order-management.component.css'],
  providers: [OrderManagementService]
})

export class OrderManagementComponent {
  @ViewChild('assignActiveAssistModal') public assignActiveAssistModal: ModalDirective;
  @ViewChild('ordersDeleteModal') public ordersDeleteModal: ModalDirective;
  @ViewChild('uidOrdersDeleteModal') public uidOrdersDeleteModal: ModalDirective;

  constructor(private orderManagementService: OrderManagementService, private translate: TranslateService, private notificationService: ToastrService,private authService: AuthenticationService) {
    this.orders = new LocalDataSource();
    this.uIdProducts = new LocalDataSource();
    this.assignOrders = new LocalDataSource();
    this.activeAssistIdList=[];
    this.translate.onLangChange.subscribe((event: TranslationChangeEvent) => {
          this.doTranslate();
    });
    console.log("after >>",this.orderSettings)
  }


  public orderManagementConfig = new OrderManagementConfig(this.translate,this.authService);
  public orderSettings: any = this.orderManagementConfig.OrdersSettings;
  public settingsUidProducts: any = this.orderManagementConfig.UidProductsSettings;
  public settingsAssignOrders: any = this.orderManagementConfig.AssignOrdersSettings;
  
  public assignOrdersCurrentPage: number;
  public ordersCurrentPageForDelete: number;
  public uidCurrentPageForDelete: number;

  public totalItems: number = 64;
  public currentPage: number = 1;
  public unitList: any;
  public productList: any;
  public aaidList:any;
  // add a property to the component
  public orders: LocalDataSource;
  public uIdProducts: LocalDataSource;
  public assignOrders: LocalDataSource;
  public selectedTab: String = 'ORDER_MANAGEMENT.HEADING';

  public selectedActiveAssistId: String;
  public activeAssistIdList: Array<String>;
  public selectedRow: any;
  public maxSize = new AppConfig().maxSize;

  productTypeNumberList : Array<any> =[
                                    { value: '', title: '' }
                                ];
  productTypeNumberListForUID : Array<any> =[
                                    { value: '', title: '' }
                                ];
  activeAssistList : Array<any> =[
                                    { value: '', title: '' }
                                ];
  doTranslate() {   
      this.orderManagementConfig.updateSettings(this.productTypeNumberList,this.productTypeNumberListForUID,this.activeAssistList);
      this.orders.refresh();     
   }

  /**
   * Order Table 
   * createOrders() - to create Orders
   * copyOrders() - to copy Orders
   * updateOrders() - to update/edit Orders
   * getOrders() - to get all the Orders list
   */

  /**257
    *Order Nr – mandatory
    *Status – auto filled as open on creation by backend, on update status dropdown list
    *Pos – number validation
    *Production Order Number – mandatory
    *Product – mandatory, product type dropdown list
    *Quantity – mandatory, number validation
    *Unit – unit dropdown list
    *Start Plan – date picker
    *End Plan – date picker
    *Start – disabled in frontend, autofilled by Backend on status change to in_progress
    *End – disabled in frontend, autofilled by Backend on status change to finished, cancelled, stopped
    *AA ID – active assist dropdown list of eligible active assists
    *Current Quantity - disabled in frontend, increased by backend, each time a product is finished
    *Step - disabled in frontend, show step in progress of current product
    *Status - disabled in frontend, show status of current product
   */
  //to create orders
  public createOrders(row: any): void {

    let flag_orders = false;
    console.log("col names in create: ", row.newData);//row.newData returns Object containing col names
    let Orderstable = row.newData;
    
    if(Orderstable["plannedStartDate"]==""){
        Orderstable["plannedStartDate"]=null;
    }
    if(Orderstable["plannedEndDate"]==""){
      Orderstable["plannedEndDate"]=null;
    }
    let _Ordersdata = {
      "customerOrderNumber": Orderstable["customerOrderNumber"],
      "status": "open",
      "pos": parseInt(Orderstable["pos"]),
      "productionOrderNumber": Orderstable["productionOrderNumber"],
      "productTypeNumber": Orderstable["productTypeNumber"],
      "name": Orderstable["name"],
      "quantity": Orderstable["quantity"],
      "unit": Orderstable["unit"],
      "plannedStartDate": Orderstable["plannedStartDate"],
      "plannedEndDate": Orderstable["plannedEndDate"],
      "productionOrderStartDate": null,
      "productionOrderEndDate": null,
      "activeAssistId": Orderstable["activeAssistId"],
      "quantityCompleted": parseInt(Orderstable["quantityCompleted"]),
      "stepInProgress": parseInt(Orderstable["stepInProgress"]),
      "productStatus": Orderstable["productStatus"]
    }
    if(_Ordersdata["customerOrderNumber"]==""&&_Ordersdata["productionOrderNumber"]==""&&_Ordersdata["productTypeNumber"]==""&&_Ordersdata["quantity"]=="")
    {
        flag_orders = true;
        this.notificationService.warning("Kindly fill the -</br>1)Order Number</br>2)Production Order Number</br>3)Product Type Number </br>4)Quantity","",customConfig);
        
    }
    else{
        for (let col in _Ordersdata) {
      
              if(col=="customerOrderNumber")
              {
                  if(_Ordersdata[col]==""){
                    flag_orders = true;
                    this.notificationService.warning("Kindly fill the Order Number");
                  }
                  if(_Ordersdata[col].length>40){
                    flag_orders = true;
                    this.notificationService.warning("Kindly fill Order Number not more than 40 characters");
                  }
              }
              if(col=="plannedEndDate")
              {
                  let startDate=new Date(_Ordersdata["plannedStartDate"]);
                  let endDate=new Date(_Ordersdata[col]);
                  console.log("start and end date",startDate,endDate);
                  if(endDate<startDate)
                  {
                      flag_orders = true;
                      this.notificationService.warning("End Plan Date and Time can't be earlier than Start Plan Date and Time");
                  }
                  /*if(endDate.getDate()<startDate.getDate())
                  {
                      flag_orders = true;
                      this.notificationService.warning("End Date is can't be earlier than the Start Date");
                  }
                  if((endDate.getMonth()+1)<(startDate.getMonth()+1))
                  {
                      flag_orders = true;
                      this.notificationService.warning("End Month can't be earlier than the Start Month");
                  }
                  if(endDate.getFullYear()<startDate.getFullYear())
                  {
                      flag_orders = true;
                      this.notificationService.warning("End Year can't be earlier than the Start Year");
                  }*/
              }
              
              if(col=="productionOrderNumber")
              {
                  if(_Ordersdata[col]==""){
                    flag_orders = true;
                    this.notificationService.warning("Kindly fill the Production Order Number");
                  }
                   if(_Ordersdata[col].length>40){
                    flag_orders = true;
                    this.notificationService.warning("Kindly fill Production Order Number not more than 40 characters");
                  }
              }
              if(col=="pos")
              {
                  // var re = new RegExp("^[0-9]*$");
                  // if (!re.test(_Ordersdata[col].toString())) {
                  //    this.notificationService.warning("Kindly fill the Numeric Value for Position");
                  //     flag_orders = true;
                  // } 
                let posLength=_Ordersdata[col].toString().length;
                console.log("position",_Ordersdata[col]);
                console.log("position length",posLength);
                  if (_Ordersdata[col]<0) {
                      this.notificationService.warning("Kindly fill a Positive value for Position");
                      flag_orders = true;
                  } 
                  if (posLength>4) {
                      this.notificationService.warning("Kindly fill Position not more than 4 digits");
                      flag_orders = true;
                  } 
              }
              if(col=="quantity")
              {
                let posLength=_Ordersdata[col].toString().length;
                console.log("position length",posLength);
                console.log("quantity value",_Ordersdata[col]);
                  if (_Ordersdata[col]<=0) {
                      flag_orders = true;
                      this.notificationService.warning("Kindly fill Quantity greater than 0");
                  } 
                  if (posLength>4) {
                      this.notificationService.warning("Kindly fill Position not more than 4 digits");
                      flag_orders = true;
                  } 
              }
              if(col=="productTypeNumber")
              {
                if(_Ordersdata[col]==""){
                    flag_orders = true;
                    this.notificationService.warning("Kindly fill the Product Type Number");
                  }
                  if(_Ordersdata[col].length>40){
                    flag_orders = true;
                    this.notificationService.warning("Kindly fill Product Type Number not more than 40 characters");
                  }
                  
              }
              if (_Ordersdata[col] == "") {
              // flag_orders = true;
                console.log("col not filled", col);
              }
            }
    }
    
    if (!flag_orders) {
      this.orderManagementService.saveOrders(_Ordersdata).then(res => {
        //add the data to the table
        row.confirm.resolve(res);
        this.orders.empty();
        this.orderSettings.serverSidePagination.page=1;
        this._getOrders({ itemsPerPage: 10,page: 1});
      }).catch(err => { console.log("Error: ", err); });
    }
  };

  //to copy orders 
  public copyOrders(row: any): void {

   let flag_orders = false;
    console.log("col names in create: ", row.newData);//row.newData returns Object containing col names
    let Orderstable = row.newData;
    
    if(Orderstable["plannedStartDate"]==""){
        Orderstable["plannedStartDate"]=null;
    }
    if(Orderstable["plannedEndDate"]==""){
      Orderstable["plannedEndDate"]=null;
    }
     let _Ordersdata = {
      "customerOrderNumber": Orderstable["customerOrderNumber"],
      "status": "open",
      "pos": parseInt(Orderstable["pos"]),
      "productionOrderNumber": Orderstable["productionOrderNumber"],
      "productTypeNumber": Orderstable["productTypeNumber"],
      "name": Orderstable["name"],
      "quantity": Orderstable["quantity"],
      "unit": Orderstable["unit"],
      "plannedStartDate": Orderstable["plannedStartDate"],
      "plannedEndDate": Orderstable["plannedEndDate"],
      "productionOrderStartDate": null,
      "productionOrderEndDate": null,
      "activeAssistId": Orderstable["activeAssistId"],
      "quantityCompleted": parseInt(Orderstable["quantityCompleted"]),
      "stepInProgress": parseInt(Orderstable["stepInProgress"]),
      "productStatus": Orderstable["productStatus"]
    }
    console.log("copy orders", _Ordersdata);
      if(_Ordersdata["customerOrderNumber"]==""&&_Ordersdata["productionOrderNumber"]==""&&_Ordersdata["productTypeNumber"]==""&&_Ordersdata["quantity"]=="")
    {
        flag_orders = true;
        this.notificationService.warning("Kindly fill the Order Number,Production Order Number,Product Type Number and Quantity");
    }
    else{
        for (let col in _Ordersdata) {
      
              if(col=="customerOrderNumber")
              {
                  if(_Ordersdata[col]==""){
                    flag_orders = true;
                    this.notificationService.warning("Kindly fill the Order Number");
                  }
              }
              if(col=="plannedEndDate")
              {
                  let startDate=new Date(_Ordersdata["plannedStartDate"]);
                  let endDate=new Date(_Ordersdata[col]);
                  console.log("start and end date",startDate,endDate);
                  if(endDate<startDate)
                  {
                      flag_orders = true;
                      this.notificationService.warning("End Plan Date and Time can't be earlier than Start Plan Date and Time");
                  }
                  /*if(endDate.getDate()<startDate.getDate())
                  {
                      flag_orders = true;
                      this.notificationService.warning("End Date is can't be earlier than the Start Date");
                  }
                  if((endDate.getMonth()+1)<(startDate.getMonth()+1))
                  {
                      flag_orders = true;
                      this.notificationService.warning("End Month can't be earlier than the Start Month");
                  }
                  if(endDate.getFullYear()<startDate.getFullYear())
                  {
                      flag_orders = true;
                      this.notificationService.warning("End Year can't be earlier than the Start Year");
                  }*/
              }
              
              if(col=="productionOrderNumber")
              {
                  if(_Ordersdata[col]==""){
                    flag_orders = true;
                    this.notificationService.warning("Kindly fill the Production Order Number");
                  }
              }
              if(col=="pos")
              {
                  // var re = new RegExp("^[0-9]*$");
                  // if (!re.test(_Ordersdata[col].toString())) {
                  //    this.notificationService.warning("Kindly fill the Numeric Value for Position");
                  //     flag_orders = true;
                  // } 
                
                  if (_Ordersdata[col]<0) {
                      this.notificationService.warning("Kindly fill a Positive value for Position");
                      flag_orders = true;
                  } 
              }
              if(col=="quantity")
              {
                console.log("quantity value",_Ordersdata[col]);
                  if (_Ordersdata[col]<=0) {
                      flag_orders = true;
                      this.notificationService.warning("Kindly fill Quantity greater than 0");
                  } 
              }
              if(col=="productTypeNumber")
              {
                if(_Ordersdata[col]==""){
                    flag_orders = true;
                    this.notificationService.warning("Kindly fill the Product Type Number");
                  }
              }
              if (_Ordersdata[col] == "") {
              // flag_orders = true;
                console.log("col not filled", col);
              }
            }
    }
    

   if (!flag_orders) {
      this.orderManagementService.saveOrders(_Ordersdata).then(res => {
        //add the data to the table
        row.confirm.resolve(res);
        this._getOrders({ itemsPerPage: 10,page: 1});
      }).catch(err => { console.log("Error: ", err); });

    }
  };

  //to update orders
  public updateOrders(row: any): void {
    //check all the required data are added
    //call the api and update the data
    let flag_orders = false;
    let _Ordersdata = row.newData;
     if(_Ordersdata["customerOrderNumber"]==""&&_Ordersdata["productionOrderNumber"]==""&&_Ordersdata["productTypeNumber"]==""&&_Ordersdata["quantity"]=="")
    {
        flag_orders = true;
        this.notificationService.warning("Kindly fill the Order Number,Production Order Number,Product Type Number and Quantity");
    }
   else{
        for (let col in _Ordersdata) {
      
              if(col=="customerOrderNumber")
              {
                  if(_Ordersdata[col]==""){
                    flag_orders = true;
                    this.notificationService.warning("Kindly fill the Order Number");
                  }
                  if(_Ordersdata[col].length>40){
                    flag_orders = true;
                    this.notificationService.warning("Kindly fill Order Number not more than 40 characters");
                  }
              }
              if(col=="plannedEndDate")
              {
                  let startDate=new Date(_Ordersdata["plannedStartDate"]);
                  let endDate=new Date(_Ordersdata[col]);
                  console.log("start and end date",startDate,endDate);
                  if(endDate<startDate)
                  {
                      flag_orders = true;
                      this.notificationService.warning("End Plan Date and Time can't be earlier than Start Plan Date and Time");
                  }
                  /*if(endDate.getDate()<startDate.getDate())
                  {
                      flag_orders = true;
                      this.notificationService.warning("End Date is can't be earlier than the Start Date");
                  }
                  if((endDate.getMonth()+1)<(startDate.getMonth()+1))
                  {
                      flag_orders = true;
                      this.notificationService.warning("End Month can't be earlier than the Start Month");
                  }
                  if(endDate.getFullYear()<startDate.getFullYear())
                  {
                      flag_orders = true;
                      this.notificationService.warning("End Year can't be earlier than the Start Year");
                  }*/
              }
              
              if(col=="productionOrderNumber")
              {
                  if(_Ordersdata[col]==""){
                    flag_orders = true;
                    this.notificationService.warning("Kindly fill the Production Order Number");
                  }
                   if(_Ordersdata[col].length>40){
                    flag_orders = true;
                    this.notificationService.warning("Kindly fill Production Order Number not more than 40 characters");
                  }
              }
              if(col=="pos")
              {
                  // var re = new RegExp("^[0-9]*$");
                  // if (!re.test(_Ordersdata[col].toString())) {
                  //    this.notificationService.warning("Kindly fill the Numeric Value for Position");
                  //     flag_orders = true;
                  // } 
                let posLength=_Ordersdata[col].toString().length;
                console.log("position",_Ordersdata[col]);
                console.log("position length",posLength);
                  if (_Ordersdata[col]<0) {
                      this.notificationService.warning("Kindly fill a Positive value for Position");
                      flag_orders = true;
                  } 
                  if (posLength>4) {
                      this.notificationService.warning("Kindly fill Position not more than 4 digits");
                      flag_orders = true;
                  } 
              }
              if(col=="quantity")
              {
                let posLength=_Ordersdata[col].toString().length;
                console.log("position length",posLength);
                console.log("quantity value",_Ordersdata[col]);
                  if (_Ordersdata[col]<=0) {
                      flag_orders = true;
                      this.notificationService.warning("Kindly fill Quantity greater than 0");
                  } 
                  if (posLength>4) {
                      this.notificationService.warning("Kindly fill Position not more than 4 digits");
                      flag_orders = true;
                  } 
              }
              if(col=="productTypeNumber")
              {
                if(_Ordersdata[col]==""){
                    flag_orders = true;
                    this.notificationService.warning("Kindly fill the Product Type Number");
                  }
                  if(_Ordersdata[col].length>40){
                    flag_orders = true;
                    this.notificationService.warning("Kindly fill Product Type Number not more than 40 characters");
                  }
                  
              }
              if (_Ordersdata[col] == "") {
              // flag_orders = true;
                console.log("col not filled", col);
              }
            }
    }
    
    /**
     * let getproductionOrderEndDate = new Date(selectedOrdersData["productionOrderEndDate"]);
    let getplannedEndDate = new Date(selectedOrdersData["plannedEndDate"]);
    let getplannedStartDate = new Date(selectedOrdersData["plannedStartDate"]);
    let getproductionOrderStartDate = new Date(selectedOrdersData["productionOrderStartDate"]);
    selectedOrdersData["productionOrderEndDate"] = (getproductionOrderEndDate.getMonth() + 1) + "/" + getproductionOrderEndDate.getDate() + "/" + getproductionOrderEndDate.getFullYear();
    selectedOrdersData["plannedEndDate"] = (getplannedEndDate.getMonth() + 1) + "/" + getplannedEndDate.getDate() + "/" + getplannedEndDate.getFullYear();
    selectedOrdersData["plannedStartDate"] = (getplannedStartDate.getMonth() + 1) + "/" + getplannedStartDate.getDate() + "/" + getplannedStartDate.getFullYear();
    selectedOrdersData["productionOrderStartDate"] = (getproductionOrderStartDate.getMonth() + 1) + "/" + getproductionOrderStartDate.getDate() + "/" + getproductionOrderStartDate.getFullYear();


    */
    console.log("update data",_Ordersdata);
       if (!flag_orders) {
         if(_Ordersdata["plannedStartDate"]==""){
              _Ordersdata["plannedStartDate"]=null;
          }
          if(_Ordersdata["plannedEndDate"]==""){
            _Ordersdata["plannedEndDate"]=null;
          }
          this.orderManagementService.updateOrdersData(_Ordersdata).then(res => {
            //add the data to the table
            row.confirm.resolve(res);
            //this._getOrders({ itemsPerPage: 10,page: 1});
          }).catch(err => { console.log("Error: ", err); });
        }
  };
  

  //get the table data for product types
  public _getOrders(pagination): void {
    let _pagination = pagination || this.orderSettings.serverSidePagination;
    console.log("_pagination",_pagination);
      //call the order management service to get the data
          this.orderManagementService.getOrdersData(_pagination).then(res => {
            this.orderSettings.serverSidePagination.totalItems = res.size;
            console.log("response",res);
            console.log("order settings",this.orderSettings);
           
            this.orders.load(res.content);
            //this.orders.reset(true);
          }).catch(err => { console.log("Error: ", err); });
        //this.getUidOrders({itemsPerPage: 10,page: 1});
  };

  // to delete orders
  public deleteOrders(row: any): void {
    if (row && row.data) {
      console.log("deleted row data", row.data);
      this.ordersDeleteModal.hide();
      //call the assembly service api and pass the product type id to delete the data
      this.orderManagementService.deleteOrder(row.data.productionOrderId).then(res => {
        //delete the data from the table
        row.confirm.resolve();
        this.orders.empty();
        this._getOrders({ itemsPerPage: 10,page: this.ordersCurrentPageForDelete});
        //hide the delete modal pop up
      }).catch(err => { console.log("Error: ", err); });
    }
  };

  // to upload orders
  public uploadOrders(fileInput: any) {
      console.log("fileinput", fileInput);
      let ordersFormData = new FormData();
      ordersFormData.append('file', fileInput.target.files[0], fileInput.target.files[0].name);
      this.orderManagementService.uploadOrdersXML(ordersFormData).then(res => {
        this._getOrders({ itemsPerPage: 10,page: 1});
        console.log("reserr", res);
        this.notificationService.success("Successfully Uploaded Orders XML");
      }).catch(err => { console.log("Error: ", err); for (let i = 0; i < err.data.failureMessages.length; i++) { this.notificationService.info(err.data.failureMessages[i],"",customTimeOutMsg); }
    });
      fileInput.target.value="";
  }



  /**
   * Assign Order Table 
   * getOrdersToAssign() - to get Assigned Orders
   * getEligibleActiveAssist() - to create a new UID Orders
   * onCellClick() - on click of a cell row display active assist ID
   * updateActiveAssistId() - to update an Active Assist ID 
   */

   /**
    * Assign Orders:
      Production Order Number - disabled in frontend
      Product Type Number - disabled in frontend
      ActiveAssist ID - active assist dropdown list of eligible active assists
    */

  // to get all the Assigned Orders
  public _getOrdersToAssign(pagination): void {
  console.log("this.orderSettings.serverSidePagination",this.orderSettings.serverSidePagination);
   let _pagination = pagination || this.settingsAssignOrders.serverSidePagination;

   if(this.assignOrders.count()==0 || _pagination.page!=this.settingsUidProducts.serverSidePagination.page){
      this.orderManagementService.getOrdersToAssignData(_pagination).then(res => {
        //load the data set to the marker table
        this.settingsAssignOrders.serverSidePagination.totalItems = res.size;
        this.assignOrders.load(res.content);
      }).catch(err => { console.log("Error: ", err); });
   }
    
  };



  // to get all the eligible active assist ID
  public _getEligibleActiveAssist(): void {
      this.orderManagementService.getEligibleActiveAssistData().then(res => {
        console.log("res of aalist",res);
        //assign the list of active asssit id
          for(let i=0;i<res.length;i++)
          {
              this.activeAssistIdList[i]=res[i].activeAssistId;
          }
        this.assignActiveAssistModal.show();
      });
      
  };

  // on click on cell row display eligible active assists ID
  public onCellClick(event: any): void {
    console.log("checking event>>", event);
    let _id = event.data.activeAssistId;
    if (_id) {
      this.selectedActiveAssistId = _id;
    } else {
      this.selectedActiveAssistId = null;
    }
    // to get all the eligible active assist id's
    this._getEligibleActiveAssist();
  };

  //to update an Active Assist ID 
  public updateActiveAssistId(id, event): void {
    console.log("id:",this.settingsAssignOrders.serverSidePagination);
    this.orderManagementService.updateActiveAssistId(event.data.id, id).then(res => {
      //this.assignOrders.reset();
      this.assignOrders.empty();
      this._getOrdersToAssign({ itemsPerPage: 10,page: this.settingsAssignOrders.serverSidePagination.page});

      //to close the modal on click of cancel
      this.assignActiveAssistModal.hide();
    });
  }

  /**
 * UID Order Table - CRUD and COPY OPERATIONS
 * getUidOrders() - to get the list of UID Orders
 * saveUidOrders() - to create a new UID Orders
 * updateUidOrder() - to update a UID Marker based on @param id 
 * deleteUidOrder() - to clone a UID Orders
 * copyUidOrders() - to delete a UID Orders based on @param id 
 */
/**
 * UID Products: 258
  Product Type ID – mandatory, product type dropdown list
  UID – mandatory
  Start Plan – date picker
  End Plan – date picker

validation in between start and end dates, start date needs to be before end date, also they can’t be in the past

if Order creation/updating is failed, generic message is showing that “Order creation is failed” 
 */
  public getUidOrders(pagination): void {
    let _pagination = pagination || this.settingsUidProducts.serverSidePagination;
    //call the order management service to get the data
    if(this.uIdProducts.count()==0 || _pagination.page != this.settingsUidProducts.serverSidePagination.page){
      this.orderManagementService.getUIDProductsData(_pagination).then(res => {
        //load the data set to the marker table
        this.settingsUidProducts.serverSidePagination.totalItems = res.size;
        this.uIdProducts.load(res.content);
      }).catch(err => { console.log("Error: ", err); });
    }

      //this._getOrdersToAssign({itemsPerPage: 10,page: 1});

  };

  checking(data){
    console.log("dataa>>>",data);
  }


// to create an activeassist entry
public saveUidOrders(row: any): void {
  let flag_UID = false;
  console.log("to create new row", row.newData);
      let UidOrderstable = row.newData;
      if(UidOrderstable["startDate"]==""){
            UidOrderstable["startDate"]=null;
        }
        if(UidOrderstable["endDate"]==""){
          UidOrderstable["endDate"]=null;
        }
      let _UidOrdersdata = {
        "productTypeNumber": UidOrderstable["productTypeNumber"],
        "uid": UidOrderstable["uid"],
        "startDate": UidOrderstable["startDate"],
        "endDate": UidOrderstable["endDate"],
      } 
      console.log("uidorders entered",UidOrderstable)
      for (let col in _UidOrdersdata) {
          if(col=="productTypeNumber")
          {
              if(_UidOrdersdata[col]==""){
                flag_UID=true;
                this.notificationService.warning("Kindly fill the Product Type ID");
              }
          }
           if(col=="uid")
          {
                if(_UidOrdersdata[col]==""){
                  flag_UID=true;
                  this.notificationService.warning("Kindly fill the UID");
                }
                if(_UidOrdersdata[col].length>40){
                  flag_UID = true;
                  this.notificationService.warning("Kindly fill UID not more than 40 characters");
                }
          }
          if(col=="endDate")
          {
              let startDate=new Date(_UidOrdersdata["startDate"]);
              let endDate=new Date(_UidOrdersdata[col]);
              console.log("start and end date UID",startDate,endDate);
              if(endDate<startDate)
              {
                  flag_UID=true;
                  this.notificationService.warning("End Date and Time can't be earlier than Start Date and Time");
              }
              /*if(endDate.getDate()<startDate.getDate())
              {
                  flag_UID = true;
                  this.notificationService.warning("End Date is can't be earlier than the Start Date");
              }
              if((endDate.getMonth()+1)<(startDate.getMonth()+1))
              {
                  flag_UID = true;
                  this.notificationService.warning("End Month can't be earlier than the Start Month");
              }
              if(endDate.getFullYear()<startDate.getFullYear())
              {
                  flag_UID = true;
                  this.notificationService.warning("End Year can't be earlier than the Start Year");
              }*/
          }
    }
    if (!flag_UID) {
      this.orderManagementService.saveUidOrder(_UidOrdersdata).then(res => {
        //add the data to the table
        row.confirm.resolve(res);
        this.uIdProducts.empty();
        this.settingsUidProducts.serverSidePagination.page=1;
        //this.getActiveassist({ itemsPerPage: 10,page: 1});
        this.getUidOrders({itemsPerPage: 10,page: 1});
      }).catch(err => { console.log("Error: ", err); });
    }
  };


  public updateUidOrder(row: any): void {
    //check all the required data are added
    /*let selecteUidData = row.newData;
    if (row.newData) {
      //call the api and update the data
      this.orderManagementService.updateUidOrder(selecteUidData).then(res => {
        //update the data to the table
        row.confirm.resolve(res);
      }).catch(err => { console.log("Error: ", err); });
    } else {
      //notify the user to fill all the fields
      this.notificationService.warning("Kindly fill all the fields");
    }*/

      let flag_UID = false;
      console.log("to update new row", row.newData);
      
      let UidOrderstable = row.newData;
      if(UidOrderstable["startDate"]==""){
            UidOrderstable["startDate"]=null;
        }
        if(UidOrderstable["endDate"]==""){
          UidOrderstable["endDate"]=null;
        }
          let _UidOrdersdata = {
            "productTypeNumber": UidOrderstable["productTypeNumber"],
            "uid": UidOrderstable["uid"],
            "startDate": UidOrderstable["startDate"],
            "endDate": UidOrderstable["endDate"],
          } 
          console.log("uidorders entered",UidOrderstable)
          for (let col in _UidOrdersdata) {
              if(col=="productTypeNumber")
              {
                  if(_UidOrdersdata[col]==""){
                    flag_UID=true;
                    this.notificationService.warning("Kindly fill the Product Type ID");
                  }
              }
              if(col=="uid")
              {
                    if(_UidOrdersdata[col]==""){
                      flag_UID=true;
                      this.notificationService.warning("Kindly fill the UID");
                    }
                     if(_UidOrdersdata[col].length>40){
                        flag_UID = true;
                        this.notificationService.warning("Kindly fill UID not more than 40 characters");
                      }
              }
              if(col=="endDate")
              {
                  let startDate=new Date(_UidOrdersdata["startDate"]);
                  let endDate=new Date(_UidOrdersdata[col]);
                  console.log("start and end date UID",startDate,endDate);
                  if(endDate<startDate)
                  {
                      flag_UID=true;
                      this.notificationService.warning("End Date and Time can't be earlier than Start Date and Time");
                  }
                  /*if(endDate.getDate()<startDate.getDate())
                  {
                      flag_UID = true;
                      this.notificationService.warning("End Date is can't be earlier than the Start Date");
                  }
                  if((endDate.getMonth()+1)<(startDate.getMonth()+1))
                  {
                      flag_UID = true;
                      this.notificationService.warning("End Month can't be earlier than the Start Month");
                  }
                  if(endDate.getFullYear()<startDate.getFullYear())
                  {
                      flag_UID = true;
                      this.notificationService.warning("End Year can't be earlier than the Start Year");
                  }*/
              }
    }
    if (!flag_UID) {
     //call the api and update the data
      this.orderManagementService.updateUidOrder(_UidOrdersdata).then(res => {
        //update the data to the table
        row.confirm.resolve(res);
      }).catch(err => { console.log("Error: ", err); });
    }
  };


  public deleteUidOrder(row: any): void {
    if (row && row.data) {
      this.uidOrdersDeleteModal.hide();
      //call the assembly service api and pass the product type id to delete the data
      this.orderManagementService.deleteUidOrder(row.data.id).then(res => {
        //delete the data from the table
        row.confirm.resolve();
        this.uIdProducts.empty();
        this.getUidOrders({ itemsPerPage: 10,page: this.uidCurrentPageForDelete});
        //hide the delete modal pop up
      }).catch(err => { console.log("Error: ", err); });
    }
  };


  public copyUidOrders(row: any): void {
    //construct the data to post it to the back end
    let flag_UID = false;
    console.log("to create new row", row.newData);
      let UidOrderstable = row.newData;
      if(UidOrderstable["startDate"]==""){
            UidOrderstable["startDate"]=null;
        }
        if(UidOrderstable["endDate"]==""){
          UidOrderstable["endDate"]=null;
        }
      let _UidOrdersdata = {
        "productTypeNumber": UidOrderstable["productTypeNumber"],
        "uid": UidOrderstable["uid"],
        "startDate": UidOrderstable["startDate"],
        "endDate": UidOrderstable["endDate"],
      } 
      console.log("uidorders entered",UidOrderstable)
      for (let col in _UidOrdersdata) {
          if(col=="productTypeNumber")
          {
              if(_UidOrdersdata[col]==""){
                flag_UID=true;
                this.notificationService.warning("Kindly fill the Product Type ID");
              }
          }
           if(col=="uid")
          {
                if(_UidOrdersdata[col]==""){
                  flag_UID=true;
                  this.notificationService.warning("Kindly fill the UID");
                }
          }
          if(col=="endDate")
          {
              let startDate=new Date(_UidOrdersdata["startDate"]);
              let endDate=new Date(_UidOrdersdata[col]);
              console.log("start and end date UID",startDate,endDate);
              if(endDate<startDate)
              {
                  flag_UID=true;
                  this.notificationService.warning("End Date and Time can't be earlier than Start Date and Time");
              }
              /*if(endDate.getDate()<startDate.getDate())
              {
                  flag_UID = true;
                  this.notificationService.warning("End Date is can't be earlier than the Start Date");
              }
              if((endDate.getMonth()+1)<(startDate.getMonth()+1))
              {
                  flag_UID = true;
                  this.notificationService.warning("End Month can't be earlier than the Start Month");
              }
              if(endDate.getFullYear()<startDate.getFullYear())
              {
                  flag_UID = true;
                  this.notificationService.warning("End Year can't be earlier than the Start Year");
              }*/
          }
    }
    console.log("copy", _UidOrdersdata);
     if (!flag_UID) {
      this.orderManagementService.saveUidOrder(_UidOrdersdata).then(res => {
        //add the data to the table
        row.confirm.resolve(res);
        //this.getActiveassist({ itemsPerPage: 10,page: 1});
        this.getUidOrders({itemsPerPage: 10,page: 1});
      }).catch(err => { console.log("Error: ", err); });
    }
  };

  public uploadUidXML(event: any): void {
    console.log("media>>", event.target.files);
    //get the file and file details and append to the form data
    let file: File = event.target.files[0];
    let formData: FormData = new FormData();
    formData.append('file', file, file.name);
    //call the assembly service and upload the media
    this.orderManagementService.uploadUidXML(formData).then(res => {
      console.log("res>>", res);
      //relaod the entire dataset
      this.getUidOrders(this.settingsUidProducts.serverSidePagination);
       this.notificationService.success("Successfully Uploaded UID XML");
      }).catch(err => { console.log("Error: ", err); for (let i = 0; i < err.data.length; i++) { this.notificationService.info(err.data[i],"",customTimeOutMsg); }
    });
    event.target.value="";
  };

  
//for pagination in Orders Table
  public pageChangedOrders(pagination) : void {
    this.ordersCurrentPageForDelete=pagination.page;
    this._getOrders(pagination);
  };
  //Pagination for UID 
public pageChangeUId(pagination) : void {
    this.uidCurrentPageForDelete=pagination.page;
    this.getUidOrders(pagination);
  };

  
   //for pagination Assign Orders
  public pageChangedAssignOrders(pagination) : void {
    this.assignOrdersCurrentPage=pagination.page;
    this._getOrdersToAssign(pagination);
  };
  ngOnInit() {
   this.assignOrdersCurrentPage=1;
   this._getOrders({ itemsPerPage: 10,page: 1});
    //this.orderSettings.columns.unit.editor.config.list=[{"title":"abc","value":"abc"}];
      //  this.orderManagementService.getUnitList().then(res=>{
      //             this.unitList=res;
      //             this.orderSettings.columns.unit.editor.config.list =  this.unitList.map((list)=> {
      //                 return { value: list, title: list };
      //               });
      //               this.orderSettings = Object.assign({}, this.orderSettings);
      //         }).catch(err => { console.log("Error: ", err); });
      this.orderManagementService.getProductTypeNumberList().then(res=>{
                  console.log("prodtype list res",res);
                  this.productList=res;
                  this.productTypeNumberList = [];
                  this.productTypeNumberListForUID=[];
                  for(let i=0;i<this.productList.length;i++)
                  {
                       this.productTypeNumberList.push({ value: this.productList[i], title: this.productList[i] });
                       this.productTypeNumberListForUID.push({ value: this.productList[i], title: this.productList[i] });
                  }
                  this.orderManagementConfig.updateSettings(this.productTypeNumberList,this.productTypeNumberListForUID,this.activeAssistList);
      }).catch(err=>{console.log("Error: ", err);})
      this.orderManagementService.getAllActiveassistList().then(res=>{
                  this.aaidList=res;
                  console.log("aaid res",res);
                  this.activeAssistList=[];
                  for(let i=0;i<this.aaidList.length;i++)
                  {
                       this.activeAssistList.push({ value: this.aaidList[i], title: this.aaidList[i] });
                  }
                  this.orderManagementConfig.updateSettings(this.productTypeNumberList,this.productTypeNumberListForUID,this.activeAssistList);
      }).catch(err=>{console.log("Error: ", err);})
  }
}
