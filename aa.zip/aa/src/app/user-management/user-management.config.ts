import { TranslateService, TranslationChangeEvent } from '@ngx-translate/core';

import { AuthenticationService } from '../authentication/authentication.service';
export class UserManagementConfig {


    constructor(private translate: TranslateService, private authService: AuthenticationService) {
        this.checkPermissions();
    }
    public tablePermissions: boolean = true;

    public checkPermissions(): void {
        if (this.authService.appPermissions == undefined) {
            this.authService.logout();
        }
    }

    public getUserPermissions(): boolean {
        if (this.authService.appPermissions != undefined) {
            return this.authService.appPermissions["Create/Change/Delete Users and Role"];
        } else {
            this.authService.logout();
        }
    }

    //pagination  settings
    public paginationSettings: Object = {
        display: false,
        perPage: 10
    };

    //table configuration for list of user table
    public userSettings: Object = {
        actions: {
            columnTitle: '',
            add: this.getUserPermissions(),
            edit: this.getUserPermissions(),
            delete: this.getUserPermissions(),
            copy: false,
            move: false,
            position: 'left', // left|right
        },
        columns: {
            username: {
                title: this.translate.instant("USER_MANAGEMENT.USER_ID_COL"),
                filter: true
            },
            surname: {
                title: this.translate.instant("USER_MANAGEMENT.FIRST_NAME_COL"),
                filter: true
            },
            lastname: {
                title: this.translate.instant("USER_MANAGEMENT.LAST_NAME_COL"),
                filter: true
            },
            mail: {
                title: this.translate.instant("USER_MANAGEMENT.EMAIL_COL"),
                filter: true
            },
            userGroupName: {
                title: this.translate.instant("USER_MANAGEMENT.USER_GROUP_COL"),
                filter: true,
                editor: {
                    type: 'list',
                    config: {
                        selectText: 'Select...',
                        list: [],
                    }
                }
            },
            password: {
                title: this.translate.instant("USER_MANAGEMENT.PASSWORD_COL"),
                filter: false,
                type: 'password'
            }
        },
        pager: this.paginationSettings
    };


    //table configuration for list of ldap configurations
    public ldapSettings: Object = {
        actions: {
            columnTitle: '',
            add: this.getUserPermissions(),
            edit: this.getUserPermissions(),
            delete: this.getUserPermissions(),
            copy: false,
            move: false,
            position: 'left', // left|right
        },
        columns: {
            host: {
                title: this.translate.instant("USER_MANAGEMENT.HOST_COL"),
                filter: true
            },
            port: {
                title: this.translate.instant("USER_MANAGEMENT.PORT_COL"),
                filter: true,
                type: "number"
            },
            principaldomainname: {
                title: this.translate.instant("USER_MANAGEMENT.DOMAIN_NAME_COL"),
                filter: true
            },
            timestamp: {
                title: this.translate.instant("USER_MANAGEMENT.LAST_EDITED_COL"),
                filter: true,
                disabled: true
            }
        },
        pager: this.paginationSettings
    };

    public updateSettings(userGroupList) {
        this.userSettings = {
            actions: {
                columnTitle: '',
                add: true,
                edit: true,
                delete: true,
                copy: false,
                move: false,
                position: 'left', // left|right
            },
            columns: {
                username: {
                    title: this.translate.instant("USER_MANAGEMENT.USER_ID_COL"),
                    filter: true
                },
                surname: {
                    title: this.translate.instant("USER_MANAGEMENT.FIRST_NAME_COL"),
                    filter: true
                },
                lastname: {
                    title: this.translate.instant("USER_MANAGEMENT.LAST_NAME_COL"),
                    filter: true
                },
                mail: {
                    title: this.translate.instant("USER_MANAGEMENT.EMAIL_COL"),
                    filter: true
                },
                userGroupName: {
                    title: this.translate.instant("USER_MANAGEMENT.USER_GROUP_COL"),
                    filter: true,
                    editor: {
                        type: 'list',
                        config: {
                            selectText: 'Select...',
                            list: userGroupList,
                        }
                    }
                },
                password: {
                    title: this.translate.instant("USER_MANAGEMENT.PASSWORD_COL"),
                    filter: false,
                    type: 'password'
                }
            },
            pager: this.paginationSettings
        };


        //table configuration for list of ldap configurations
        this.ldapSettings = {
            actions: {
                columnTitle: '',
                add: true,
                edit: true,
                delete: true,
                copy: false,
                move: false,
                position: 'left', // left|right
            },
            columns: {
                host: {
                    title: this.translate.instant("USER_MANAGEMENT.HOST_COL"),
                    filter: true
                },
                port: {
                    title: this.translate.instant("USER_MANAGEMENT.PORT_COL"),
                    filter: true,
                    type: "number"
                },
                principaldomainname: {
                    title: this.translate.instant("USER_MANAGEMENT.DOMAIN_NAME_COL"),
                    filter: true
                },
                timestamp: {
                    title: this.translate.instant("USER_MANAGEMENT.LAST_EDITED_COL"),
                    filter: true,
                    disabled: true
                }
            },
            pager: this.paginationSettings
        };
    }

}