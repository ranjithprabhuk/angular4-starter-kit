import { NgModule } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

import { TabsModule,ModalModule } from 'ng2-bootstrap';
import { Ng2SmartTableModule } from '../smart-table';

import { TranslateModule } from '@ngx-translate/core';


import { UserManagementComponent } from './user-management.component';
import { UserManagementRoutingModule } from './user-management-routing.module';

@NgModule({
  imports: [
    UserManagementRoutingModule,
    CommonModule,
    FormsModule,
    Ng2SmartTableModule,
    TranslateModule,
    TabsModule.forRoot(),
    ModalModule.forRoot()
  ],
  declarations: [ UserManagementComponent ]
})
export class UserManagementModule { }
