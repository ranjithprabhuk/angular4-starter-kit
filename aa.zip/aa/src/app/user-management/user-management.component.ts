import { Component, ViewChild } from '@angular/core';

import { Ng2SmartTableModule, LocalDataSource } from '../smart-table';
import { ModalDirective } from 'ng2-bootstrap/modal';
import { TranslateService, TranslationChangeEvent } from '@ngx-translate/core';
import { UserManagementConfig } from './user-management.config';
import { UserManagementService } from './user-management.service';
import { AuthenticationService } from '../authentication/authentication.service';

import { ToastrService } from 'ngx-toastr';
@Component({
    templateUrl: 'user-management.component.html',
    styleUrls: ['./user-management.component.css'],
    providers: [UserManagementService]
})

export class UserManagementComponent {

    @ViewChild('deleteUserModal') public deleteUserModal: ModalDirective;
    @ViewChild('deleteLdapModal') public deleteLdapModal: ModalDirective;
    @ViewChild('deleteUserGroupModal') public deleteUserGroupModal: ModalDirective;
    @ViewChild('addUserGroupModal') public addUserGroupModal: ModalDirective;
    @ViewChild('addPermissionModal') public addPermissionModal: ModalDirective;

    constructor(private userManagementService: UserManagementService,
        private notificationService: ToastrService, private authService: AuthenticationService,
        private translate: TranslateService) {
        this.checkPermissions();
        this.userData = new LocalDataSource();
        this.ldapData = new LocalDataSource();
        this.translate.onLangChange.subscribe((event: TranslationChangeEvent) => {
            this.doTranslate();
        });
    }

    public userConfig: UserManagementConfig = new UserManagementConfig(this.translate, this.authService);
    public userSettings: any = new UserManagementConfig(this.translate, this.authService).userSettings;
    public ldapSettings: any = new UserManagementConfig(this.translate, this.authService).ldapSettings;

    public selectedTab: String = "USER_MANAGEMENT.USERS_TAB";
    public userGroup: any = { "groupName": "" };
    public permissionData: any = { "permission": "" };

    public userData: LocalDataSource;
    public ldapData: LocalDataSource;
    public userGroups: Array<any> = [];
    public selectedUser: any;
    public selectedLdap: any;
    public selectedUserGroup: any;
    public permissionList: Array<any>;
    public permissionWithGroupList: Array<any>;
    public userPermission: boolean = false;

    public userGroupList: Array<any> = [];

    doTranslate() {
        this.userConfig.updateSettings(this.userGroups);
    }

    public checkPermissions(): void {
        if (this.authService.appPermissions == undefined) {
            this.authService.logout();
        } else {
            this.userPermission = this.authService.appPermissions["Create/Change/Delete Users and Role"];
        }
    }

    public getUserData(): void {
        this.userManagementService.getUserData().then(res => {
            if (res.length > 0) {
                for (let i = 0; i < res.length; i++) {
                    if (res[i].userGroup)
                        res[i].userGroupName = res[i].userGroup.groupName;
                    res[i].password = "...";
                }
                this.userData.load(res);
            }
            this.getUserGroupData();
        }).catch(err => { console.log("Error: ", err); });
    }

    public getUserGroupData(): void {
        this.userGroupList = [];
        this.userManagementService.getUserGroupData().then(res => {
            if (res.length > 0) {
                this.userGroups = res;
                this.userSettings.columns.userGroupName.editor.config.list = res.map((list) => {
                    this.userGroupList.push({ value: list.groupName, title: list.groupName });
                    return { value: list.groupName, title: list.groupName };
                });
                this.userSettings = Object.assign({}, this.userSettings);

                this.userConfig.updateSettings(this.userGroupList);
            }
        }).catch(err => { console.log("Error: ", err); });
    }


    public createUser(data: any): void {
        if (this.validateUserData(data.newData, "create")) {
            let userdata = this.constructUserData(data.newData);

            this.userManagementService.saveUser(userdata).then(res => {
                res.password = "...";
                res.userGroupName = res.userGroup.groupName;
                data.confirm.resolve(res);
            }).catch(err => { console.log("Error: ", err); });

        }
    }

    public updateUser(data: any): void {
        if (this.validateUserData(data.data, "edit")) {
            let userdata = this.constructUserUpdateData(data.data);

            this.userManagementService.editUser(userdata).then(res => {
                res.password = "...";
                res.userGroupName = res.userGroup.groupName;
                data.confirm.resolve(res);
            }).catch(err => { console.log("Error: ", err); });

        }
    }

    public constructUserData(user): Object {
        let data = {
            "lastname": user.lastname,
            "mail": user.mail,
            "password": user.password,
            "surname": user.surname,
            "userGroup": this.setUserGroup(user.userGroupName),
            "username": user.username
        }

        return data;
    }

    public constructUserUpdateData(user): Object {
        let data = {
            "id": user.id,
            "lastname": user.lastname,
            "mail": user.mail,
            "password": user.password,
            "surname": user.surname,
            "userGroup": this.setUserGroup(user.userGroupName),
            "username": user.username
        }

        return data;
    }

    public setUserGroup(name): Object {
        let userGroup = this.userGroups;
        for (let i = 0; i < userGroup.length; i++) {
            if (userGroup[i].groupName == name) {
                return userGroup[i];
            }
        }
    }

    public validateUserData(user: any, operation: string): boolean {
        if (user.username == "") {
            this.notificationService.warning("Kindly fill the user name");
            return false;
        }
        if (user.surname == "") {
            this.notificationService.warning("Kindly fill the first name");
            return false;
        }
        if (user.lastname == "") {
            this.notificationService.warning("Kindly fill the last name");
            return false;
        }
        if (!this.validateEmail(user.mail)) {
            this.notificationService.warning("Kindly fill the email");
            return false;
        }
        if (user.userGroupName == "") {
            this.notificationService.warning("Kindly select a user group");
            return false;
        }
        if (user.password == "" && operation == "create") {
            this.notificationService.warning("Kindly fill the password");
            return false;
        }
        return true;
    }

    public validateEmail(email: string): boolean {
        let EMAIL_REGEXP = /^[a-z0-9!#$%&'*+\/=?^_`{|}~.-]+@[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)*$/i;
        return EMAIL_REGEXP.test(email);
    }

    public deleteUser(row: any): void {
        if (row && row.data) {
            this.userManagementService.deleteUser(row.data.id).then(res => {
                row.confirm.resolve();
                this.deleteUserModal.hide();
            }).catch(err => { console.log("Error: ", err); });
        }
    };

    public getPermissions() {
        this.userManagementService.getUserPermissions().then(res => {
            this.permissionList = res;
            this.getPermissionsWithUserGroups();
        }).catch(err => { console.log("Error: ", err); });
    }

    public getPermissionsWithUserGroups() {
        this.userManagementService.getPermissionWithUserGroups().then(res => {

            let data = res;
            if (data.length > 0) {
                for (let i = 0; i < data.length; i++) {
                    for (let j = 0; j < this.userGroups.length; j++) {
                        let _index = 0;
                        let _isEnabled = false;

                        for (let k = 0; k < data[i].userGroups.length; k++) {
                            if (data[i].userGroups[k].groupName == this.userGroups[j].groupName) {
                                _isEnabled = true;
                                _index = k;
                                break;
                            }
                        }

                        if (_isEnabled) {
                            data[i].userGroups[_index].isEnabled = _isEnabled;
                        } else {
                            let _userGroup = this.userGroups[j];
                            data[i].userGroups.push({
                                "groupName": _userGroup.groupName,
                                "id": _userGroup.id,
                                "isEnabled": false
                            });
                        }
                    }
                    data[i].userGroups.sort(function (a, b) { return a.id - b.id });
                }
            }
            this.permissionWithGroupList = data;
            this.addUserGroupModal.hide();
            this.addPermissionModal.hide();
        }).catch(err => { console.log("Error: ", err); });
    }

    public addUserGroup(userGroup): void {
        this.userManagementService.saveUserGroup(userGroup).then(res => {
            this.getUserGroupData();
            this.getPermissions();
            this.userGroup.groupName = "";
        }).catch(err => { console.log("Error: ", err); });
    }

    public addPermission(permission): void {
        this.userManagementService.savePermission(permission).then(res => {
            this.getUserGroupData();
            this.getPermissions();
            this.permissionData.permission = "";
        }).catch(err => { console.log("Error: ", err); });
    }

    public updateUserGroup(userGroup, index): void {
        let _userGroup = {
            "groupName": userGroup.groupName,
            "id": userGroup.id
        };
        this.userManagementService.updateUserGroup(_userGroup).then(res => {
            this.userGroups[index].isEditable = false;
        }).catch(err => { console.log("Error: ", err); });
    }

    public updatePermission(parent, child): void {

        this.permissionWithGroupList[parent].userGroups[child].isEnabled = !this.permissionWithGroupList[parent].userGroups[child].isEnabled;
    }

    public savePermissionwithUserGroups(data): void {

        let permissionGroup = JSON.parse(JSON.stringify(data));

        for (let i = 0; i < permissionGroup.length; i++) {
            for (let j = 0; j < permissionGroup[i].userGroups.length; j++) {
                if (!permissionGroup[i].userGroups[j].isEnabled) {
                    permissionGroup[i].userGroups.splice(j, 1);
                    --j;
                }
            }
        }

        this.userManagementService.setPermission(permissionGroup).then(res => {
            console.log("success>>");
        }).catch(err => { console.log("Error: ", err); });
    }


    public getLdapData(): void {
        if (this.ldapData.count() == 0) {
            this.userManagementService.getLdapData().then(res => {
                if (res.length > 0) {
                    this.ldapData.load(res);
                }
            }).catch(err => { console.log("Error: ", err); });
        }
    }

    public saveLdap(data): void {
        if (this.validateLdapData(data.newData)) {
            let _data = {
                "host": data.newData.host,
                "port": data.newData.port,
                "principaldomainname": data.newData.principaldomainname
            }

            this.userManagementService.saveLdap(_data).then(res => {
                console.log("success>>", res);
                // this.ldapData.append(res);
                data.confirm.resolve(res);
            }).catch(err => { console.log("Error: ", err); });
        }
    };

    public updateLdap(data): void {
        if (this.validateLdapData(data.newData)) {
            let _data = {
                "host": data.newData.host,
                "id": data.newData.id,
                "port": data.newData.port,
                "principaldomainname": data.newData.principaldomainname
            }

            this.userManagementService.updateLdap(_data).then(res => {
                data.confirm.resolve(res);
            }).catch(err => { console.log("Error: ", err); });
        }
    };

    public deleteLdap(row: any): void {
        if (row && row.data) {
            this.userManagementService.deleteLdap(row.data.id).then(res => {
                row.confirm.resolve();
                this.deleteLdapModal.hide();
            }).catch(err => { console.log("Error: ", err); });
        }
    };

    public validateLdapData(data): boolean {
        if (data.host == "") {
            this.notificationService.warning("Kindly enter host name");
            return false;
        }
        if (data.port == "") {
            this.notificationService.warning("Kindly enter port name");
            return false;
        }
        if (data.principaldomainname == "") {
            this.notificationService.warning("Kindly enter domain name");
            return false;
        }
        return true;
    };

    public deleteUserGroup(data: any): void {
        if (data && data.id) {
            this.userManagementService.deleteUserGroup(data.id).then(res => {
                this.getUserGroupData();
                this.getPermissions();
                this.deleteUserGroupModal.hide();
            }).catch(err => { console.log("Error: ", err); });
        }
    };

    public checkUserPermissions(user, permission): boolean {
        if (user == 'Admin')
            return false;
        else
            return permission;
    }




    ngOnInit() {
        this.getUserData();
        //this.getLdapData();
    }
}
