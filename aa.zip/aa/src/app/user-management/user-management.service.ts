import { Injectable } from '@angular/core';
import { URLSearchParams } from '@angular/http';
import { ApiService } from '../app.service';

import 'rxjs/add/operator/toPromise';


@Injectable()
export class UserManagementService {

    constructor(private apiService: ApiService) {
        //this.getDetails();
    }

    //protected apiEndPoint: string = this.apiService.baseUrl.userManagementServicePort +"/";
    protected apiEndPoint: string = "";

    public host = "userManagementService";

    getDetails(): void {
        this.getExternalProperties().then((res) => {
            this.apiEndPoint = res.userManagementServicePort + "/";
        });
    }

    getExternalProperties(): Promise<any> {
        return this.apiService.getExternalApplicationProperties().then(res => { return Promise.resolve(res) });
    }


    //to get the list of users
    getUserData(parameter?: any): Promise<any> {
        let params: URLSearchParams = new URLSearchParams();
        return this.apiService.get(this.host, this.apiEndPoint + "getusers")
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    //to get the list of users groups
    getUserGroupData(parameter?: any): Promise<any> {
        let params: URLSearchParams = new URLSearchParams();
        return this.apiService.get(this.host, this.apiEndPoint + "getusergroups")
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }


    // to save a new user
    saveUser(parameter?: any): Promise<any> {
        return this.apiService.create(this.host, this.apiEndPoint + "createuser", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    // to save a new user
    editUser(parameter?: any): Promise<any> {
        return this.apiService.update(this.host, this.apiEndPoint + "edituser", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    // to delete a user
    deleteUser(parameter?: any): Promise<any> {
        return this.apiService.delete(this.host, this.apiEndPoint + "deleteuser/" + parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    //to get the list of user groups
    getPermissionWithUserGroups(parameter?: any): Promise<any> {
        let params: URLSearchParams = new URLSearchParams();
        return this.apiService.get(this.host, this.apiEndPoint + "getpermissionswithusergroup")
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    //to get the list of user groups
    getUserPermissions(parameter?: any): Promise<any> {
        let params: URLSearchParams = new URLSearchParams();
        return this.apiService.get(this.host, this.apiEndPoint + "getpermissions")
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    // to save a new user group
    saveUserGroup(parameter?: any): Promise<any> {
        return this.apiService.create(this.host, this.apiEndPoint + "createusergroup", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    // to save a new permission
    savePermission(parameter?: any): Promise<any> {
        return this.apiService.create(this.host, this.apiEndPoint + "createpermission", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    //to update a user group
    updateUserGroup(parameter?: any): Promise<any> {
        return this.apiService.update(this.host, this.apiEndPoint + "editusergroup", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    // to set a new permission
    setPermission(parameter?: any): Promise<any> {
        return this.apiService.create(this.host, this.apiEndPoint + "setpermissionswithusergroup", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    //to get the list ldap config
    getLdapData(parameter?: any): Promise<any> {
        let params: URLSearchParams = new URLSearchParams();
        return this.apiService.get(this.host, this.apiEndPoint + "getLdapConfig")
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    // to save a new ldap config
    saveLdap(parameter?: any): Promise<any> {
        return this.apiService.create(this.host, this.apiEndPoint + "createLdapConfig", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    //to update a ldap config
    updateLdap(parameter?: any): Promise<any> {
        return this.apiService.update(this.host, this.apiEndPoint + "editLdapConfig", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    // to delete a ldap
    deleteLdap(parameter?: any): Promise<any> {
        return this.apiService.delete(this.host, this.apiEndPoint + "deleteLdapConfig?id=" + parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    // to delete a User Group
    deleteUserGroup(parameter?: any): Promise<any> {
        return this.apiService.delete(this.host, this.apiEndPoint + "deleteusergroup/" + parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }


}
