import { Component, ViewChild } from '@angular/core';
import { TabsetComponent, ModalDirective } from 'ng2-bootstrap';
import { AssemblyManagementConfig } from './assembly-management.config';
import { Cell } from '../table/lib/data-set/cell';

import { AssemblyManagementService } from './assembly-management.service';
import { AuthenticationService } from '../authentication/authentication.service';
import { TranslateService, TranslationChangeEvent } from '@ngx-translate/core';
import { AppConfig } from '../app.config';
import { Ng2SmartTableModule, LocalDataSource } from '../smart-table';
import { ToastrService } from 'ngx-toastr';
import { ToastConfig } from 'ngx-toastr';

const customConfig: ToastConfig = { enableHtml: true };
const customTimeOutMsg: ToastConfig = { timeOut: 8000 };

@Component({
  templateUrl: 'assembly-management.component.html',
  styleUrls: ['./assembly-management.component.css'],
  providers: [AssemblyManagementService]
})
export class AssemblyManagementComponent {

  @ViewChild('staticTabs') staticTabs: TabsetComponent;
  @ViewChild('markerModal') public markerModal: ModalDirective;
  @ViewChild('mediaModal') public mediaModal: ModalDirective;
  @ViewChild('productTypeDeleteModal') public productTypeDeleteModal: ModalDirective;
  @ViewChild('markerDeleteModal') public markerDeleteModal: ModalDirective;
  @ViewChild('mediaDeleteModal') public mediaDeleteModal: ModalDirective;
  @ViewChild('assemblyDeleteModal') public assemblyDeleteModal: ModalDirective;
  @ViewChild('workflowModal') public workflowModal: ModalDirective;
  @ViewChild('workflowDeleteModal') public workflowDeleteModal: ModalDirective;

  constructor(private assemblyManagementService: AssemblyManagementService, private translate: TranslateService, private notificationService: ToastrService, private authService: AuthenticationService) {
    this.checkPermissions();
    this.markerData = new LocalDataSource();
    this.productTypeData = new LocalDataSource();
    this.workFlowData = new LocalDataSource();
    this.translate.onLangChange.subscribe((event: TranslationChangeEvent) => {
      this.doTranslate();
    });
  }

  source: LocalDataSource; // add a property to the component
  markerSource: LocalDataSource; // add a property to the component

  public selectedTab: String = 'ASSEMBLY_MANAGEMENT.PRODUCT_TYPES';

  public assemblyManagementConfig = new AssemblyManagementConfig(this.translate, this.authService);
  public mediaUrl: String = new AppConfig().apiBase + "9001";

  public productTypeSettings: any = this.assemblyManagementConfig.productTypeSettings;
  public planSettings: any = this.assemblyManagementConfig.assemblyPlanSettings;
  public markerSettings: any = this.assemblyManagementConfig.markerSettings;
  public workflowSettings: any = this.assemblyManagementConfig.workflowSettings;
  public productTypeData: LocalDataSource;
  public markerData: LocalDataSource;
  public workFlowData: LocalDataSource;
  public mediaList: Array<any> = [];
  public selectedMedia: any;
  public selectedRow: any;
  public selectedProduct: any;
  public addMediaPermission: boolean = false;

  public selectedMediaLeft: any;
  public selectedMediaRight: any;
  public selectedMediaBeamer: any;
  public selectedMediaInfo: any;
  public selectedProductType: any;
  public selectedStepId: number;
  public selectedWorkflow: any;
  public selectedWorkflowforDelete: any;

  public tabs: any[] = [];
  public ScrewDriverList: any;
  public MaterialNumberList: any;
  public maxSize = new AppConfig().maxSize;

  public checkPermissions(): void {
    if (this.authService.appPermissions != undefined) {
      this.addMediaPermission = this.authService.appPermissions["Create/Change/Delete Media Data"];
    } else {
      this.authService.logout();
    }
  }


  /**
  * Product Type Table - CRUD and COPY OPERATIONS
  * getProductTypes() - to get the list of Product Types 
  * createProductType() - to create a new Product Type 
  * updateProductType() - to update a product type based on @param id 
  * copyProductType() - to clone a product type
  * deleteProductType() - to delete a product type based on @param id 
  * createDynamicTabs() - to create a new Dynamic Tabs [depends on {Get Assembly Plans}]
  */

  public getProductTypes(pagination): void {
    let _pagination = pagination || this.productTypeSettings.serverSidePagination;
    //call the assembly management service to get the data
    this.assemblyManagementService.getProductTypes(_pagination).then(res => {
      //load the data set to the table
      this.productTypeSettings.serverSidePagination.totalItems = res.size;
      this.productTypeData.load(res.content);
    }).catch(err => { console.log("Error: ", err); });
  };

  doTranslate() {
    this.assemblyManagementConfig.updateSettings();
    this.productTypeData.refresh();
  }

  public createProductType(row: any): void {

    //check all the required data are added
    if (row.newData.productTypeName == "" && row.newData.productTypeNumber == "")
      this.notificationService.warning("Kindly fill the -</br>1)Product Name</br>2)Production Number", "", customConfig);



    else if (row.newData.productTypeName == "")
      this.notificationService.warning("Kindly fill Product type Name");

    else if (row.newData.productTypeNumber == "")
      this.notificationService.warning("Kindly fill Product type number");

    //call the api and append th data
    else {
      row.newData.id = 0;
      this.assemblyManagementService.saveProductTypes(row.newData).then(res => {

        //add the data to the table
        row.confirm.resolve(res);
        this.getProductTypes({ itemsPerPage: 10, page: 1 });
      }).catch(err => { console.log("Error: ", err); });

    }
  };


  public updateProductType(row: any): void {

    //check all the required data are added
    if (row.newData.productTypeName == "" && row.newData.productTypeNumber == "")
      this.notificationService.warning("Kindly fill the -</br>1)Product Name</br>2)Production Number", "", customConfig);

    else if (row.newData.productTypeName == "")
      this.notificationService.warning("Kindly fill Product type Name");

    else if (row.newData.productTypeNumber == "")
      this.notificationService.warning("Kindly fill Product type number");

    //call the api and append th data
    else {
      //call the api and update the data
      this.assemblyManagementService.updateProductTypes(row.newData).then(res => {
        //update the data to the table
        row.confirm.resolve(res);
        this.getProductTypes({ itemsPerPage: 10, page: 1 });
      }).catch(err => { console.log("Error: ", err); });
    }
  };



  public deleteProductType(row: any): void {

    if (row && row.data) {
      //call the assembly service api and pass the product type id to delete the data
      this.assemblyManagementService.deleteProductTypes(row.data.id).then(res => {

        //delete the data from the table
        row.confirm.resolve();

        //hide the delete modal pop up
        this.productTypeDeleteModal.hide();
      }).catch(err => { console.log("Error: ", err); });
    }
  };


  public copyProductType(row: any): void {
    // console.log()
    //construct the data to post it to the back end
    let _newProductType = row.newData;
    //remove the parameters
    _newProductType.id = 0;
    _newProductType.productTypeNumber = "copy-of-" + _newProductType.productTypeNumber;
    //call the assembly management service and create a new product type
    this.assemblyManagementService.saveProductTypes(_newProductType).then(res => {
      console.log(res, "copy product");
      //add the data to the table
      row.confirm.resolve(res);
    }).catch(err => { console.log("Error: ", err); });
  };
  // public copyActiveAssist(row: any): void {
  //     //construct the data to post it to the back end
  //     let selecteActiveAssistData = row.newData;
  //     console.log("copy", selecteActiveAssistData);
  //     this.deviceManagementService.saveActiveAssist(selecteActiveAssistData).then(res => {
  //       //add the data to the table
  //       row.confirm.resolve(res);
  //     }).catch(err => { console.log("Error: ", err); });
  //   };




  /**
  * Marker Table - CRUD and COPY OPERATIONS
  * getMarkers() - to get the list of Marker
  * createMarker() - to create a new Marker
  * updateMarker() - to update a Marker based on @param id 
  * copyMarker() - to clone a marker
  * deleteMarker() - to delete a marker based on @param id 
  */


  public getMarkers(event: any, title: string): void {
    this.selectedStepId = event.row.data.stepId;
    //call the assembly management service to get the data
    this.assemblyManagementService.getMarker(this.selectedStepId).then(res => {

      //load the data set to the marker table
      this.markerData.load(res);

      //display the marker pop-up
      this.markerModal.show();

    }).catch(err => { console.log("Error: ", err); });
  };


  public createMarker(row: any): void {

    //check all the required data are added
    if (row.newData.name != "" && row.newData.form != "") {

      //append the step id for the marker
      row.newData.stepId = this.selectedStepId;

      //call the api and append th data
      this.assemblyManagementService.saveMarker(row.newData).then(res => {

        //add the data to the table
        row.confirm.resolve(res);
      }).catch(err => { console.log("Error: ", err); });
    } else if (row.newData.name == "" && row.newData.form == "")
      this.notificationService.warning("Kindly fill the -</br>1)Marker Name</br>2)Marker Form", "", customConfig);
    else if (row.newData.name == "")
      this.notificationService.warning("Kindly fill Marker Name");
    else if (row.newData.form == "")
      this.notificationService.warning("Kindly fill Marker Form");
    //notofy the user to fill all the fields


  };


  public updateMarker(row: any): void {

    //check all the required data are added
    if (row.newData.name != "" && row.newData.color != "" && row.newData.form != "") {

      //call the api and update the data
      this.assemblyManagementService.updateMarker(row.newData).then(res => {

        //update the data to the table
        row.confirm.resolve(res);
      }).catch(err => { console.log("Error: ", err); });
    } else {
      //notofy the user to fill all the fields
      this.notificationService.warning("Kindly fill the -</br>1)Marker Name</br>2)Marker Form", "", customConfig);
    }
  };


  public deleteMarker(row: any): void {

    if (row && row.data) {

      //call the assembly service api and pass the product type id to delete the data
      this.assemblyManagementService.deleteMarker(row.data.id).then(res => {

        //delete the data from the table
        row.confirm.resolve();

        //hide the delete modal pop up
        this.markerDeleteModal.hide();
      }).catch(err => { console.log("Error: ", err); });
    }
  };


  public copyMarker(row: any): void {

    //construct the data to post it to the back end
    let newMarker = row.newData;

    //remove the parameters
    newMarker.id = null;
    newMarker.name = "copy-of-" + newMarker.name;

    //call the assembly management service and create a new product type
    this.assemblyManagementService.saveProductTypes(newMarker).then(res => {

      //add the data to the table
      row.confirm.resolve(res);
    }).catch(err => { console.log("Error: ", err); });
  };


  /**
  * Media Table -  UPLOAD LIST and SELECT MEDIA
  * getMedia() - to get the list of Media files from the Database
  * uploadMedia() - to upload a new Media file
  */


  public getMedia(event: Cell, title: string): void {

    this.selectedRow = event;
    //call the assembly management service to get the data
    this.assemblyManagementService.getMedia().then(res => {

      //load the data set to the media list
      this.mediaList = res;
      this.selectedMedia = event.getValue();

      //display the media
      this.mediaModal.show();

    }).catch(err => { console.log("Error: ", err); });
  };


  public uploadMedia(event: any): void {
    if (this.addMediaPermission) {
      let media_flag = true;
      //get the file and file details and append to the form data
      let file: File = event.target.files[0];
      let formData: FormData = new FormData();
      formData.append('file', file, file.name);

      let mediaRight = file.name.substr(file.name.lastIndexOf('.') + 1);
      mediaRight = mediaRight.toUpperCase();
      console.log(mediaRight, "media");
      let mediaFormat = ["PNG", "JPEG", "JPG", "PDF", "DOC", "DOCX", "CSV", "GIF", "MP3", "MP4"];
      for (let i = 0; i <= mediaFormat.length; i++) {
        media_flag = false;
        if (mediaRight == mediaFormat[i]) {
          console.log(mediaRight, mediaFormat[i], "mediaright, mediaformat");
          media_flag = true;
          break;
        }
      }
      console.log(media_flag, "inside upload media");
      if (media_flag == false) {
        this.notificationService.warning("Kindly select proper Media Type");
      } else {

        //call the assembly service and upload the media
        this.assemblyManagementService.saveMedia(formData).then(res => {

          this.mediaList.push(res);
        }).catch(err => { console.log("Error: ", err); });

      }
    }else{
      this.notificationService.warning("You don't have permission to upload the media");
    }
  };

  public updateMedia(media, event: Cell) {
    // console.log("dsd",event);
    if (event.getRow().isInEditing) {
      event.setValue(media.mediaName);
      let _columnTitle = event.getColumn().title;
      switch (_columnTitle) {
        case "Media Left":
          this.selectedMediaLeft = media;
          this.closeMediaModal();
          break;
        case "Media Right":
          this.selectedMediaRight = media;
          this.closeMediaModal();
          break;
        case "Beamer Media":
          this.selectedMediaBeamer = media;
          this.closeMediaModal();
          break;
        case "Media Info":
          this.selectedMediaInfo = media;
          this.closeMediaModal();
          break;
      }
    }
  };

  public closeMediaModal() {
    this.mediaModal.hide();
    this.selectedMedia = null;
  }


  /**
  * Tabs Methods - DYNAMIC TABS, ACTIVE TABS, DELETE TABS
  * selectTab() - set the active tab based on @param index
  * removeTab() - remove a tab from the DOM based on @param index
  */


  public removeTab(event: any, index: number): void {

    //remove the tab data from the tabs array, tabs and DOM
    this.tabs.splice(index, 1);
    this.staticTabs.tabs.splice(index + 1, 1);
    event.parentNode.parentNode.parentNode.removeChild(event.parentNode.parentNode);

    //make another tab active in a short delay
    setTimeout(() => {
      this.selectTab(index);
    }, 100);

  };


  public selectTab(index: number) {
    this.staticTabs.tabs[index].active = true;

    if (this.tabs[index - 1])
      this.selectedProduct = this.tabs[index - 1].product;
  }


  /**
  * Assembly Plan Table - CRUD, MOVE and COPY OPERATIONS
  * getAssemblyPlanSteps() - to get the list of Assembly plans steps
  * createAssemblyPlanStep() - to create a new Assembly plan
  * updateAssemblyPlanStep() - to update a Assembly plan step
  * copyAssemblyPlanStep() - to clone a Assembly plan step
  * deleteAssemblyPlanSteps() - to delete a Assembly plan step
  * swapAssemblyPlanSteps() - to swap or move the Assembly plan step positions based on @param stepNumber
  * onAssemblyPlanTableCellClick() - trigger the marker and media based on cell click of table in assembly plan
  */
  // public productClick=false;

  public createDynamicTabs(tabData: any, product: any) {
    //construct the Tab Data
    //  let res_data=tabData;
    // if(res_data.timestamp==null)
    // res_data.timestamp="";
    //console.log(res_data,"next tab data", tabData,"resposedata in create dynamic tab,",product);
    console.log("tabs>>", this.tabs);
    if (this.tabs.length > 0) {
      if (this.checkDuplicateTabs(product)) {
        let _data = {
          title: product.data.productTypeName,
          tableData: tabData,
          active: true,
          removable: true,
          disabled: false,
          product: product.data
        };
        console.log(this.tabs, "Inside createdynamic tab function");

        //push the Tab data to Tab array to dynamically create the Tabs
        this.tabs.push(_data);
        this.selectedProduct = product.data;
        //  this.productClick=true;
      }
    } else {
      let _data = {
        title: product.data.productTypeName,
        tableData: tabData,
        active: true,
        removable: true,
        disabled: false,
        product: product.data
      };
      console.log(this.tabs, "Inside createdynamic tab function");

      //push the Tab data to Tab array to dynamically create the Tabs
      this.tabs.push(_data);
      this.selectedProduct = product.data;
    }



  };

  public checkDuplicateTabs(product): boolean {
    console.log("dsds>>", this.tabs, product);
    for (let i = 0; i < this.tabs.length; i++) {
      console.log("dat6a>.", this.tabs[i].product.productTypeNumber == product.data.productTypeNumber);
      if (this.tabs[i].product.productTypeNumber == product.data.productTypeNumber) {
        setTimeout(() => {
          this.selectTab(i + 1);
        }, 100);
        return false;
      }
    }
    return true;
  }

  public getAssemblyPlanSteps(productType: any): void {
    //check the product type has product type number
    if (productType) {
      //call the assembly management service to get the assembly plan details
      this.assemblyManagementService.getAssemblyPlanSteps(productType.data.productTypeNumber).then(res => {
        // if(this.productClick==false)
        this.createDynamicTabs(res, productType);
      }).catch(err => { console.log("Error: ", err); });
    }

  };

  //validate the assembly step details
  public validateAssemplyStepValues(data: any): boolean {
    let flag_assembly = false;
    console.log("data>>", data);

    if (data.type == "") {
      this.notificationService.warning("Kindly fill Step type");
      return false;
    }

    if (data.mediaIdLeftName != "") {
      let mediaL_flag = false;
      let mediaLeft = data.mediaIdLeftName.substr(data.mediaIdLeftName.lastIndexOf('.') + 1);
      mediaLeft = mediaLeft.toUpperCase();
      console.log(mediaLeft, "media left validation");
      let mediaFormat = ["PNG", "JPEG", "JPG", "PDF", "DOC", "DOCX", "CSV", "GIF", "MP3", "MP4"];
      for (let i = 0; i <= mediaFormat.length; i++) {
        mediaL_flag = false;
        if (mediaLeft == mediaFormat[i]) {
          mediaL_flag = true;
          break;
        }
      }
      if (mediaL_flag == false) {
        this.notificationService.warning("Kindly select proper  Left Media");
      }
    }

    else if (data.mediaIdRightName != "") {
      let mediaR_flag = false;
      let mediaRight = data.mediaIdRightName.substr(data.mediaIdRightName.lastIndexOf('.') + 1);
      mediaRight = mediaRight.toUpperCase();

      let mediaFormatR = ["PNG", "JPEG", "JPG", "PDF", "DOC", "DOCX", "CSV", "GIF", "MP3", "MP4"];
      for (let i = 0; i <= mediaFormatR.length; i++) {
        mediaR_flag = false;
        if (mediaRight == mediaFormatR[i]) {
          mediaR_flag = true;
          break;
        }
      }
      if (mediaR_flag == false) {

        this.notificationService.warning("Kindly select proper Right Media ");
      }

    }
    //     //Media info
    else if (data.mediaIdInfoName != "") {

      let mediaInfo_flag = false;
      let mediaInfo = data.mediaIdInfoName.substr(data.mediaIdInfoName.lastIndexOf('.') + 1);
      mediaInfo = mediaInfo.toUpperCase();

      let mediaFormatInfo = ["PNG", "JPEG", "JPG", "PDF", "DOC", "DOCX", "CSV", "GIF", "MP3", "MP4"];
      for (let i = 0; i <= mediaFormatInfo.length; i++) {
        mediaInfo_flag = false;
        if (mediaInfo == mediaFormatInfo[i]) {
          mediaInfo_flag = true;
          break;
        }
      }
      if (mediaInfo_flag == false) {
        this.notificationService.warning("Kindly select proper Media Info");
      }
    }
    //     //Beamer
    else if (data.mediaIdBeamerName != "") {
      let beamer_flag = false;
      let mediaBeamer = data.mediaIdBeamerName.substr(data.mediaIdBeamerName.lastIndexOf('.') + 1);
      mediaBeamer = mediaBeamer.toUpperCase();

      let mediaFormatBeamer = ["PNG", "JPEG", "JPG", "PDF", "DOC", "DOCX", "CSV", "GIF", "MP3", "MP4"];
      for (let i = 0; i <= mediaBeamer.length; i++) {
        beamer_flag = false;
        if (mediaBeamer == mediaBeamer[i]) {
          beamer_flag = true;
          break;
        }
      }
      if (beamer_flag == false) {
        this.notificationService.warning("Kindly select proper Beamer");
      }


    }
    // if (data.mediaIdLeftName == "") {
    //   this.notificationService.warning("Kindly select left media");
    //   return false;
    // }

    // if (data.mediaIdRightName == "") {
    //   this.notificationService.warning("Kindly select right media");
    //   return false;
    // }
    // if (data.mediaIdBeamerName == "") {
    //   this.notificationService.warning("Kindly select beamer media");
    //   return false;
    // }

    // if (data.mediaIdInfoName == "") {
    //   this.notificationService.warning("Kindly select info media");
    //   return false;
    // }

    // if (data.workflowName == "") {
    //   this.notificationService.warning("Kindly select a workflow");
    //   return false;
    // }
    if (parseInt(data.quantity) <= 0) {
      this.notificationService.warning("Quantity should not be less than zero");
      return false;
    }
    if (data.stepExecutionTime > 1000) {
      this.notificationService.warning("Kindly enter >1000 seconds");
      return false;
    }

    // if (parseInt(data.viewNumber) < -10) {
    //   this.notificationService.warning("View number should not be less than zero");
    //   return false;
    // }
    if (data.quantity) {
      var re = new RegExp("[1-9][0-9]*");
      if (re.test(data.quantity.toString())) {
      } else {
        this.notificationService.warning("Kindly fill the Numeric Value for Position");
        flag_assembly = true;

      } console.log(flag_assembly, "flag value");
    }
    if (data.viewNumber) {
      var re = new RegExp("[1-9][0-9]*");
      if (re.test(data.viewNumber.toString())) {
      } else {
        this.notificationService.warning("Kindly fill the Numeric Value for Position");
        flag_assembly = true;
      }
    }

    return true;
  };

  public createAssemblyPlanStep(stepData: any, productType: any): void {
    console.log("StepData>>", stepData, this.selectedProduct);
    let _data = stepData.newData;
    let _productType = productType;

    //     if(isNaN(_data.quantity))
    //     _data.quantity=1;
    // if(isNaN(_data.viewNumber))
    //     _data.viewNumber=0;
    if (this.validateAssemplyStepValues(stepData.newData)) {


      console.log("data before parse", _data);
      let _stepData = {
        "assemblyPlanId": this.selectedProduct.assemblyPlanId,
        "stepDescription": _data.stepDescription,
        "deviceTypeId": _data.deviceTypeId,
        "ignoreInputs": _data.ignoreInputs == "" ? false : _data.ignoreInputs,
        "mediaIdBeamer": this.selectedMediaBeamer ? this.selectedMediaBeamer.id : _data.mediaIdBeamer,
        "mediaIdInfo": this.selectedMediaInfo ? this.selectedMediaInfo.id : _data.mediaIdInfo,
        "mediaIdLeft": this.selectedMediaLeft ? this.selectedMediaLeft.id : _data.mediaIdLeft,
        "mediaIdRight": this.selectedMediaRight ? this.selectedMediaRight.id : _data.mediaIdRight,
        "mediaIdBeamerName": this.selectedMediaBeamer ? this.selectedMediaBeamer.mediaName : _data.mediaIdBeamerName,
        "mediaIdInfoName": this.selectedMediaInfo ? this.selectedMediaInfo.mediaName : _data.mediaIdInfoName,
        "mediaIdLeftName": this.selectedMediaLeft ? this.selectedMediaLeft.mediaName : _data.mediaIdLeftName,
        "mediaIdRightName": this.selectedMediaRight ? this.selectedMediaRight.mediaName : _data.mediaIdRightName,
        "projectionAreaName": _data.projectionAreaName,
        "stepName": _data.stepName,
        "note": _data.note,
        "stepNumber": stepData.source.data[0] ? 0 : 1,
        "stepTitle": _data.stepName,
        "type": _data.type,
        "viewNumber": _data.viewNumber,
        "workflowId": this.selectedWorkflow ? this.selectedWorkflow.id : _data.workflowId,
        "materialNumber": _data.materialNumber,
        "quantity": _data.quantity,
        "stepExecutionTime": _data.stepExecutionTime,
        "workflowName": this.selectedWorkflow ? this.selectedWorkflow.workflowName : _data.workflowName
      };
      if (_stepData.mediaIdBeamer == undefined)
        _stepData.mediaIdBeamer = 0;
      if (_stepData.mediaIdInfo == undefined)
        _stepData.mediaIdInfo = 0;
      if (_stepData.mediaIdLeft == undefined)
        _stepData.mediaIdLeft = 0;
      if (_stepData.mediaIdRight == undefined)
        _stepData.mediaIdRight = 0;
      if (_stepData.workflowId == undefined)
        _stepData.workflowId = 0;

      if (_stepData.stepExecutionTime > 1000) {
        this.notificationService.warning("Kindly enter lesser than 1000 seconds");
      }
      // else{
      console.log("stepdata", _stepData);
      this.assemblyManagementService.saveAssemblyPlanSteps(_stepData).then(res => {
        // console.log("step data in creation",_stepData);
        //add the step data to the table

        stepData.confirm.resolve(res);
        this.getAssemblyPlanSteps(_productType);
        this.resetSelectedMedia();
      }).catch(err => { console.log("Error: ", err); });
      // }
    }
  };

  public resetSelectedMedia(): void {
    this.selectedMediaBeamer = 0;
    this.selectedMediaInfo = 0;
    this.selectedMediaLeft = 0;
    this.selectedMediaRight = 0;
  };

  public updateAssemblyPlanStep(stepData: any): void {
    console.log("StepData>>", stepData);

    let _data = stepData.newData;

    if (this.validateAssemplyStepValues(_data)) {

      let _stepData = {
        "assemblyPlanId": this.selectedProduct.assemblyPlanId,
        "stepDescription": _data.stepDescription,
        "deviceTypeId": _data.deviceTypeId,
        "ignoreInputs": _data.ignoreInputs ? true : false,
        "mediaIdBeamer": this.selectedMediaBeamer ? this.selectedMediaBeamer.id : _data.mediaIdBeamer,
        "mediaIdInfo": this.selectedMediaInfo ? this.selectedMediaInfo.id : _data.mediaIdInfo,
        "mediaIdLeft": this.selectedMediaLeft ? this.selectedMediaLeft.id : _data.mediaIdLeft,
        "mediaIdRight": this.selectedMediaRight ? this.selectedMediaRight.id : _data.mediaIdRight,
        "mediaIdBeamerName": this.selectedMediaBeamer ? this.selectedMediaBeamer.mediaName : _data.mediaIdBeamerName,
        "mediaIdInfoName": this.selectedMediaInfo ? this.selectedMediaInfo.mediaName : _data.mediaIdInfoName,
        "mediaIdLeftName": this.selectedMediaLeft ? this.selectedMediaLeft.mediaName : _data.mediaIdLeftName,
        "mediaIdRightName": this.selectedMediaRight ? this.selectedMediaRight.mediaName : _data.mediaIdRightName,
        "projectionAreaName": _data.projectionAreaName,
        "stepName": _data.stepName,
        "note": _data.note,
        "stepNumber": parseInt(_data.stepNumber),
        "stepTitle": _data.stepName,
        "type": _data.type,
        "viewNumber": _data.viewNumber,
        "stepExecutionTime": _data.stepExecutionTime,
        "workflowId": this.selectedWorkflow ? this.selectedWorkflow.id : _data.workflowId,
        "materialNumber": _data.materialNumber,
        "quantity": _data.quantity,
        "workflowName": this.selectedWorkflow ? this.selectedWorkflow.workflowName : _data.workflowName,
        "stepId": _data.stepId
      };

      if (_stepData.mediaIdBeamer == undefined)
        _stepData.mediaIdBeamer = 0;
      if (_stepData.mediaIdInfo == undefined)
        _stepData.mediaIdInfo = 0;
      if (_stepData.mediaIdLeft == undefined)
        _stepData.mediaIdLeft = 0;
      if (_stepData.mediaIdRight == undefined)
        _stepData.mediaIdRight = 0;
      if (_stepData.workflowId == undefined)
        _stepData.workflowId = 0;
      if (_stepData.stepExecutionTime > 1000) {
        this.notificationService.warning("Kindly enter lesser than 1000 seconds");
      }
      this.assemblyManagementService.updateAssemblyPlanSteps(_stepData).then(res => {

        //add the step data to the table
        stepData.confirm.resolve(res);

        this.resetSelectedMedia();
      }).catch(err => { console.log("Error: ", err); });

    }

  };

  public copyAssemblyPlanStep(stepData: any): void {

    let _length = stepData.source.data.length;
    let _stepNumber = stepData.source.data[0].stepNumber + 1;
    console.log("StepData>>", stepData, this.selectedProduct);

    let _data = stepData.newData;

    if (this.validateAssemplyStepValues(_data)) {
      let _stepData = {
        "assemblyPlanId": this.selectedProduct.assemblyPlanId,
        "stepDescription": _data.stepDescription,
        "deviceTypeId": _data.deviceTypeId,
        "ignoreInputs": _data.ignoreInputs ? true : false,
        "mediaIdBeamer": _data.mediaIdBeamer,
        "mediaIdInfo": _data.mediaIdInfo,
        "mediaIdLeft": _data.mediaIdLeft,
        "mediaIdRight": _data.mediaIdRight,
        "mediaIdBeamerName": _data.mediaIdBeamerName,
        "mediaIdInfoName": _data.mediaIdInfoName,
        "mediaIdLeftName": _data.mediaIdLeftName,
        "mediaIdRightName": _data.mediaIdRightName,
        "projectionAreaName": _data.projectionAreaName,
        "stepName": _data.stepName,
        "note": _data.note,
        "stepNumber": _stepNumber,
        "stepTitle": _data.stepName,
        "type": _data.type,
        "viewNumber": _data.viewNumber,
        "stepExecutionTime": _data.stepExecutionTime,
        "workflowId": _data.workflowId,
        "materialNumber": "copy-of-" + _data.materialNumber,
        "quantity": _data.quantity,
        "workflowName": _data.workflowName
      };
      if (_stepData.mediaIdBeamer == undefined)
        _stepData.mediaIdBeamer = 0;
      if (_stepData.mediaIdInfo == undefined)
        _stepData.mediaIdInfo = 0;
      if (_stepData.mediaIdLeft == undefined)
        _stepData.mediaIdLeft = 0;
      if (_stepData.mediaIdRight == undefined)
        _stepData.mediaIdRight = 0;
      if (_stepData.workflowId == undefined)
        _stepData.workflowId = 0;
      console.log(_stepData, "step data in creation ")
      if (_stepData.stepExecutionTime > 1000) {
        this.notificationService.warning("Kindly enter lesser than 1000 seconds");
      }

      this.assemblyManagementService.saveAssemblyPlanSteps(_stepData).then(res => {

        //add the step data to the table
        stepData.confirm.resolve(res);

        // this.resetSelectedMedia();
      }).catch(err => { console.log("Error: ", err); });
    }
  };

  public swapAssemblyPlanSteps(event): void {
    console.log("event>>", event);

    // //call the api to swap the data
    this.assemblyManagementService.swapAssemblyPlanSteps(event.swap).then(res => {
      event.confirm.resolve();
    }).catch(err => { console.log("Error: ", err); });
  };

  public deleteAssemblyPlanSteps(step: any): void {
    let _step = step.data;
    //check if assembly plan id and step id exists
    if (_step.assemblyPlanId && _step.stepId) {

      //call the assembly management service and delete the step based in step id
      this.assemblyManagementService.deleteAssemblyPlanSteps(_step.assemblyPlanId, _step.stepNumber).then(res => {

        //call the assembly management service to get the assembly plan details
        this.assemblyManagementService.getAssemblyPlanSteps(this.selectedProduct.productTypeNumber).then(res => {
          step.source.load(res);
          this.assemblyDeleteModal.hide();
        }).catch(err => { console.log("Error: ", err); });
      }).catch(err => { console.log("Error: ", err); });
    }
  };


  public onAssemblyPlanTableCellClick(event: Cell) {
    //console.log("view mode", event, event.getColumn().title);
    let _columnTitle = event.getColumn().title;
    //console.log(event);
    if (_columnTitle == "Marker" && !event.getRow().isInEditing) {
      this.getMarkers(event, _columnTitle);
    } else if (_columnTitle.indexOf("Media") > -1 && event.getRow().isInEditing) {
      this.getMedia(event, _columnTitle);
    } else if (_columnTitle.indexOf("Workflow") > -1) {
      if (event.getRow().isInEditing)
        this.getWorkflow(event, _columnTitle, "");
    }
  };



  /**
  * Workflow Table - CRUD  OPERATIONS
  * getWorkflow() - to get the list of Workflow
  * createWorkflow() - to create a new Workflow
  * updateWorkflow() - to update a Workflow based on @param id 
  * deleteWorkflow() - to delete a Workflow based on @param id 
  */



  public getWorkflow(event: Cell, title: string, pagination): void {
    let _pagination = pagination || this.workflowSettings.serverSidePagination;
    //call the assembly management service to get the data
    this.assemblyManagementService.getWorkflow(_pagination).then(res => {
      //load the data set to the Workflow table
      this.workflowSettings.serverSidePagination.totalItems = res.size;
      this.workFlowData.load(res.content);
      //display the marker pop-up
      this.workflowModal.show();

      this.selectedRow = event;

    }).catch(err => { console.log("Error: ", err); });
  };


  public createWorkflow(row: any): void {

    //check all the required data are added
    if (row.newData.workflowNumber != "" && row.newData.workflowName != "" && row.newData.description != "") {

      //call the api and append th data
      this.assemblyManagementService.saveWorkflow(row.newData).then(res => {

        //add the data to the table
        row.confirm.resolve(res);
        this.getWorkflow(this.selectedRow, "", { itemsPerPage: 10, page: 1 })
      }).catch(err => { console.log("Error: ", err); });
    } else if (row.newData.workflowNumber == "" && row.newData.workflowName == "" && row.newData.description == "")
      this.notificationService.warning("Kindly fill the -</br>1)Workflow  Number</br>2)workflow Name</br>3)Workflow Description", "", customConfig);
    else if (row.newData.workflowNumber == "")
      this.notificationService.warning("Kindly fill the -</br>1)Workflow  Number");
    else if (row.newData.workflowName == "")
      this.notificationService.warning("Kindly fill the -</br>1)Workflow  Name");
    else if (row.newData.description == "")
      this.notificationService.warning("Kindly fill the -</br>1)Workflow  description");

  };


  public updateWorkflow(row: any): void {

    //check all the required data are added
    if (row.newData.workflowNumber != "" && row.newData.workflowName != "" && row.newData.description != "") {

      //call the api and update the data
      this.assemblyManagementService.updateWorkflow(row.newData).then(res => {

        //update the data to the table
        row.confirm.resolve(res);
      }).catch(err => { console.log("Error: ", err); });
    } else {
      //notofy the user to fill all the fields
      this.notificationService.warning("Kindly fill the -</br>1)Workflow  Number</br>2)workflow Name</br>3)Workflow Description", "", customConfig);
    }
  };


  public deleteWorkflow(row: any): void {

    if (row && row.data) {
      this.workflowDeleteModal.hide();
      //call the assembly service api and pass the product type id to delete the data
      this.assemblyManagementService.deleteWorkflow(row.data.id).then(res => {

        //delete the data from the table
        row.confirm.resolve();
        this.getWorkflow(this.selectedRow, "", { itemsPerPage: 10, page: 1 })
        //hide the delete modal pop up
      }).catch(err => { console.log("Error: ", err); });
    }
  };

  public onWorkflowSelect(row: any): void {
    this.selectedWorkflow = row.data;
    this.selectedRow.setValue(row.data.workflowName);
    this.workflowModal.hide();
  }
  //to get list of screw driver
  assemblyTabClickScrewDriverDropdown() {

    this.assemblyManagementService.getDeviceType().then(res => {
      this.ScrewDriverList = res;
      this.planSettings.columns.deviceTypeId.editor.config.list = this.ScrewDriverList.map((list) => {
        return { value: list.name, title: list.name, id: list.typeId };

      });

      this.planSettings = Object.assign({}, this.planSettings);
    }).catch(err => { console.log("Error: ", err); });
  }

  //to get list of screw driver
  assemblyTabClickMaterialNumberDropdown() {

    this.assemblyManagementService.getAllMaterialNumber().then(res => {
      this.MaterialNumberList = res;
      this.planSettings.columns.materialNumber.editor.config.list = this.MaterialNumberList.map((list) => {
        return { value: list.materialNumber, title: list.materialNumber + "_" + list.materialName, id: list.typeId };

      });

      this.planSettings = Object.assign({}, this.planSettings);
    }).catch(err => { console.log("Error: ", err); });
  }



  //on page load
  ngOnInit() {
    this.assemblyTabClickMaterialNumberDropdown();
    this.assemblyTabClickScrewDriverDropdown();
    this.getProductTypes({ itemsPerPage: 10, page: 1 });
    // this.planSettings.columns.ignoreInputs.editor.config.list =this.planSettings.columns.ignoreInputs.editor.config.list ;

    //to get list of matirial nuber

  }
  //Pagination for product Type 
  public pageChangedProductType(pagination): void {
    console.log("UID pagination ", pagination);
    this.getProductTypes(pagination);
  };
  public pageChangedWorkFLow(pagination): void {
    console.log("UID pagination", pagination);
    this.getWorkflow(this.selectedRow, "", pagination);

  };




}
