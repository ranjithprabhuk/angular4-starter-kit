import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AssemblyManagementComponent } from './assembly-management.component';

const routes: Routes = [
  {
    path: '',
    component: AssemblyManagementComponent,
    data: {
      title: 'Assembly Management'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AssemblyManagementRoutingModule {}
