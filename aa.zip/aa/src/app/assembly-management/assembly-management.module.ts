import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { TranslateModule } from '@ngx-translate/core';
import { TabsModule,ModalModule, PaginationModule } from 'ng2-bootstrap';
import { Ng2SmartTableModule } from '../smart-table';




import { AssemblyManagementComponent } from './assembly-management.component';
import { AssemblyManagementRoutingModule } from './assembly-management-routing.module';

@NgModule({
  imports: [
    CommonModule,
    TranslateModule,
    FormsModule,
    AssemblyManagementRoutingModule,
    Ng2SmartTableModule,
    TabsModule.forRoot(),
    ModalModule.forRoot(),
    PaginationModule.forRoot()
  ],
  declarations: [ AssemblyManagementComponent ]
})
export class AssemblyManagementModule { }
