import { TranslateService, TranslationChangeEvent } from '@ngx-translate/core';

import { AuthenticationService } from '../authentication/authentication.service';

export class AssemblyManagementConfig {

    constructor(private translate: TranslateService, private authService: AuthenticationService) {
        this.checkPermissions();
    }
    public tablePermissions: boolean = true;

    public checkPermissions(): void {
        if (this.authService.appPermissions == undefined) {
            this.authService.logout();
        }
    }

    public getWorkflowPermissions(): boolean {
        if (this.authService.appPermissions != undefined) {
            return this.authService.appPermissions["Create/Change/Delete Workflows"];
        } else {
            this.authService.logout();
        }
    }

    //pagination  settings
    public paginationSettings: Object = {
        display: false,
        perPage: 10
    };
    //table configuration for Product Types Tab
    public productTypeSettings: Object = {

        actions: {
            columnTitle: "Actions",
            add: true,
            edit: true,
            delete: true,
            copy: true,
            move: false,
            sort: true,
            position: 'left', // left|right
            // reset:true
        },

        columns: {
            productTypeNumber: {
                title: this.translate.instant("ASSEMBLY_MANAGEMENT.PRODUCT_TYPE_NUMBER"),
                filter: true,
                minWidth: "200px"
            },
            productTypeName: {
                title: this.translate.instant("ASSEMBLY_MANAGEMENT.PRODUCT_TYPE_NAME"),
                filter: true,
                minWidth: "200px"
            }
        },
        pager: this.paginationSettings,
        serverSidePagination: {
            itemsPerPage: 10,
            page: 1,
            totalItems: 0
        }
    };

    //table configuration for Workflow Table
    public workflowSettings: Object = {

        actions: {
            columnTitle: 'Actions',
            add: this.getWorkflowPermissions(),
            edit: this.getWorkflowPermissions(),
            delete: this.getWorkflowPermissions(),
            copy: false,
            move: false,
            position: 'left', // left|right
        },

        columns: {
            workflowNumber: {
                title: 'Workflow Number',
                filter: true,
                minWidth: "150px"
            },
            workflowName: {
                title: 'Workflow Name',
                filter: true,
                minWidth: "150px"
            },
            description: {
                title: 'Description',
                filter: true,
                minWidth: "200px"
            }
        },
        pager: this.paginationSettings,
        serverSidePagination: {
            itemsPerPage: 10,
            page: 1,
            totalItems: 0
        }
    };

    //table configuration for Marker
    public markerSettings: Object = {

        actions: {
            columnTitle: 'Actions',
            add: true,
            edit: true,
            delete: true,
            copy: false,
            position: 'left', // left|right
        },

        columns: {
            name: {
                title: 'Marker Name',
                filter: true,
            },
            color: {
                title: 'Color',
                filter: true,
                type: "color"
            },
            form: {
                title: 'Form',
                filter: true,
                editor: {
                    type: 'list',
                    config: {
                        selectText: 'Select...',
                        list: [
                            { value: 'circle', title: 'circle' },
                            { value: 'square', title: 'square' },
                            { value: 'triangle', title: 'triangle' },
                            { value: 'arrow', title: 'arrow' },
                            { value: 'custom', title: 'custom' },
                        ],
                    }
                }
            }
        },
        pager: {
            display: true,
            perPage: 250
        }
    };

    //table configuration for Assembly Plan Tab
    public assemblyPlanSettings: Object = {

        actions: {
            columnTitle: 'Actions',
            add: true,
            edit: true,
            delete: true,
            copy: true,
            move: true,
            position: 'left', // left|right,
            minWidth: "123px"
        },
        style: {
            minWidth: "1200px"
        },

        columns: {
            stepNumber: {
                title: 'Step Number',
                filter: true,
                minWidth: "150px",
                disabled: true
            },
            stepName: {
                title: 'Step Name',
                filter: true,
                minWidth: "150px"
            },
            type: {
                title: 'Step Type',
                filter: true,
                minWidth: "150px",
                editor: {
                    type: 'list',
                    config: {
                        selectText: 'Select...',
                        list: [
                            { value: 'Assemble', title: 'Assemble' },
                            { value: 'Confirm Assemble', title: 'Confirm Assemble' },
                            { value: 'Pick', title: 'Pick' },
                            { value: 'Confirm Pick', title: 'Confirm Pick' },
                            { value: 'PickRfid', title: 'PickRfid' },
                            { value: 'Nexo', title: 'Nexo' },
                            { value: 'Pack', title: 'Pack' },
                            { value: 'Activate Screw Driver', title: 'Activate Screw Driver' },
                            { value: 'De-Activate Screw Driver', title: 'De-Activate Screw Driver' },
                            { value: 'Confirm Interaction', title: 'Confirm Interaction' },
                        ],
                    }
                }
            },
            stepDescription: {
                title: 'Step Description',
                filter: true,
                minWidth: "200px"
            },
            note: {
                title: 'Step Note',
                filter: true,
                minWidth: "200px"
            },
            mediaIdLeftName: {
                title: 'Media Left',
                filter: true,
                minWidth: "150px",
                detailsIcon: true
            },
            mediaIdRightName: {
                title: 'Media Right',
                filter: true,
                minWidth: "150px",
                detailsIcon: true
            },
            mediaIdBeamerName: {
                title: 'Beamer Media',
                filter: true,
                minWidth: "150px",
                detailsIcon: true
            },
            mediaIdInfoName: {
                title: 'Media Info',
                filter: true,
                minWidth: "150px",
                detailsIcon: true
            },
            projectionAreaName: {
                title: 'Marker',
                filter: true,
                minWidth: "150px",
                detailsIcon: true,
                disabled: true
            },
            workflowName: {
                title: 'Workflow',
                filter: true,
                minWidth: "150px"
            },
            materialNumber: {
                title: 'Material Number',
                filter: true,
                minWidth: "200px",
                detailsIcon: true,
                editor: {
                    type: 'list',
                    config: {
                        selectText: "Select...",
                        list: [

                            { value: '', title: '' }

                        ],
                    }
                }
            },
            quantity: {
                title: 'Quantity',
                filter: true,
                type: 'number',
                minWidth: "150px"
            },
            deviceTypeId: {
                title: 'Screw Driver Type',
                filter: true,
                minWidth: "150px",
                editor: {
                    type: 'list',
                    config: {
                        selectText: "Select...",
                        list: [

                            { value: '', title: '' }

                        ],
                    }
                }
            },
            // pos: {
            //     title: 'POS',
            //     filter: true,
            //     minWidth: "150px"
            // },
            ignoreInputs: {
                title: 'Ignore Inputs',
                filter: true,
                minWidth: "150px",
                class: "false",
                editor: {
                    type: 'list',
                    config: {
                        preventdefault: 'false',
                        selectText: "Select...",
                        value: 'false',
                        list: [

                            { value: 'false', title: 'false' },
                            { value: 'true', title: 'true' }

                        ],
                    }
                }
            },
            viewNumber: {
                title: 'View Number',
                filter: true,
                type: 'Number',
                minWidth: "150px"
            },
            stepExecutionTime:
            {
                title: 'Planned Step Execution Time (in Sec)',
                filter: true,
                type: 'Number',
                minWidth: "150px"
            },
            timestamp: {
                title: 'Last Edited',
                filter: true,
                minWidth: "150px",
                disabled: true
            }
        },
        pager: {
            display: true,
            perPage: 250
        }
    };

    public updateSettings() {
        this.productTypeSettings = {

            actions: {
                columnTitle: "Actions",
                add: true,
                edit: true,
                delete: true,
                copy: true,
                move: false,
                sort: true,
                position: 'left', // left|right
                // reset:true
            },

            columns: {
                productTypeNumber: {
                    title: this.translate.instant("ASSEMBLY_MANAGEMENT.PRODUCT_TYPE_NUMBER"),
                    filter: true,
                    minWidth: "200px"
                },
                productTypeName: {
                    title: this.translate.instant("ASSEMBLY_MANAGEMENT.PRODUCT_TYPE_NAME"),
                    filter: true,
                    minWidth: "200px"
                }
            },
            pager: this.paginationSettings,
            serverSidePagination: {
                itemsPerPage: 10,
                page: 1,
                totalItems: 0
            }
        };
    }
}