import { Injectable } from '@angular/core';
import { URLSearchParams } from '@angular/http';
import { ApiService } from '../app.service';

import 'rxjs/add/operator/toPromise';


@Injectable()
export class AssemblyManagementService {

    constructor(private apiService: ApiService) {
        //this.getDetails();
    }

    //protected apiEndPoint: string = this.apiService.baseUrl.assemblyManagementServicePort +"/";
    protected apiEndPoint: string = "";

    public host = "assemblyManagementService";

    getDetails(): void {
        this.getExternalProperties().then((res) => {
            this.apiEndPoint = res.assemblyManagementServicePort + "/";
        });
    }

    getExternalProperties(): Promise<any> {
        return this.apiService.getExternalApplicationProperties().then(res => { return Promise.resolve(res) });
    }

    //to get the assembly table data
    getTableData(parameter?: any): Promise<any> {
        let params: URLSearchParams = new URLSearchParams();
        return this.apiService.get(this.host, this.apiEndPoint, params)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    //to get the list of Product Types
    getProductTypes(parameter?: any): Promise<any> {
        let params: URLSearchParams = new URLSearchParams();
        parameter.page = parameter.page - 1;
        params.append("page", parameter.page);
        params.append("size", parameter.itemsPerPage);
        return this.apiService.get(this.host, this.apiEndPoint + "getProductTypes?" + params)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }



    //to save a new Product Type
    saveProductTypes(parameter?: any): Promise<any> {
        console.log("inside as service");
        return this.apiService.create(this.host, this.apiEndPoint + "saveProductType", parameter)
            .then(res => {console.log("inside as successs"); return Promise.resolve(res) })
            .catch(err => {console.log("inside as failure"); return Promise.reject(err) });
    }

    //to update a particular data in the product types
    updateProductTypes(parameter?: any): Promise<any> {
        return this.apiService.update(this.host, this.apiEndPoint + "updateProductType", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    //to delete a particular data in the product types
    deleteProductTypes(parameter?: any): Promise<any> {
        let params = "?productTypeId=" + parameter;
        return this.apiService.delete(this.host, this.apiEndPoint + "deleteProductType" + params)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    //to get the list of Media
    getMedia(parameter?: any): Promise<any> {
        return this.apiService.get(this.host, this.apiEndPoint + "assemblyplan/getAllMedia")
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }


    //to save a new Media
    saveMedia(parameter?: any): Promise<any> {
        return this.apiService.create(this.host, this.apiEndPoint + "assemblyplan/uploadMedia", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    //to update a Media
    updateMedia(parameter?: any): Promise<any> {
        return this.apiService.upload(this.host, this.apiEndPoint + "assemblyplan/updateMedia", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    //to delete a Media
    deleteMedia(parameter?: any): Promise<any> {
        let params = "?productTypeId=" + parameter;
        return this.apiService.delete(this.host, this.apiEndPoint + "assemblyplan/deleteMedia" + params)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    //to get the list of Markers
    getMarker(parameter?: any): Promise<any> {
        //  let params : URLSearchParams = new URLSearchParams();
        // params.append("",parameter);       
        let params = "?stepId=" + parameter;
        return this.apiService.get(this.host, this.apiEndPoint + "getProjectionAreaForStep" + params)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }


    //to save a new Marker
    saveMarker(parameter?: any): Promise<any> {
        return this.apiService.create(this.host, this.apiEndPoint + "saveProjectionArea", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    //to update a Marker
    updateMarker(parameter?: any): Promise<any> {
        return this.apiService.update(this.host, this.apiEndPoint + "updateProjectionArea", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    //to delete a Marker
    deleteMarker(parameter?: any): Promise<any> {
        let params = "?projectionAreaId=" + parameter;
        return this.apiService.delete(this.host, this.apiEndPoint + "deleteProjectionArea" + params)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }




    //to get the list of Assembly plans
    getAssemblyPlanSteps(parameter?: any): Promise<any> {
        let params = "?productTypeNumber=" + parameter;
        return this.apiService.get(this.host, this.apiEndPoint + "getAssemblyPlanByPTypeNo" + params)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }


    //to save a new Assembly plan step
    saveAssemblyPlanSteps(parameter?: any): Promise<any> {
        return this.apiService.create(this.host, this.apiEndPoint + "addStepToAssemblyPlanById", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    //to update a assembly plan step
    updateAssemblyPlanSteps(parameter?: any): Promise<any> {
        return this.apiService.update(this.host, this.apiEndPoint + "updateStep", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    //to update a assembly plan step
    swapAssemblyPlanSteps(parameter?: any): Promise<any> {
        return this.apiService.update(this.host, this.apiEndPoint + "swapStep", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    //to delete a assembly plan step
    deleteAssemblyPlanSteps(assemblyPlanId: any, stepNumber: any): Promise<any> {
        let params: URLSearchParams = new URLSearchParams();
        params.append("assemblyPlanId", assemblyPlanId);
        params.append("stepNumber", stepNumber);

        return this.apiService.delete(this.host, this.apiEndPoint + "deleteStep?" + params)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    //to get the list of Workflow Markers
    getWorkflow(parameter?: any): Promise<any> {
        let params: URLSearchParams = new URLSearchParams();
        parameter.page = parameter.page - 1;
        params.append("page", parameter.page);
        params.append("size", parameter.itemsPerPage);
        return this.apiService.get(this.host, this.apiEndPoint + "getWorkflows?" + params)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }


    //to save a new Workflow
    saveWorkflow(parameter?: any): Promise<any> {
        return this.apiService.create(this.host, this.apiEndPoint + "saveWorkflow", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    //to update a Workflow
    updateWorkflow(parameter?: any): Promise<any> {
        return this.apiService.update(this.host, this.apiEndPoint + "updateWorkflow", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    //to delete a Workflow
    deleteWorkflow(parameter?: any): Promise<any> {
        let params = "?workflowId=" + parameter;
        return this.apiService.delete(this.host, this.apiEndPoint + "deleteWorkflow" + params)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }
    /* Device config getActiveassistDevice type */
    getDeviceType(parameter?: any): Promise<any> {
        //  let params: URLSearchParams = new URLSearchParams();
        return this.apiService.get(this.host, this.apiEndPoint + "getDeviceTypesList")
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    //Get all material number
    getAllMaterialNumber(parameter?: any): Promise<any> {
        //  let params: URLSearchParams = new URLSearchParams();
        return this.apiService.get(this.host, this.apiEndPoint + "getMaterialList")
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }


}
