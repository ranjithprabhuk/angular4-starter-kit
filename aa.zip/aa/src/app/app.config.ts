export class AppConfig {

    public appTitle: string = "Active Assist";
    public languageCode: string = "en";
    public languageName: string = "English";
    public dateFormat: string = 'yyyy-mm-dd hh:ii:ss';
    public maxSize: number = 10;
    //public apiBase: string = "http://localhost:";
    //public apiBase: string = "http://10.169.176.78:";
    public apiBase: string = "http://10.49.0.218:";

    public baseUrl = {
        "orderManagementServiceHost": this.apiBase,
        "orderManagementServicePort": "9003",
        "assemblyManagementServiceHost": this.apiBase,
        "assemblyManagementServicePort": "9001",
        "deviceManagementServiceHost": this.apiBase,
        "deviceManagementServicePort": "9005",
        "userManagementServiceHost": this.apiBase,
        "userManagementServicePort": "9007",
        "licenseManagementServiceHost": this.apiBase,
        "licenseManagementServicePort": "9011",
        "dataAnalyticsServiceHost": "http://localhost:",
        "dataAnalyticsServicePort":"8080",
       // "dataAnalyticsServicePort": "9012",
        "activeAssistServiceHost": "http://10.169.176.78:",
        "activeAssistServicePort": "54056",
        "stompServerUrl": "ws://10.184.152.54:8181"
    }

    public permissions= {
        "Change Personal Settings": true,
        "Change Orders": true,
        "Create/Change/Delete Material": true,
        "Automatic Production (By Product identification)": false,
        "Order Production": true,
        "User-Login": false,
        "Workflow Tests (by simulation of workflows)": false,
        "Unscrew": false,
        "Software Updates": false,
        "Pause Orders": false,
        "Create/Change/Delete Boxes": true,
        "Expert Settings": false,
        "Licence Updates": false,
        "Program restart and System reboot": false,
        "Create/Change/Delete Workplaces": true,
        "Teach the System": false,
        "Interaction with work instructions": false,
        "Jump between worksteps": false,
        "Status view of AA workplaces": false,
        "Configuration of Loggin Service": false,
        "Review Log File Data": false,
        "Create/Change/Delete Workflows": false,
        "Password change (Admin GUI)": false,
        "Forgot Password": false,
        "View Systemfailures and infos": false,
        "Create/Change/Delete Users and Role": true,
        "Manual Production": true,
        "System Status Overview": false,
        "Set/Change Tool Settings": false,
        "Create/Change/Delete Media Data": true,
        "Database setup and changes": false,
        "Call for help": true
    }

}