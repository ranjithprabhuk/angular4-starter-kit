import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { TabsModule,ModalModule } from 'ng2-bootstrap';
import { Ng2SmartTableModule } from '../table';
import { TranslateModule } from '@ngx-translate/core';

import { DeviceManagementComponent } from './device-management.component';
import { DeviceManagementRoutingModule } from './device-management-routing.module';


//Expert Settings Components
import { ProductIdentificationComponent } from './expert-setting/product-identification/product-identification';
import { CameraComponent } from './expert-setting/camera/camera';
import { BeamerComponent } from './expert-setting/beamer/beamer';
import { HandTrackingComponent } from './expert-setting/hand-tracking/hand-tracking';

@NgModule({
  imports: [
    DeviceManagementRoutingModule,
    CommonModule,
    FormsModule,
    Ng2SmartTableModule,
    TranslateModule,
    TabsModule.forRoot(),
    ModalModule.forRoot()
  ],
  declarations: [ DeviceManagementComponent,ProductIdentificationComponent,CameraComponent,BeamerComponent,HandTrackingComponent ]
})
export class DeviceManagementModule { }
