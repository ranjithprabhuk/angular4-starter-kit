import { Component, ViewChild, Injectable } from '@angular/core';

import { Ng2SmartTableModule, LocalDataSource } from '../table';
import { ModalDirective } from 'ng2-bootstrap/modal';
import { TabsetComponent } from 'ng2-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { DeviceManagementConfig } from './device-management.config';
import { DeviceManagementService } from './device-management.service';

import { ToastrService } from 'ngx-toastr';
@Injectable()
@Component({
  templateUrl: 'device-management.component.html',
  styleUrls: ['./device-management.component.css'],
  providers: [DeviceManagementService]
})

export class DeviceManagementComponent {
  @ViewChild('BoxProjectionAreaModal') public BoxProjectionAreaModal: ModalDirective;
  @ViewChild('BRHandTrackingModal') public BRHandTrackingModal:ModalDirective;
  @ViewChild('ProjectionAreaModal') public ProjectionAreaModal: ModalDirective;
  @ViewChild('VAHandTrackingModal') public VAHandTrackingModal:ModalDirective;
  @ViewChild('RestoreModal') public RestoreModal: ModalDirective;
  @ViewChild('BackupModal') public BackupModal: ModalDirective;
  @ViewChild('CloneModal') public CloneModal: ModalDirective;
  //public selectedRowBoxesRails: any;
  constructor(private deviceManagementService: DeviceManagementService, private translate: TranslateService, private notificationService: ToastrService) {
  }
  public deviceManagementConfig = new DeviceManagementConfig();


  public show_box_projection_text:any;
  public show_handtracking_coordinates:any;
  public show_projection_text:any;

  public selectedTab: String = 'DEVICE_MANAGEMENT.ACTIVE_ASSISTS';
  public settingsActiveAssists: any = this.deviceManagementConfig.ActiveAssistsSettings;
  public settingsMaterial: any = this.deviceManagementConfig.MaterialSettings;
  public settingsBoxTypes: any = this.deviceManagementConfig.BoxTypesSettings;
  public settingsBoxRails: any = this.deviceManagementConfig.BoxRailsSettings;
  public settingsVirtualAreas: any = this.deviceManagementConfig.VirtualAreasSettings;
  public settingsSensorActor: any = this.deviceManagementConfig.SensorActorSettings;
  public settingsDeviceConfig: any = this.deviceManagementConfig.DeviceConfigSettings;

  // public showDMModal($event):any {
  //     this.DMModal.show();
  //     console.log("row details",$event);
  //     console.log("selected row",this.selectedRowBoxesRails);
  //     switch($event.id)
  //     {
  //         case "boxProjectionArea":  this.show_box_projection_text="showBoxProjectionArea";
  //                                    this.show_handtracking_coordinates="hideHandtrackingCoordinates";
  //                                    this.show_projection_text="hideBoxProjectionArea";
  //                                    break;
  //         case "handTrackingCoordinates":   this.show_box_projection_text="hideBoxProjectionArea";
  //                                           this.show_handtracking_coordinates="showHandtrackingCoordinates";
  //                                           this.show_projection_text="hideBoxProjectionArea";
  //                                           break;
  //         case "vHandTrackingCoordinates":  this.show_box_projection_text="hideBoxProjectionArea";
  //                                           this.show_handtracking_coordinates="showHandtrackingCoordinates";
  //                                           this.show_projection_text="hideBoxProjectionArea";
  //                                           break;
  //         case "projectionArea": this.show_box_projection_text="hideBoxProjectionArea";
  //                                this.show_handtracking_coordinates="hideHandtrackingCoordinates";
  //                                this.show_projection_text="showBoxProjectionArea";
  //                                           break;
  //     }

  // }

  // public hideDMModal(): void {
  //   this.DMModal.hide();
  // }



// Active Assist Tab Buttons
  public onButtonClick(event): void {
    let columnTitle = event.getColumn().title;
    switch (columnTitle) {
      case "Restore":
        this.RestoreModal.show();
        break;
      case "Backup":
        this.BackupModal.show();
        break;
      case "Clone":
        this.CloneModal.show();
        break;
    }
  };



  //Active Assist Tab Data
  public _activeAssists = [
    {
      number: 1,
      aa_id: "AA_Bosch-FE-DC-Pruef-01",
      ipAddress: '192.168.104.03',
      company: "BOSCH",
      plant: "FE",
      department: "MOE1",
      line: "Line1",
      supervisor: "Mueller",
    },
    {
      number: 2,
      aa_id: "AA_Bosch-FE-DC-Pruef-01",
      ipAddress: '192.168.104.03',
      company: "BOSCH",
      plant: "FE",
      department: "MOE1",
      line: "Line1",
      supervisor: "Mueller",
    },
    {
      number: 3,
      aa_id: "AA_Bosch-FE-DC-Pruef-01",
      ipAddress: '192.168.104.03',
      company: "BOSCH",
      plant: "FE",
      department: "MOE1",
      line: "Line1",
      supervisor: "Mueller",
    },
    {
      number: 4,
      aa_id: "AA_Bosch-FE-DC-Pruef-01",
      ipAddress: '192.168.104.03',
      company: "BOSCH",
      plant: "FE",
      department: "MOE1",
      line: "Line1",
      supervisor: "Mueller",
    },
    {
      number: 5,
      aa_id: "AA_Bosch-FE-DC-Pruef-01",
      ipAddress: '192.168.104.03',
      company: "BOSCH",
      plant: "FE",
      department: "MOE1",
      line: "Line1",
      supervisor: "Mueller",
    },
    {
      number: 6,
      aa_id: "AA_Bosch-FE-DC-Pruef-01",
      ipAddress: '192.168.104.03',
      company: "BOSCH",
      plant: "FE",
      department: "MOE1",
      line: "Line1",
      supervisor: "Mueller",
    },
  ];



  //Device congif data
  public _deviceConfig = [
    {
      aaid: "AA1",
      deviceNr: 1,
      deviceCategory: "Sensor",
      deviceType: "Sensor type 1 ",
      description: "This is a detailed description for Sensor type 1"
    },
    {
      aaid: "AA1",
      deviceNr: 2,
      deviceCategory: "Sensor",
      deviceType: "Sensor type 2 ",
      description: "This is a detailed description for Sensor type 2"
    },
    {
      aaid: "AA1",
      deviceNr: 3,
      deviceCategory: "Camera",
      deviceType: "Camera type 1 ",
      description: "This is a detailed description for Camera type 1"
    },
    {
      aaid: "AA1",
      deviceNr: 4,
      deviceCategory: "RFID",
      deviceType: "RFID type 1 ",
      description: "This is a detailed description for RFID type 1"
    },
    {
      aaid: "AA1",
      deviceNr: 5,
      deviceCategory: "Screw Driver",
      deviceType: "Screw Driver type 1 ",
      description: "This is a detailed description for Screw Driver type 1"
    },
    {
      aaid: "AA1",
      deviceNr: 6,
      deviceCategory: "Screw Driver",
      deviceType: "Screw Driver type 2 ",
      description: "This is a detailed description for Screw Driver type 2"
    }
  ];
  //Material Tab Data
  public _material = [
    {
      materialId: '3842 654 322',
      materialName: "Material 1",
      description: "This is a detailed description of Material 1",
      createDate: '04.03.2017',
    },
    {
      materialId: '3842 654 323',
      materialName: "Material 2",
      description: "This is a detailed description of Material 2",
      createDate: '05.03.2017',

    },
    {
      materialId: '3842 654 323',
      materialName: "Material 3",
      description: "This is a detailed description of Material 3",
      createDate: '01.03.2017',
    },
    {
      materialId: '3842 654 324',
      materialName: "Material 4",
      description: "This is a detailed description of Material 4",
      createDate: '10.03.2017',
    },
    {
      materialId: '3842 654 325',
      materialName: "Material 5",
      description: "This is a detailed description of Material 5",
      createDate: '14.03.2017',
    },
    {
      materialId: '3842 654 326',
      materialName: "Material 6",
      description: "This is a detailed description of Material 6",
      createDate: '13.03.2017',
    },
  ];
  //Box Types Tab Data
  public _boxTypesData = [
      {
        boxTypeName: "Box Type 1",
        length: 56,
        width : 45,
        height : 33,
      },
      {
        boxTypeName: "Box Type 2",
        length: 80,
        width : 40,
        height : 20,
      },
      {
        boxTypeName: "Box Type 3",
        length: 40,
        width : 60,
        height : 20,
      },
      {
        boxTypeName: "Box Type 4",
        length: 34,
        width : 80,
        height : 40,
      }
    ];
    //Box Rails Tab Data 
    //(click)="this.deviceComponent.showDMModal(cell.column);"
    
    public _boxRailsData=[
        {
          aaid:"AA1",
          material: "3842 555 654",
          boxtypeName: "Type 1",
          trackingMode : "Virtual Box",
          posNr : "R1U2",
          boxProjectionArea:"x=10,y=10,z=12,width=600,height=200",
          handTrackingCoordinates:"x=23,y=5,z=35"  
        },
        {
            aaid:"AA2",
            material: "3842 555 654",
            boxtypeName: "Type 1",
            trackingMode : "Virtual Box",
            posNr : "R2U2",
            boxProjectionArea:"[check local config data]",
            handTrackingCoordinates:"[check local config data]" 
        },
        {
            aaid:"AA3",
            material: "3842 333 777",
            boxtypeName: "Type 2",
            trackingMode : "Pick-To-Light",
            posNr : "13",
            boxProjectionArea:"[---]",
            handTrackingCoordinates:"[---]"  
        },
        {
            aaid:"AA4",
            material: "3842 222 333",
            boxtypeName: "Type 3",
            trackingMode : "Pick-To-Light",
            posNr : "12",
            boxProjectionArea:"[---]",
            handTrackingCoordinates:"[---]"  
        }
    ];
    //Virtual Areas Tab Data
    public _virtualAreasData=[
        {
          type: "Button",
          name: "Confirm",
          form :  '',
          color : '',
          projectionArea:"x=10,y=10,z=10,width=600,height=200",
          vHandTrackingCoordinates:"x=23,y=5,z=35"  
        },
        {
          type: "Button",
          name: "Forward",
          form : "",
          color :  "",
          projectionArea:"x=10,y=10,z=10,width=600,height=200",
          vHandTrackingCoordinates:"x=23,y=5,z=35"  
        },
        {
          type: "Button",
          name: "Backward",
          form : "",
          color :  "",
          projectionArea:"x=10,y=10,z=10,width=600,height=200",
          vHandTrackingCoordinates:"x=23,y=5,z=35"  
        },
        {
          type: "Marker",
          name: "DellXPS15_5",
          form : "Circle",
          color :  "#FFEEDD",
          projectionArea:"x=10,y=10,z=10,width=600,height=200",
          vHandTrackingCoordinates:"x=23,y=5,z=35"  
        }   
    ];
 //Sensor Actor Tab Data
 public _sensorActorData=[
        {
          port: "Port 2",
          posnr: 10,
          type : "Output",
          test :  "",
          status:""
        },
         {
          port: "Port 3",
          posnr: 11,
          type : "Input",
          test :  "",
          status:""
        },
         {
          port: "Port 4",
          posnr: 11,
          type : "Output",
          test :  "",
          status:""
        },
         {
          port: "Port 5",
          posnr: 12,
          type : "Input",
          test :  "",
          status:""
        },
         {
          port: "Port 6",
          posnr: 12,
          type : "Output",
          test :  "",
          status:""
        },
         {
          port: "Port 7",
          posnr: 13,
          type : "Input",
          test :  "",
          status:""
        },
         {
          port: "Port 8",
          posnr: 13,
          type : "Output",
          test :  "",
          status:""
        }
         
    ];
    
    public showBoxProjectionAreaModal():any {
      this.BoxProjectionAreaModal.show();
    }
    public showBRHandTrackingModalModal():any {
      this.BRHandTrackingModal.show();
    }
    public showProjectionAreaModal():any {
      this.ProjectionAreaModal.show();
    }
    public showVAHandTrackingModalModal():any {
      this.VAHandTrackingModal.show();
    }

    //DMSModal events
     public eventStartTeaching(): void{
      //console.log("event start teaching",$event);
      // let a=$event.data;
      // a["boxPosition"]=2;
      // a["boxProjectionArea"]="x=40,y=80,width=100,height=480";
      // a["boxtypeName"]="Type 3";
      // a["handTrackingCoordinates"]="x=45,y=50,z=15";
      // a["material"]="2432 000 222";
      // a["p2lPosNr"]="20";
     }
     public eventOk($event): void {
        console.log("event ok", $event);
    }
    public onCellClickBoxesRails(event: any):void{
        console.log("checking event>>", event);
        if(event.column.id=="boxProjectionArea")
        {
            this.showBoxProjectionAreaModal();
        }
        if(event.column.id=="handTrackingCoordinates")
        {
            this.showBRHandTrackingModalModal();
        }
     };
      public onCellClickVirtualAreas(event: any):void{
        console.log("checking event>>", event);
        if(event.column.id=="projectionArea")
        {
            this.showProjectionAreaModal();
        }
        if(event.column.id=="vHandTrackingCoordinates")
        {
            this.showVAHandTrackingModalModal();
        }
      };
      
  ngOnInit() {

  }
}
