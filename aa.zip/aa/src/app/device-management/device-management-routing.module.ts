import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DeviceManagementService } from './device-management.service';
import { DeviceManagementComponent } from './device-management.component';

const DeviceManagementRoutes: Routes = [
  {
    path: '',
    component: DeviceManagementComponent,
    data: {
      title: 'Device Management'
    }
  }
];


@NgModule({
  imports: [
    RouterModule.forChild(DeviceManagementRoutes)
  ],
  exports: [
    RouterModule
  ],
  providers: [DeviceManagementService]
})
export class DeviceManagementRoutingModule { }



