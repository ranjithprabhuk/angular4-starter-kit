import { Component } from '@angular/core';

@Component({
    selector : "beamer",
    templateUrl: "./beamer.html",
    styleUrls : ["./beamer.css"]
})

export class BeamerComponent {

}