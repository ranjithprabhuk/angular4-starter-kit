import { Component } from '@angular/core';

@Component({
    selector : "hand-tracking",
    templateUrl: "./hand-tracking.html",
    styleUrls : ["./hand-tracking.css"]
})

export class HandTrackingComponent {

}