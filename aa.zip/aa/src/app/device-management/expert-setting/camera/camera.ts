import { Component } from '@angular/core';

@Component({
    selector : "camera",
    templateUrl: "./camera.html",
    styleUrls : ["./camera.css"]
})

export class CameraComponent {

}