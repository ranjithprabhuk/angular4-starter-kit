import { Component } from '@angular/core';

@Component({
    selector : "product-identification",
    templateUrl: "./product-identification.html",
    styleUrls : ["./product-identification.css"]
})

export class ProductIdentificationComponent {

}