    export class DeviceManagementConfig {

    //pagination  settings
    public paginationSettings: Object = {
    display: false,
    perPage: 2
    };
    //table configuration for Active Assist Tab
    public ActiveAssistsSettings: Object = {
    actions: {
        columnTitle: 'Actions',
        add: true,
        edit: true,
        delete: true,
        copy: true,
        move: false,
        position: 'left', // left|right
    },
     columns: {
         aa_id: {
            title: 'AA_ID',
            filter: true,
            minWidth: "200px"
        },
        ipAddress: {
            title: 'IP Address',
            filter: true,
            minWidth: "200px"
        },
        company: {
            title: 'Comapany',
            filter: true,
            minWidth: "100px"
        },
            plant: {
            title: 'Plant',
            filter: true,
            minWidth: "70px"
        },
        department: {
            title: 'Department',
            filter: true,
            minWidth: "100px"
        },
        line: {
            title: 'Line',
            filter: true,
            minWidth: "70px"
        },
        release: {
            title: 'Release',
            filter: true,
            minWidth: "100px"
        }, 
        supervisor: {
            title: 'Supervisor',
            filter: true,
            
            minWidth: "100px"
        }, 
        restore: {
            title: 'Restore',
            filter: false,
            minWidth: "50px",
            type: "button",
            buttonText : "Restore",
           
        },
        backup: {
            title: 'Backup',
            filter: false,
            minWidth: "50px",
            type: "button",
            buttonText : "Backup",
          
        }, 
            clone: {
            title: 'Clone',
            filter: false,
            minWidth: "50px",
            type: "button",
            buttonText : "Clone", 
              
        },       
     },   
        pager: this.paginationSettings
    };


  //table configuration for Material Tab
    public MaterialSettings: Object = {
    actions: {
        columnTitle: 'Actions',
        add: true,
        edit: true,
        delete: true,
        copy: true,
        move: false,
        position: 'left', // left|right
    },
     columns: {
         materialId: {
            title: 'Material Id',
            filter: true,
            minWidth: "200px"
        },
        materialName: {
            title: 'Material Name',
            filter: true,
            minWidth: "200px"
        },
        description: {
            title: 'Description',
            filter: true,
            minWidth: "200px"
        },
        createDate: {
            title: 'Create Date',
            filter: true,
            minWidth: "70px"
        },
     },   
        pager: this.paginationSettings
    };


    public BoxTypesSettings: Object = {
    actions: {
        columnTitle: '',
        add: true,
        edit: true,
        delete: true,
        copy: true,
        move: false,
        position: 'left', // left|right
    },
    columns: {
        boxTypeName: {
            title: 'Box Type Name',
            filter: true,
            minWidth: "180px"
        },
        length: {
            title: 'Length',
            filter: true,
            minWidth: "106px"
        },
        width: {
            title: 'Width',
            filter: true,
            minWidth: "50px"
        },
        height: {
            title: 'Height',
            filter: true,
            minWidth: "200px"
        }
    },
    pager: this.paginationSettings
    };
    public BoxRailsSettings: Object = {
        actions: {
            columnTitle: '',
            add: true,
            edit: true,
            delete: true,
            copy: true,
            move: false,
            position: 'left', // left|right
        },
        columns: {
            aaid:{
                title: 'AA ID',
                filter: true,
                minWidth: "60px"
            },
            material: {
                title: 'Material',
                filter: true,
                minWidth: "100px"
            },
            boxtypeName: {
                title: 'Box Type Name',
                filter: true,
                minWidth: "106px"
            },
            trackingMode: {
                title: 'Tracking Mode',
                filter: true,
                minWidth: "100px",
                editor: {
                    type: 'list',
                    config: {
                        selectText: 'Select...',
                        list: [
                            { value: 'Virtual Box', title: 'Virtual Box' },
                            { value: 'Pick-To-Light', title: 'Pick-To-Light' },
                        ],
                    }
                }
            },
            posNr: {
                title: 'Pos Nr',
                filter: true,
                minWidth: "100px"
            },
            boxProjectionArea: {
                title: 'Box Projection Area',
                filter: true,
                minWidth: "300px",
                projectionAreaIcon: true
            },
            handTrackingCoordinates:{
                title: 'Hand Tracking Coordinates',
                filter: true,
                minWidth: "250px",
                projectionAreaIcon: true
            }
        },
        pager: this.paginationSettings
    };

     public VirtualAreasSettings: Object = {
        actions: {
            columnTitle: '',
            add: true,
            edit: true,
            delete: true,
            copy: true,
            move: false,
            position: 'left', // left|right
        },
        columns: {
            type: {
                title: 'Type',
                filter: true,
                minWidth: "100px"
            },
            name: {
                title: 'Name',
                filter: true,
                minWidth: "106px"
            },
            form: {
                title: 'Form',
                filter: true,
                minWidth: "100px",
                // editor: {
                //     type: 'list',
                //     config: {
                //         selectText: 'Select...',
                //         list: [
                //             { value: 'circle', title: 'circle' },
                //             { value: 'square', title: 'square' }
                //         ],
                //     }
                //  }
            },
            color: {
                title: 'Color',
                filter: true,
                minWidth: "100px",
                //type:'color'
            },
            projectionArea: {
                title: 'Projection Area',
                filter: true,
                minWidth: "300px",
                projectionAreaIcon: true
            },
            vHandTrackingCoordinates:{
                title: 'Hand Tracking Coordinates',
                filter: true,
                minWidth: "250px",
                projectionAreaIcon: true
            }
        },
        pager: this.paginationSettings
    };
    public SensorActorSettings: Object = {
        actions: {
            columnTitle: '',
            add: false,
            edit: false,
            delete: false,
            copy: false,
            move: false,
            position: 'left', // left|right
        },
        columns: {
            port: {
                title: 'Port',
                filter: true,
                minWidth: "100px"
            },
            posnr: {
                title: 'Pos Nr',
                filter: true,
                minWidth: "106px"
            },
            type: {
                title: 'Type',
                filter: true,
                minWidth: "50px"
            },
            test: {
                title: '',
                filter: true,
                minWidth: "200px"
            },
            status: {
                title: '',
                filter: true,
                minWidth: "200px"
            }
        },
        pager: this.paginationSettings
    };
    public DeviceConfigSettings: Object = {
        actions: {
            columnTitle: 'Actions',
            add: true,
            edit: true,
            delete: true,
            copy: true,
            move: false,
            position: 'left', // left|right
        },
        columns: {
            aaid: {
                title: 'AA ID',
                filter: true,
                minWidth: "100px"
            },
            deviceNr: {
                title: 'Device Nr',
                filter: true,
                minWidth: "106px"
            },
            deviceCategory: {
                title: 'Device Category',
                filter: true,
                minWidth: "50px"
            },
            deviceType: {
                title: 'Device Type',
                filter: true,
                minWidth: "200px"
            },
            description: {
                title: 'Description',
                filter: true,
                minWidth: "200px"
            }
        },
        pager: this.paginationSettings
    };
}