import { Injectable } from '@angular/core';
import { URLSearchParams } from '@angular/http';
import { ApiService } from '../app.service';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class DeviceManagementService {

    constructor(private apiService: ApiService) { 
        //this.getDetails();
    }

    //protected apiEndPoint: string = this.apiService.baseUrl.deviceManagementServicePort +"/";
    protected apiEndPoint: string = "";

    public host = "deviceManagementService";

    getDetails(): void {
        this.getExternalProperties().then((res) => {
            this.apiEndPoint = res.deviceManagementServicePort + "/";
        });
    }

    getExternalProperties(): Promise<any> {
        return this.apiService.getExternalApplicationProperties().then(res => { return Promise.resolve(res) });
    }

    //to get the order table data
    getOrdersData(parameter?: any): Promise<any> {
        let params: URLSearchParams = new URLSearchParams();
        return this.apiService.get(this.host, this.apiEndPoint + "getAllOrdersList")
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    //to get the UID orders table data
    getUIDProductsData(parameter?: any): Promise<any> {
        let params: URLSearchParams = new URLSearchParams();
        return this.apiService.get(this.host, this.apiEndPoint + "fetchUidOrders")
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    //to get the Assisn Orders table data
    getOrdersToAssignData(parameter?: any): Promise<any> {
        let params: URLSearchParams = new URLSearchParams();
        return this.apiService.get(this.host, this.apiEndPoint + "getOrdersToAssign")
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    //to get the eligible Active Assist ID Data
    getEligibleActiveAssistData(parameter?: any): Promise<any> {
        let params: URLSearchParams = new URLSearchParams();
        return this.apiService.get(this.host, this.apiEndPoint + "getEligibleActiveAssist")
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    // to save the Orders under Orders tab
    saveOrders(parameter?: any): Promise<any> {
        return this.apiService.create(this.host, this.apiEndPoint + "createOrders", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    //to save UID Products under UID Products tab
    saveUIDProducts(parameter?: any): Promise<any> {
        return this.apiService.create(this.host, this.apiEndPoint + "createUidOrder", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    //to update a particular active assist ID
    updateActiveAssistId(productionOrderId?: any, activeAssistId?: any): Promise<any> {
        let params = "productionOrderId=" + productionOrderId + "&activeAssistId=" + activeAssistId;
        return this.apiService.update(this.host, this.apiEndPoint + "updateActiveAssistId?" + params)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    //to upload Xml orders
    uploadOrdersXML(parameter?: any): Promise<any> {
        return this.apiService.upload(this.host, this.apiEndPoint + "createXmlOrders", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }


    //to update an order
    updateOrdersData(parameter?: any): Promise<any> {
        return this.apiService.update(this.host, this.apiEndPoint + "updateOrders", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    //to delete an order
    deleteOrder(parameter?: any): Promise<any> {
        let params = "?productionOrderId=" + parameter;
        return this.apiService.delete(this.host, this.apiEndPoint + "deleteOrder" + params)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    //to upload a XML file
    uploadUidXML(parameter?: any): Promise<any> {
        return this.apiService.upload(this.host, this.apiEndPoint + "feedUidXmlInfo", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    //to save a new UID Order
    saveUidOrder(parameter?: any): Promise<any> {
        return this.apiService.create(this.host, this.apiEndPoint + "createUidOrder", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    //to update a UID Order
    updateUidOrder(parameter?: any): Promise<any> {
        return this.apiService.update(this.host, this.apiEndPoint + "updateUidOrders", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    //to delete a UID Order
    deleteUidOrder(parameter?: any): Promise<any> {
        return this.apiService.delete(this.host, this.apiEndPoint + "deleteUidOrder/" + parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }


}
