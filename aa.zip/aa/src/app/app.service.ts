import { Injectable } from '@angular/core';
import { Headers, Http, URLSearchParams } from '@angular/http';
import { AppConfig } from './app.config';
import { Observable } from 'rxjs/Observable';
import { LoaderService } from './shared/loader';
import { ToastrService } from 'ngx-toastr';
import 'rxjs/add/operator/toPromise';


@Injectable()
export class ApiService {
    public apiBase = new AppConfig().apiBase;
    public static baseUrl: any = undefined;
    private headers = new Headers({ 'Accept': 'application/json' });
    private multiPartHeaders = new Headers({ 'Content-Type': 'multipart/form-data' });
    public enableLoader: boolean = false;

    constructor(protected http: Http, public loader: LoaderService, public notification: ToastrService) {
        //this.getExternalApplicationProperties();
    }

    //to get the external application properties
    getExternalApplicationProperties(parameter?: URLSearchParams): Promise<any> {
        if (ApiService.baseUrl != undefined) {
            return Promise.resolve(ApiService.baseUrl);
        } else {
            return this.http
                .get("/getApplicationProperties", { search: parameter, headers: this.headers })
                .toPromise()
                .then((res) => {
                    ApiService.baseUrl = this.configureApiBase(res);
                    return Promise.resolve(ApiService.baseUrl);
                })
                .catch((err) => {
                    ApiService.baseUrl = new AppConfig().baseUrl; //copy to baseUrl for initial baseUrl value in ng serve
                    return Promise.resolve(ApiService.baseUrl);
                });
        }
    }

    //for all GET operations
    get(service: string, module: string, parameter?: URLSearchParams): Promise<any> {
        this.showLoader();
        return this.getExternalApplicationProperties().then(res => {
            this.apiBase = res[service + "Host"] + res[service + "Port"] + "/";
            return this.http
                .get(this.apiBase + module, { search: parameter, headers: this.headers })
                .toPromise()
                .then((res) => { return this.handleSuccess(res) })
                .catch((err) => { return this.handleError(err) });

        }).catch((err) => { return this.handleError(err) })
    }

    //for all POST operations
    create(service: string, module: string, parameter: any): Promise<any> {
        this.showLoader();
        return this.getExternalApplicationProperties().then(res => {
            this.apiBase = res[service + "Host"] + res[service + "Port"] + "/";
            return this.http
                .post(this.apiBase + module, parameter, { headers: this.headers })
                .toPromise()
                .then((res) => { return this.handleSuccess(res) })
                .catch((err) => { return this.handleError(err) });

        }).catch((err) => { return this.handleError(err) })
    }
    createWithoutLoader(service: string, module: string, parameter: any): Promise<any> {
         this.hideLoader();
       return this.getExternalApplicationProperties().then(res => {
            this.apiBase = res[service + "Host"] + res[service + "Port"] + "/";
            return this.http
                .post(this.apiBase + module, parameter, { headers: this.headers })
                .toPromise()
                .then((res) => { return this.handleSuccess(res) })
                .catch((err) => { return this.handleError(err) });

        }).catch((err) => { return this.handleError(err) });
    }
    //for all POST operations
    createWithURParam(service: string, module: string, parameter?: URLSearchParams): Promise<any> {
        this.showLoader();
        return this.getExternalApplicationProperties().then(res => {
            this.apiBase = res[service + "Host"] + res[service + "Port"] + "/";
            return this.http
                .post(this.apiBase + module, parameter, { headers: this.headers })
                .toPromise()
                .then((res) => { return this.handleSuccess(res) })
                .catch((err) => { return this.handleError(err) });
        }).catch((err) => { return this.handleError(err) });
    }

    //for all UPDATE operations
    update(service: string, module: string, parameter?: any): Promise<any> {
        this.loader.loader.emit(true);
        return this.getExternalApplicationProperties().then(res => {
            this.apiBase = res[service + "Host"] + res[service + "Port"] + "/";
            return this.http
                .put(this.apiBase + module, parameter, { headers: this.headers })
                .toPromise()
                .then((res) => { return this.handleSuccess(res) })
                .catch((err) => { return this.handleError(err) });
        }).catch((err) => { return this.handleError(err) });
    }

    //for all DELETE operations
    delete(service: string, module: string): Promise<any> {
        this.showLoader();
        return this.getExternalApplicationProperties().then(res => {
            this.apiBase = res[service + "Host"] + res[service + "Port"] + "/";
            return this.http.delete(this.apiBase + module, { headers: this.headers })
                .toPromise()
                .then((res) => { return this.handleSuccess(res) })
                .catch((err) => this.handleError(err));
        }).catch((err) => { return this.handleError(err) });
    }

    //for all UPLOAD file operations
    upload(service: string, module: string, parameter: any): Promise<any> {
        this.showLoader();
        return this.getExternalApplicationProperties().then(res => {
            this.apiBase = res[service + "Host"] + res[service + "Port"] + "/";
            return this.http.post(this.apiBase + module, parameter, this.multiPartHeaders)
                .toPromise()
                .then((res) => { return this.handleSuccess(res) })
                .catch((err) => this.handleUploadError(err));
        }).catch((err) => { return this.handleError(err) });
    }


    //for successfull API response
    protected handleSuccess(response: any): Promise<any> {
        console.log(response);
        if (response.status === 200) {

            //convert the response body as JSON
            let res = response.json();

            if (res.code === 200) {
                console.log(res);
                console.log("after validation: success");
                //this.notification.success(res.message);
                this.enableLoader = false;
                this.loader.loader.emit(false);
                return Promise.resolve(res.data);
            }
            else {
                console.log("after validation: failure");
                this.enableLoader = false;
                this.notification.error(res.message);
                this.loader.loader.emit(false);
                return Promise.reject(res);
            }
        } else {
            this.notification.error("Backend API is not Available");
        }

    }


    //for error handling
    public handleError(error: any): Promise<any> {
        console.error('An error occurred', error);
        this.enableLoader = false;
        this.loader.loader.emit(false);
        return Promise.reject(error.message || error);
    }
    public handleUploadError(error: any): Promise<any> {
        console.error('An error occurred', error);
        this.enableLoader = false;
        this.loader.loader.emit(false);
        return Promise.reject(error || error);
    }
    public showLoader(): void {
        this.enableLoader = true;
        setTimeout(() => {
            if (this.enableLoader) {
                this.loader.loader.emit(true);
                this.enableLoader = false;
            }
        }, 3000);
    }
    public hideLoader(): void {
        this.enableLoader = false;
        setTimeout(() => {
            if (this.enableLoader) {
                this.loader.loader.emit(true);
                this.enableLoader = false;
            }
        }, 3000);
    }
    public configureApiBase(response) {
        if (response.status == 200) {
            //convert the response body as JSON
            let res = response.json();

            if (res.code === 200) {
                console.log("inside api base>>", res.data);
                return res.data;
            }
        }
    };

    public checkBaseUrl(host): string {
        if (ApiService.baseUrl) {
            return ApiService.baseUrl[host];
        }
    }
}
