import { Component, Input, Output, EventEmitter } from '@angular/core';

import { Grid } from '../../../lib/grid';
import { Row } from '../../../lib/data-set/row';

@Component({
  selector: 'copy-row',
  template: `
    <a href="#" *ngIf="grid.getSetting('actions.copy')" class="ng2-smart-action ng2-smart-action-edit-edit"
        [innerHTML]="grid.getSetting('copy.copyButtonContent')" (click)="onCopy($event)">Copy</a>    
  `,
})
export class CopyRowComponent {

  @Input() grid: Grid;
  @Input() row: Row;
  @Input() source: any;
  @Input() copyConfirm: EventEmitter<any>;

  @Output() edit = new EventEmitter<any>();
  @Output() delete = new EventEmitter<any>();
  @Output() editRowSelect = new EventEmitter<any>();

  onCopy(event: any) {
    event.preventDefault();
    event.stopPropagation();

    this.editRowSelect.emit(this.row);

    if (this.grid.getSetting('mode') === 'external') {
      this.edit.emit({
        data: this.row.getData(),
        source: this.source,
      });
    } else {
      this.grid.copy(this.row, this.copyConfirm);
    }
  }
}
