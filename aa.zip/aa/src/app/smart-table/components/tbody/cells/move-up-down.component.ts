import { Component, Input, Output, EventEmitter } from '@angular/core';

import { Grid } from '../../../lib/grid';
import { Row } from '../../../lib/data-set/row';

@Component({
  selector: 'move-up-down',
  template: `
    <a href="#" *ngIf="grid.getSetting('actions.move')" class="ng2-smart-action ng2-smart-action-delete-delete"
        [innerHTML]="grid.getSetting('moveup.moveupButtonContent')" (click)="$event.direction='sqa';onMoveUp($event)"></a>
    <a href="#" *ngIf="grid.getSetting('actions.move')" class="ng2-smart-action ng2-smart-action-delete-delete"
        [innerHTML]="grid.getSetting('movedown.movedownButtonContent')" (click)="onMoveDown($event)"></a>
    
  `,
})
export class MoveUpDownComponent {

  @Input() grid: Grid;
  @Input() row: Row;
  @Input() source: any;
  @Input() moveConfirm: EventEmitter<any>;

  @Output() edit = new EventEmitter<any>();
  @Output() move = new EventEmitter<any>();
  @Output() editRowSelect = new EventEmitter<any>();

  onMoveUp(event: any) {
    event.preventDefault();
    event.stopPropagation();



    //this.move.emit(_swapData);

    if (this.grid.getSetting('mode') === 'external') {
      this.edit.emit({
        data: this.row.getData(),
        source: this.source,
      });
    } else {
      let _index: number = this.row.index;
      if (_index) {
        let _swapData = {
          "assemblyPlanId": this.row.getData().assemblyPlanId,
          "stepNumberFirst": this.row.getData().stepNumber,
          "stepNumberSecond": this.grid.dataSet.rows[this.row.index - 1].getData().stepNumber
        }
        this.grid.move(_index, this.moveConfirm, "up", _swapData);
      }
    }
  }

  onMoveDown(event: any) {
    event.preventDefault();
    event.stopPropagation();

    if (this.grid.getSetting('mode') === 'external') {
      this.edit.emit({
        data: this.row.getData(),
        source: this.source,
      });
    } else {
      let _index = this.row.index;
      if (_index != this.grid.dataSet.rows.length - 1) {

        let _swapData = {
          "assemblyPlanId": this.row.getData().assemblyPlanId,
          "stepNumberFirst": this.row.getData().stepNumber,
          "stepNumberSecond": this.grid.dataSet.rows[this.row.index + 1].getData().stepNumber
        }
        this.grid.move(_index, this.moveConfirm, "down", _swapData);
      }
    }
  }
}
