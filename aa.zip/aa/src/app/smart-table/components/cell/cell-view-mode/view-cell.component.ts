import {Component, Input, ChangeDetectionStrategy,EventEmitter, Output } from '@angular/core';

import { Cell } from '../../../lib/data-set/cell';

@Component({
  selector: 'table-cell-view-mode',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
        <div [ngSwitch]="cell.getColumn().type" (click)="CellClick.emit(cell)">
        <custom-view-component *ngSwitchCase="'custom'" [cell]="cell"></custom-view-component>
        <div *ngSwitchCase="'html'" [innerHTML]="cell.getValue()"></div>
        <div *ngSwitchCase="'button'"><button type="button" class="btn btn-primary" style="color:white;">{{cell.column.buttonText}}</button></div>
        
          <div *ngSwitchCase="'circle'"><button type="button" class="btn btn-primary" style="padding:10px 11px; background:green; width:2px; border-radius:100%; width:1%;">{{cell.column.buttonText}}</button></div>
        <div *ngSwitchDefault>{{ cell.getValue() }}
          <span class="badge badge-default float-right" *ngIf="cell.column.type=='color'" [ngStyle]="{'padding':'5px 9px','background-color':cell.value}">&nbsp;</span>
          <span class="float-right" *ngIf="cell.column.detailsIcon">
          <button style="background: 0;border: 0;cursor: pointer;"><img class="img-responsive table-icons" alt="Edit Marker" src="../assets/img/icons/details.png" /></button>
            
          </span>
           <span class="float-right" *ngIf="cell.column.projectionAreaIcon">
            <button style="background: 0;border: 0;cursor: pointer;"><img class="img-responsive table-icons" alt="Edit Projection Area" src="../assets/img/icons/arrow_collapse.png" /></button>
          </span>
        </div>
    </div>
    `,
})
export class ViewCellComponent {

  @Input() cell: Cell;
  @Output() CellClick = new EventEmitter<any>();
}
