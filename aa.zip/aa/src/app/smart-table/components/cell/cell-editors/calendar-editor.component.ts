import { Component, ElementRef, Input } from '@angular/core';

import { DefaultEditor } from './default-editor';
import { Cell } from '../../../lib/data-set/cell';

import { AppConfig } from '../../../../app.config';

declare var $: any;

@Component({
  selector: 'calendar-editor',
  styleUrls: ['./editor.component.scss'],
  template: `
  <input [ngClass]="inputClass"
           class="form-control"
           type="{{cell.column.type}}"
           [(ngModel)]="cell.newValue"
           [attr.id]="cell.getClass()"
           [name]="cell.getId()"
           [placeholder]="cell.getTitle()"
           [disabled]="!cell.isEditable() || cell.column.disabled"
           (click)="onClick.emit($event)"
           (keydown.enter)="onEdited.emit($event)"
           (keydown.esc)="onStopEditing.emit()">
    `,
})
export class CalendarEditorComponent extends DefaultEditor {


  constructor(private elm: ElementRef) {
    super();
  }
  public dateFormat: string;
  public datepickerClass: string;

  ngAfterViewInit() {
    
    this.dateFormat = new AppConfig().dateFormat;
    let getCurrentDate=new Date();
    
    let cYear=(getCurrentDate.getFullYear()).toString();
    let cDate=(getCurrentDate.getDate()).toString();
    let cMonth=(getCurrentDate.getMonth()+1).toString();
    let cHour=(getCurrentDate.getHours()).toString();
    let cMinute=(getCurrentDate.getMinutes()).toString();
    let cSeconds=(getCurrentDate.getSeconds()).toString();

    if(cDate.length==1)
    {
        cDate="0"+cDate;
    }
    if(cMonth.length==1)
    {
         cMonth="0"+cMonth;
    }
    if(cHour.length==1)
    {
         cHour="0"+cHour;
    }
    if(cMinute.length==1)
    {
        cMinute="0"+cMinute;
    }
    if(cSeconds.length==1)
    {
        cSeconds="0"+cSeconds;
    }
    let currentDate=cYear+"-"+cMonth+"-"+cDate+" "+cHour+":"+cMinute+":"+cSeconds;
    console.log("current date",currentDate);

    let startDateJson={ format: this.dateFormat, autoclose: true,startDate: currentDate };//2017-07-07 07:35:58 yyyy-mm-dd hh:ii:ss
    let endDateJson={ format: this.dateFormat, autoclose: true,startDate: currentDate };
      $("#startDatePicker").datetimepicker(startDateJson).change(() => {
        if(this.cell.getColumn().class=="startDatePicker")
        {
            this.cell.setValue($("#startDatePicker").val());
            console.log("start date",$("#startDatePicker").val());
        }
      });
      $("#endDatePicker").datetimepicker(endDateJson).change(() => {
        if(this.cell.getColumn().class=="endDatePicker")
        {
            this.cell.setValue($("#endDatePicker").val());
            console.log("end date",$("#endDatePicker").val());
        }
      });
       $("#startDatePicker1").datetimepicker(startDateJson).change(() => {
        if(this.cell.getColumn().class=="startDatePicker1")
        {
            this.cell.setValue($("#startDatePicker1").val());
            console.log("start date uid",$("#startDatePicker1").val());
        }
      });
       $("#endDatePicker1").datetimepicker(endDateJson).change(() => {
        if(this.cell.getColumn().class=="endDatePicker1")
        {
            this.cell.setValue($("#endDatePicker1").val());
            console.log("end date uid",$("#endDatePicker1").val());
        }
      });
  }
}
