import {Component, Input, Output, EventEmitter, OnChanges } from '@angular/core';

import { Grid } from '../../../lib/grid';

@Component({
  selector: 'ng2-st-actions',
  template: `
    <a href="#" class="ng2-smart-action ng2-smart-action-add-create"
        [innerHTML]="createButtonContent"
        (click)="$event.preventDefault();create.emit($event);customiseNumberField()"></a>
    <a href="#" class="ng2-smart-action ng2-smart-action-add-cancel"
        [innerHTML]="cancelButtonContent"
        (click)="$event.preventDefault();grid.createFormShown = false;grid.resetData();"></a>
  `,
})
export class ActionsComponent implements OnChanges {

  @Input() grid: Grid;
  @Output() create = new EventEmitter<any>();

  createButtonContent: string;
  cancelButtonContent: string;

    ngAfterViewChecked() {
    this.customiseNumberField();
  }

  customiseNumberField(){
    /* adding code to restrict input field with type number (excluding e,.,+,-) */
    let inputHTMLComponent=document.getElementsByTagName("input");
    let newCopy=inputHTMLComponent;
    for(let i=0;i<newCopy.length;i++)
    {
        if(newCopy[i].type=="number"){
            newCopy[i].min="0";
            newCopy[i].onkeypress=function(event){
               let charCode=(event.which)?event.which:event.keyCode;
              //left arrow, 37. up arrow, 38. right arrow, 39. down arrow, 40
              //'backspace': 8,'delete': 46,'leftArrow': 37,'rightArrow': 39,
              //console.log("charcode",charCode);

              //if(charCode>31 && (charCode<48 || charCode > 57)) { return false }
              if(charCode!==8 && charCode!==46 && charCode!==37&& charCode!==39 && charCode!==38 && charCode!==40 && (charCode<48 || charCode > 57)) { return false }
              else{ return true }
              //return event.charCode >= 48 && event.charCode <= 57;
            }
        }
    }
  }

  ngOnChanges() {
    this.createButtonContent = this.grid.getSetting('add.createButtonContent');
    this.cancelButtonContent = this.grid.getSetting('add.cancelButtonContent');
  }
}
