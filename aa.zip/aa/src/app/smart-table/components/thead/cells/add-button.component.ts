import { Component, Input, Output, EventEmitter, AfterViewInit, ElementRef, OnChanges } from '@angular/core';

import { Grid } from '../../../lib/grid';
import { DataSource } from '../../../lib/data-source/data-source';

@Component({
  selector: '[ng2-st-add-button]',
  template: `
    <a *ngIf="isActionAdd" href="#" class="ng2-smart-action ng2-smart-action-add-add"
        [innerHTML]="addNewButtonContent" (click)="onAdd($event)"></a>
  `,
})
export class AddButtonComponent implements AfterViewInit, OnChanges {

  @Input() grid: Grid;
  @Input() source: DataSource;
  @Output() create = new EventEmitter<any>();

  isActionAdd: boolean;
  addNewButtonContent: string;

  constructor(private ref: ElementRef) {
  }

  ngAfterViewInit() {
    this.ref.nativeElement.classList.add('ng2-smart-actions-title', 'ng2-smart-actions-title-add');
  }

  ngOnChanges() {
    this.isActionAdd = this.grid.getSetting('actions.add');
    this.addNewButtonContent = this.grid.getSetting('add.addButtonContent');
  }

      ngAfterViewChecked() {
    this.customiseNumberField();
  }

  customiseNumberField(){
    /* adding code to restrict input field with type number (excluding e,.,+,-) */
    let inputHTMLComponent=document.getElementsByTagName("input");
    let newCopy=inputHTMLComponent;
    for(let i=0;i<newCopy.length;i++)
    {
        if(newCopy[i].type=="number"){
            newCopy[i].min="0";
            newCopy[i].onkeypress=function(event){
               let charCode=(event.which)?event.which:event.keyCode;
              //left arrow, 37. up arrow, 38. right arrow, 39. down arrow, 40
              //'backspace': 8,'delete': 46,'leftArrow': 37,'rightArrow': 39,
              //console.log("charcode",charCode);

              //if(charCode>31 && (charCode<48 || charCode > 57)) { return false }
              if(charCode!==8 && charCode!==46 && charCode!==37&& charCode!==39 && charCode!==38 && charCode!==40 && (charCode<48 || charCode > 57)) { return false }
              else{ return true }
              //return event.charCode >= 48 && event.charCode <= 57;
            }
        }
    }
  }

  onAdd(event: any) {
    event.preventDefault();
    event.stopPropagation();
    if (this.grid.getSetting('mode') === 'external') {
      this.create.emit({
        source: this.source,
      });
    } else {
      this.grid.createFormShown = true;
    }
  }
}
