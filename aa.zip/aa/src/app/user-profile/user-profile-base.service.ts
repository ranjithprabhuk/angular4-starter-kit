import { Injectable,OnInit } from '@angular/core';
import { Headers, Http, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Observable';

import { ToastrService } from 'ngx-toastr';

import {ApiService} from '../app.service';
import { LoaderService } from '../shared/loader';
import 'rxjs/add/operator/toPromise';
import { environment } from '../../environments/environment';

@Injectable()
export class UserProfileBaseService extends ApiService{
    constructor(protected http: Http, public loader: LoaderService, public notification: ToastrService) { 
      super(http,loader,notification);
      console.log("UserProfileBaseService");
    }


      //for successfull API response
    protected handleSuccess(response: any): Promise<any> {
        console.log(response);
        if (response.status === 200) {

            //convert the response body as JSON
            let res = response.json();

            if (res.status === "SUCCESS") {
                console.log(res);               
                this.enableLoader = false;
                this.loader.loader.emit(false);
                return Promise.resolve(res.data);
            }
            else {
                this.enableLoader = false;
                this.notification.error(res.data);
                this.loader.loader.emit(false);
                return Promise.reject(res);
            }
        }else{
            this.notification.error("Backend API is not Available");
        }

    }
}