import { Injectable } from '@angular/core';
import { ApiService } from '../app.service';
import { Observable } from 'rxjs/Observable';
import { AbstractControl } from '@angular/forms';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/delay';

import {UserProfileBaseService} from './user-profile-base.service'

@Injectable()
export class UserProfileService {
   // protected apiEndPoint: string =  this.port +  "/";

    protected apiEndPoint: string = 9007 +"/";

    public host = "userManagementServiceHost";

    constructor(protected apiService: UserProfileBaseService) {
         this.getDetails();
    }

    static emailValidator(control: AbstractControl) {
        // RFC 2822 compliant regex
        if (control.value != null && control.value.match(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/)) {
            return null;
        } else {
            return { 'invalidEmailAddress': true };
        }
    }
     
    static passwordValidator(control: AbstractControl) {
        // {6,100}           - Assert password is between 6 and 100 characters
        // (?=.*[0-9])       - Assert a string has at least one number
        // (?!.*\s)          - Spaces are not allowed
        if (control.value != null && control.value.match(/^(?=.*\d)(?=.*[a-zA-Z!@#$%^&*])(?!.*\s).{6,100}$/) || control.value == null) {
            return null;
        } else {
            return { 'invalidPassword': true };
        }
    }

    static passwordMatching(ac: AbstractControl) {
        let newPassword = ac.get('newPassword').value;
        let verifyPassword = ac.get('verifyPassword').value; 
        if(newPassword != null && newPassword != "" && verifyPassword != null && verifyPassword != "" && newPassword != verifyPassword) {          
            ac.get('verifyPassword').setErrors( {passwordMatching: true} )
        } else {           
            return null
        }
    }

    getDetails(): void {
        this.getExternalProperties().then((res) => {
            this.apiEndPoint = res.userManagementServicePort + "/";
        });
    }

    getExternalProperties(): Promise<any> {
        return this.apiService.getExternalApplicationProperties().then(res => { return Promise.resolve(res) });
    }

    getUserProfile(id:number): Promise<any> {       
        return this.apiService.get(this.host,this.apiEndPoint+"getUserProfile?id=" + id)
            .then(res => { return Promise.resolve(res)})
            .catch(err => { return Promise.reject(err)});
    }

    updateUser(userDetail: any) : Promise<any> {       
        return this.apiService.update(this.host,this.apiEndPoint+"editUserProfile",userDetail)
            .then(res => { 
                return Promise.resolve(res)
            })
            .catch(err => { return Promise.reject(err)});
    }
}