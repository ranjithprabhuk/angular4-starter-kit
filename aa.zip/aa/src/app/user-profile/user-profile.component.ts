import { Component,ViewChild } from '@angular/core';
import { ActivatedRoute ,Params } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { LoaderService } from '../shared/loader';
import { ToastrService } from 'ngx-toastr';

import {UserProfileService} from './user-profile.service';

@Component({
  templateUrl: 'user-profile.component.html',
  styleUrls: ['./user-profile.component.css'],
  providers: [UserProfileService]
})
export class UserProfileComponent {
  private userProfileForm: FormGroup;
  private userId : number;
  private languages: Array<Object> = [{name:'German',value:'DE'},{name:'English',value: 'EN'}]; 
  private userDetail: any = {
    "userPreference": {    
      "user": {
        
      },   
    },
    "resetPasswordDTO": {
      "username": null,
      "oldPassword": null,
      "newPassword": null
    }
  };
  
  constructor(  private userProfileService: UserProfileService, 
                private route: ActivatedRoute,  
                private loader: LoaderService, 
                private formBuilder: FormBuilder, 
                private notification: ToastrService) {
    
  }

  ngOnInit(){
    this.buildForm();
    
    this.route.params.subscribe((params: Params) => {
       this.userId = +params['userId'] || 0;      
       //this.userId = 1
       if (this.userId > 0) {         
          this.userProfileService.getUserProfile(this.userId).then(res => {
                this.userDetail = res;
                let user = this.userDetail.userPreference.user;
                this.userDetail.userPreference.user.fullname= user.surname + ' ' + user.lastname;             
            }).catch(err => { this.handleError(err); });   
       }         
    });
    
    if (this.userId == 0) {
      this.disableForm();
    }
    
  }

  buildForm() {
        this.userProfileForm = this.formBuilder.group({
            username:  ['', [ Validators.required]],  
            fullName : [],
            email:     ['', [ Validators.required, UserProfileService.emailValidator ]], 
            language:  [],
            fontSize:  [],         
            oldPassword: ['', [ UserProfileService.passwordValidator ]],  
            newPassword: ['', [ UserProfileService.passwordValidator ] ],
            verifyPassword: []           
            },
            {
               validator: UserProfileService.passwordMatching 
            }
        );
  }

  disableForm() {
      this.userProfileForm.disable();
  }

  handleData() {
    let fullName: string = this.userDetail.userPreference.user.fullname;
    let i : number = fullName.indexOf(' ');
    if (i >=0 ) {     
        this.userDetail.userPreference.user.surname = fullName.substr(0,i);
        this.userDetail.userPreference.user.lastname = fullName.substr(i+ 1);
    } else {
        this.userDetail.userPreference.user.surname = '';
        this.userDetail.userPreference.user.lastname = fullName;
    }
    this.userDetail.resetPasswordDTO.username = this.userDetail.userPreference.user.username;
  }  

  public submit(data) {
    console.log("submit data",data);
    this.handleData();
    console.log("userDetail",this.userDetail);
     this.userProfileService.updateUser(this.userDetail).then(res => {
        this.showSuccess("Update was successful");
     }).catch(err => { this.handleError(err); });    
  }

  public handleError(error: any) {       
        console.log("Error: ", error);
        this.notification.error("Update was unsuccessful"); 
        this.loader.loader.emit(false);        
  }

  public showSuccess(message: any): void {       
      this.notification.success(message); 
      this.loader.loader.emit(false);        
  }
}