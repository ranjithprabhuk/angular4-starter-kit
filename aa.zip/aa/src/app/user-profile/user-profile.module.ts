import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '../shared/shared.module';
//import { FormsModule } from '@angular/forms';

import {UserProfileRoutingModule} from './user-profile-routing.module';
import {UserProfileComponent} from './user-profile.component';
import {UserProfileBaseService} from './user-profile-base.service';

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule, 
    TranslateModule,      
    UserProfileRoutingModule
  ],
  providers: [UserProfileBaseService],
  declarations: [UserProfileComponent ]
})
export class UserProfileModule { }