import { TranslateService,TranslationChangeEvent } from '@ngx-translate/core';   
import { UploadIconComponent } from './components/upload-icon';

export class LicenceManagementConfig {

    constructor(private translate:TranslateService) {

    }

    //table configuration for Licence and Update 
    public licenceSettings: Object = {
        actions: {
            columnTitle: '',
            add: false,
            edit: false,
            delete: false,
            copy: false,
            move: false,
            position: 'left', // left|right
        },
        columns: {
            activeAssistId: {
                title: 'ActiveAssist ID',
                filter: true
            },
            licensenumber: {
                title:  this.translate.instant("LICENCE_MANAGEMENT.LICENCE_NUMBER_COL"), 
                filter: true
            },
            status: {
                title: this.translate.instant("LICENCE_MANAGEMENT.LICENCE_STATUS_COL"), 
                filter: true,
            },
            activeAssistReleaseVersion: {
                title: this.translate.instant("LICENCE_MANAGEMENT.VERSION_COL"), 
                filter: true
            },
            enddate: {
                title: this.translate.instant("LICENCE_MANAGEMENT.EXPIRING_DATE_COL"), 
                filter: true
            },
            updateVersion: {
                title:  this.translate.instant("LICENCE_MANAGEMENT.UPDATE_VERSION_COL"), 
                filter: false,
                type: 'custom',
                renderComponent: UploadIconComponent
            },
            uploadLicence: {
                title:  this.translate.instant("LICENCE_MANAGEMENT.UPLOAD_LICENCE_COL"), 
                filter: false,
                type: 'custom',
                renderComponent: UploadIconComponent
            },
            hardwareInformation: {
                title:  this.translate.instant("LICENCE_MANAGEMENT.HARDWARE_INFO_COL"), 
                filter: false,
                type: 'button',
                buttonText: "Hardware Information"
            },
        },
        pager: {
            display: true,
            perPage: 10
        }
    };

     public updateSettings() {
        this.licenceSettings = {
            actions: {
                columnTitle: '',
                add: false,
                edit: false,
                delete: false,
                copy: false,
                move: false,
                position: 'left', // left|right
            },
            columns: {
                activeAssistId: {
                    title: 'ActiveAssist ID',
                    filter: true
                },
                licensenumber: {
                    title:  this.translate.instant("LICENCE_MANAGEMENT.LICENCE_NUMBER_COL"), 
                    filter: true
                },
                status: {
                    title: this.translate.instant("LICENCE_MANAGEMENT.LICENCE_STATUS_COL"), 
                    filter: true,
                },
                activeAssistReleaseVersion: {
                    title: this.translate.instant("LICENCE_MANAGEMENT.VERSION_COL"), 
                    filter: true
                },
                enddate: {
                    title: this.translate.instant("LICENCE_MANAGEMENT.EXPIRING_DATE_COL"), 
                    filter: true
                },
                updateVersion: {
                    title:  this.translate.instant("LICENCE_MANAGEMENT.UPDATE_VERSION_COL"), 
                    filter: false,
                    type: 'custom',
                    renderComponent: UploadIconComponent
                },
                uploadLicence: {
                    title:  this.translate.instant("LICENCE_MANAGEMENT.UPLOAD_LICENCE_COL"), 
                    filter: false,
                    type: 'custom',
                    renderComponent: UploadIconComponent
                },
                hardwareInformation: {
                    title:  this.translate.instant("LICENCE_MANAGEMENT.HARDWARE_INFO_COL"), 
                    filter: false,
                    type: 'button',
                    buttonText: "Hardware Information"
                },
            },
            pager: {
                display: true,
                perPage: 10
            }
        };   
     }
}