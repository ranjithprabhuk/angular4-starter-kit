import { Injectable } from '@angular/core';
import { URLSearchParams } from '@angular/http';
import { ApiService } from '../app.service';

import 'rxjs/add/operator/toPromise';


@Injectable()
export class LicenceManagementService {

    constructor(private apiService: ApiService) { }

    //protected apiEndPoint: string = this.apiService.baseUrl.licenseManagementServicePort +"/";
    protected apiEndPoint: string =  "";

    public host = "licenseManagementService";

    getDetails(): void {
        this.getExternalProperties().then((res) => {
            this.apiEndPoint = res.licenseManagementServicePort + "/";
        });
    }

    getExternalProperties(): Promise<any> {
        return this.apiService.getExternalApplicationProperties().then(res => { return Promise.resolve(res) });
    }

    //to get the registered license information
    getLicenseData(parameter?: any): Promise<any> {
        let params: URLSearchParams = new URLSearchParams();
        return this.apiService.get(this.host, this.apiEndPoint + "getAllRegisteredLicenseInformation")
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    //upload the license file
    uploadLicense(file: any, parameter: any): Promise<any> {
        let params: URLSearchParams = new URLSearchParams();
        params.append("activeAssistId", parameter);
        return this.apiService.upload(this.host, this.apiEndPoint + "uploadLicenseInformationFile?activeAssistId=" + parameter, file)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    //to get the registered license information
    getHardwareInformation(parameter?: any): Promise<any> {
        let params: URLSearchParams = new URLSearchParams();
        return this.apiService.get(this.host, this.apiEndPoint + "generateHardwareInformationFile?activeAssistId=" + parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }


}
