import { Component } from '@angular/core';

@Component({
    selector : 'upload-icon',
    template : '<div class="text-center"><img src="../assets/img/icons/upload.png" /></div>'
})

export class UploadIconComponent {

}


