import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LicenceManagementComponent } from './licence-management.component';

const routes: Routes = [
  {
    path: '',
    component: LicenceManagementComponent,
    data: {
      title: 'Licence and Updates'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LicenceManagementRoutingModule {}
