import { Component, ViewChild } from '@angular/core';

import { Ng2SmartTableModule, LocalDataSource } from '../smart-table';
import { ModalDirective } from 'ng2-bootstrap/modal';
import { TranslateService, TranslationChangeEvent } from '@ngx-translate/core';
import { LicenceManagementConfig } from './licence-management.config';
import { LicenceManagementService } from './licence-management.service';
import { AuthenticationService } from '../authentication/authentication.service';

import { AppConfig } from '../app.config';

import { ToastrService } from 'ngx-toastr';
@Component({
  templateUrl: 'licence-management.component.html',
  styleUrls: ['./licence-management.component.css'],
  providers: [LicenceManagementService]
})

export class LicenceManagementComponent {

  constructor(private licenseManagementService: LicenceManagementService,
    private notificationService: ToastrService,
    private translate: TranslateService,
    private authService: AuthenticationService) {
    this.checkPermissions();
    this.softwareUpdatePermission = this.authService.appPermissions["Licence Updates"];
    this.licenceData = new LocalDataSource();
    this.translate.onLangChange.subscribe((event: TranslationChangeEvent) => {
      this.doTranslate();
    });
  }

  public licenceManageConfig = new LicenceManagementConfig(this.translate);
  public licenceSettings: Object = new LicenceManagementConfig(this.translate).licenceSettings;

  public licenceData: LocalDataSource;
  public selectedActiveAssistId: string;
  public softwareUpdatePermission: boolean = false;
  public apiBase: string = new AppConfig().apiBase + "9011/generateHardwareInformationFile?activeAssistId=";

  doTranslate() {
    this.licenceManageConfig.updateSettings();
  }

  public checkPermissions(): void {
    if (this.authService.appPermissions == undefined) {
      this.authService.logout();
    }
  }

  public openUploadDialog(event, permission): void {
    if (permission) {
      if (event.column.title == "Update Version") {
        document.getElementById("version-file-input").click();
      } else if (event.column.title == "Upload Licence") {
        document.getElementById("licence-file-input").click();
        this.selectedActiveAssistId = event.row.data.activeAssistId;
      } else if (event.column.title == "Hardware Information") {
        let _url = this.apiBase + event.row.data.activeAssistId;
        document.getElementById("trigger-download").setAttribute("href", _url);
        console.log(document.getElementById("trigger-download"));
        document.getElementById("trigger-download").click();
      }
    }else{
      this.notificationService.warning("You dont have permission for license updates");
    }
  };

  public uploadLicenseFile(event: any): void {
    let file: File = event.target.files[0];
    let formData: FormData = new FormData();
    formData.append('file', file, file.name);
    this.licenseManagementService.uploadLicense(formData, this.selectedActiveAssistId).then(res => {
      this.notificationService.success(res);
    }).catch(err => { console.log("Error: ", err); });
  };

  //get the license data
  public getLicenseData(): void {
    this.licenseManagementService.getLicenseData().then(res => {
      this.licenceData.load(res);
    }).catch(err => { console.log("Error: ", err); });
  };

  public getHardwareInformation(): void {
    this.licenseManagementService.getHardwareInformation(this.selectedActiveAssistId).then(res => {
      //this.licenceData.load(res);
    }).catch(err => { console.log("Error: ", err); });
  };

  ngOnInit() {
    this.getLicenseData();
  }

}


