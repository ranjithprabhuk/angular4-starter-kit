import { NgModule } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

import { TabsModule,ModalModule } from 'ng2-bootstrap';
import { Ng2SmartTableModule } from '../smart-table';

import { TranslateModule } from '@ngx-translate/core';


import { LicenceManagementComponent } from './licence-management.component';
import { LicenceManagementRoutingModule } from './licence-management-routing.module';
import { UploadIconComponent } from './components/upload-icon';

@NgModule({
  imports: [
    LicenceManagementRoutingModule,
    CommonModule,
    FormsModule,
    Ng2SmartTableModule,
    TranslateModule,
    TabsModule.forRoot(),
    ModalModule.forRoot()
  ],
  declarations: [ LicenceManagementComponent, UploadIconComponent ],
  entryComponents : [ UploadIconComponent]
})
export class LicenceManagementModule { }
