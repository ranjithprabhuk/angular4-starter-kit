import { TranslateService,TranslationChangeEvent } from '@ngx-translate/core';        
export class DeviceManagementLocalConfig {

    constructor(private translate:TranslateService) {

    }

    //pagination  settings
    public paginationSettings: Object = {
    display: true,
    perPage: 10
    };
    //table configuration forVirtualAreasSettings
      public VirtualAreasSettings: Object = {
        actions: {
            columnTitle: '',
            add: false,
            edit: false,
            delete: false,
            copy: false,
            move: false,
            position: 'left', // left|right
        },
        columns: {
            type: {
                title: this.translate.instant("DEVICE_MANAGEMENT_LOCAL.TYPE_COL"),
                filter: true,
                minWidth: "100px"
            },
            name: {
                title: this.translate.instant("DEVICE_MANAGEMENT_LOCAL.NAME_COL"),
                filter: true,
                minWidth: "106px"
            },
            // form: {
            //     title: 'Form',
            //     filter: true,
            //     minWidth: "100px",
            //     //editable: false, 
            //     editor: {
            //         type: 'list',
            //         config: {
            //             //selectText: 'Select',
            //             list: [
            //                 { value: '', title: 'Select' },
            //                 { value: 'circle', title: 'Circle' },
            //                 { value: 'square', title: 'Square' }
            //             ],
            //         }
            //      }
            // },
            // color: {
            //     title: 'Color',
            //     filter: true,
            //     minWidth: "100px",
            //     type:  "color",
                //editable: false, 
                // editor: {
                //     type: 'list',
                //     config: {
                //         //selectText: 'Select',
                //         list: [
                //             { value: '', title: 'Select' },
                //             { value: 'blue', title: '#0000CD' },
                //             { value: 'red', title: '#FF0000' },
                //             { value: 'orange', title: '#FFA500'},
                //             { value: "yellow", title : "#FFD700"},
                //             { value: "green", title: "#00CD00"},
                //             { value: "white", title: "#FFFFFF"}                            
                //         ],
                //     }
                //  }
            // },
            projectionArea: {
                title: this.translate.instant("DEVICE_MANAGEMENT_LOCAL.PROJECTION_AREA_COL"),
                filter: true,
                minWidth: "300px",
                projectionAreaIcon: true
            },
            vHandTrackingCoordinates:{
                title: this.translate.instant("DEVICE_MANAGEMENT_LOCAL.HAND_TRACKING_COORD_COL"),
                filter: true,
                minWidth: "250px",
                projectionAreaIcon: true
            }
        },
        pager: this.paginationSettings
    };
    public SensorActorSettings: Object = {
        actions: {
            columnTitle: 'Actions',
            add: false,
            edit: true,
            delete: false,
            copy: false,
            move: false,
            position: 'left', // left|right
        },
        columns: {
            port: {
                title: this.translate.instant("DEVICE_MANAGEMENT_LOCAL.PORT_COL"),
                filter: true,
                minWidth: "100px"
            },
            posnr: {
                title: this.translate.instant("DEVICE_MANAGEMENT_LOCAL.PORT_NUMBER_COL"),
                filter: true,
                minWidth: "106px"
            },
            type: {
                title: this.translate.instant("DEVICE_MANAGEMENT_LOCAL.TYPE_COL"),
                filter: true,
                minWidth: "50px"
            }
           
         
        },
        pager: this.paginationSettings
    };
 
    public updateSettings() {   
        this.VirtualAreasSettings = {
            actions: {
                columnTitle: '',
                add: false,
                edit: false,
                delete: false,
                copy: false,
                move: false,
                position: 'left', // left|right
            },
            columns: {
                type: {
                    title: this.translate.instant("DEVICE_MANAGEMENT_LOCAL.TYPE_COL"),
                    filter: true,
                    minWidth: "100px"
                },
                name: {
                    title: this.translate.instant("DEVICE_MANAGEMENT_LOCAL.NAME_COL"),
                    filter: true,
                    minWidth: "106px"
                },              
                projectionArea: {
                    title: this.translate.instant("DEVICE_MANAGEMENT_LOCAL.PROJECTION_AREA_COL"),
                    filter: true,
                    minWidth: "300px",
                    projectionAreaIcon: true
                },
                vHandTrackingCoordinates:{
                    title: this.translate.instant("DEVICE_MANAGEMENT_LOCAL.HAND_TRACKING_COORD_COL"),
                    filter: true,
                    minWidth: "250px",
                    projectionAreaIcon: true
                }
            },
            pager: this.paginationSettings
        };
        this.SensorActorSettings = {
            actions: {
                columnTitle: 'Actions',
                add: false,
                edit: true,
                delete: false,
                copy: false,
                move: false,
                position: 'left', // left|right
            },
            columns: {
                port: {
                    title: this.translate.instant("DEVICE_MANAGEMENT_LOCAL.PORT_COL"),
                    filter: true,
                    minWidth: "100px"
                },
                posnr: {
                    title: this.translate.instant("DEVICE_MANAGEMENT_LOCAL.PORT_NUMBER_COL"),
                    filter: true,
                    minWidth: "106px"
                },
                type: {
                    title: this.translate.instant("DEVICE_MANAGEMENT_LOCAL.TYPE_COL"),
                    filter: true,
                    minWidth: "50px"
                }
            
            
            },
            pager: this.paginationSettings
        };
    }
}