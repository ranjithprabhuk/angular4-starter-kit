import { Component, ViewChild, Injectable, Input } from '@angular/core';
import { Ng2SmartTableModule, LocalDataSource } from '../smart-table';
import { ModalDirective } from 'ng2-bootstrap/modal';
import { TabsetComponent } from 'ng2-bootstrap';
import { TranslateService, TranslationChangeEvent } from '@ngx-translate/core';
import { DeviceManagementLocalConfig } from './device-management-local.config';
import { DeviceManagementLocalService } from './device-management-local.service';
import { AuthenticationService } from '../authentication/authentication.service';

import { ToastrService } from 'ngx-toastr';
@Injectable()
@Component({
  templateUrl: 'device-management-local.component.html',
  styleUrls: ['./device-management-local.component.css'],
  providers: [DeviceManagementLocalService]
})

export class DeviceManagementLocalComponent {
  @ViewChild('ProjectionAreaModal') public ProjectionAreaModal: ModalDirective;
  @ViewChild('VAHandTrackingModal') public VAHandTrackingModal: ModalDirective;
  @ViewChild('RestoreModal') public RestoreModal: ModalDirective;
  @ViewChild('BackupModal') public BackupModal: ModalDirective;
  @ViewChild('CloneModal') public CloneModal: ModalDirective;
  @ViewChild('DeleteSystemLightModal') public DeleteSystemLightModal: ModalDirective;

  public selectedRowBoxesRails: any;
  public productTypeData: Array<String>;
  public projectionFormData: any = {};
  public enableAdd: boolean = true;

  constructor(private deviceManagementLocalService: DeviceManagementLocalService, private translate: TranslateService, private notificationService: ToastrService,
    private authService: AuthenticationService) {
    // Expert Settings
    this.productIndetification = new LocalDataSource();
    this.activeAssistCamera = new LocalDataSource();
    this.translate.onLangChange.subscribe((event: TranslationChangeEvent) => {
      this.doTranslate();
    });
  }

  public deviceManagementLocalConfig = new DeviceManagementLocalConfig(this.translate);
  // ActiveAssistID DropDown
  public selectedActiveAssistId: String;
  public activeAssistIdList: Array<String>;
  public sensorModule: String;


  public show_box_projection_text: any;
  public show_handtracking_coordinates: any;
  public show_projection_text: any;

  public selectedTab: String = 'DEVICE_MANAGEMENT_LOCAL.VIRTUAL_AREAS';
  public settingsVirtualAreas: any = this.deviceManagementLocalConfig.VirtualAreasSettings;
  public settingsSensorActor: any = this.deviceManagementLocalConfig.SensorActorSettings;

  // Expert Settings
  public productIdentificationData: Object;
  public handTrackingData: Object;
  public cameraActiveAssistData: Object;
  public productIndetification: LocalDataSource;
  public activeAssistCamera: LocalDataSource;


  doTranslate() {
    this.deviceManagementLocalConfig.updateSettings();
    //this.material.refresh();    
  }

  public checkPermissions(): void {
    if (this.authService.appPermissions == undefined) {
      this.authService.logout();
    }
  }


  // to get all active assist ID
  public getAllActiveAssistID(): void {
    this.deviceManagementLocalService.getAllActiveAssistIDData().then(res => {
      // list of active asssit id
      this.activeAssistIdList = res;
    });
  };


  //  to get the list of ProductIndetification
  public getProductIndetification(): void {
    //call the device management service to get the data
    if (this.selectedActiveAssistId && typeof (this.selectedActiveAssistId) == "string") {
      this.deviceManagementLocalService.getProductIndetificationData(this.selectedActiveAssistId).then(res => {
        if (typeof res == "string") {
          this.productIdentificationData = {};
        } else {
          res.activeAssistId = this.selectedActiveAssistId;
          this.productIdentificationData = res;
        }
      }).catch(err => { console.log("Error: ", err); });
    } else {
      this.notificationService.warning("Kindly select an Active Assist from the dropdown");
    }
  };



  //  to get the list of Beamer
  public getBeamer(): void {
    //call the device management service to get the data
    if (this.selectedActiveAssistId && typeof (this.selectedActiveAssistId) == "string") {
      this.deviceManagementLocalService.getBeamerData(this.selectedActiveAssistId).then(res => {
        if (typeof res == "string") {
          this.productIdentificationData = { "activeAssistId": this.selectedActiveAssistId};
        } else {
          res.activeAssistId = this.selectedActiveAssistId;
          this.productIdentificationData = res;
        }
      }).catch(err => { console.log("Error: ", err); });
    } else {
      this.notificationService.warning("Kindly select an Active Assist from the dropdown");
    }
  };

  //  to get the list of Hand Tracking
  public getHandTracking(): void {
    //call the device management service to get the data
    if (this.selectedActiveAssistId && typeof (this.selectedActiveAssistId) == "string") {
      this.deviceManagementLocalService.getHandTrackingData(this.selectedActiveAssistId).then(res => {
        if (typeof res == "string") {
          this.productIdentificationData = { "activeAssistId": this.selectedActiveAssistId};
        } else {
          res.activeAssistId = this.selectedActiveAssistId;
          this.productIdentificationData = res;
        }
      }).catch(err => { console.log("Error: ", err); });
    } else {
      this.notificationService.warning("Kindly select an Active Assist from the dropdown");
    }
  };


  //  to get the list of ActiveAssist Camera
  public getActiveAssistCamera(): void {
    //call the device management service to get the data
    if (this.selectedActiveAssistId && typeof (this.selectedActiveAssistId) == "string") {
      this.deviceManagementLocalService.getActiveAssistCameraData(this.selectedActiveAssistId).then(res => {
        if (typeof res == "string") {
          this.productIdentificationData = { "activeAssistId": this.selectedActiveAssistId};
        } else {
          res.activeAssistId = this.selectedActiveAssistId;
          this.productIdentificationData = res;
        }
      }).catch(err => { console.log("Error: ", err); });
    } else {
      this.notificationService.warning("Kindly select an Active Assist from the dropdown");
    }
  };

  /*****           ###### Sensor Module ######             *****/

  //Get all the sensor module by ID
  public getAllSensorModuleByActiveAssistId(): void {
    if (this.selectedActiveAssistId) {
      this.deviceManagementLocalService.getAllSensorModuleByActiveAssistId(this.selectedActiveAssistId).then(res => {
        res.activeAssistId = this.selectedActiveAssistId;
        this.sensorModule = res;
      }).catch(err => { console.log("Error :", err) });
    } else {
      this.notificationService.warning("Kindly select a Active Assist in the dropdown");
    }
  };


  public getSensorModuleId(data: any): any {
    let sensorModuleList = this.sensorModule;
    for (let i = 0; i < sensorModuleList.length; i++) {
      if (data == sensorModuleList[i]) {
        return sensorModuleList[i];
      }
    }
  }

  //Get sensor module based on sensor ID
  public getAllSensorModuleBySensorModuleId(sensorModuleId): void {
    this.deviceManagementLocalService.getAllSensorModuleBySensorModuleId(sensorModuleId).then(res => {

    }).catch(err => { console.log("Error :", err) })

  }

  /**---------------------- End of Sensor Module -------------------------**/


  //Virtual Areas Tab Data
  public _virtualAreasData = [
    {
      type: "Button",
      name: "Confirm",
      form: '',
      color: '',
      projectionArea: "x=10,y=10,width=600,height=200",
      vHandTrackingCoordinates: "x=23,y=5,z=35"
    },
    {
      type: "Button",
      name: "Forward",
      form: "",
      color: "",
      projectionArea: "x=10,y=10,width=600,height=200",
      vHandTrackingCoordinates: "x=23,y=5,z=35"
    },
    {
      type: "Button",
      name: "Backward",
      form: "",
      color: "",
      projectionArea: "x=10,y=10,width=600,height=200",
      vHandTrackingCoordinates: "x=23,y=5,z=35"
    },
    {
      type: "Marker",
      name: "DellXPS15_5",
      form: "Circle",
      color: "#FFEEDD",
      projectionArea: "x=10,y=10,width=600,height=200",
      vHandTrackingCoordinates: "x=23,y=5,z=35"
    }
  ];

  public showProjectionAreaModal(): any {
    this.ProjectionAreaModal.show();
  }
  public showVAHandTrackingModalModal(): any {
    this.VAHandTrackingModal.show();
  }
  public onCellClickVirtualAreas(event: any): void {
    if (event.column.id == "projectionArea") {
      this.showProjectionAreaModal();
    }
    if (event.column.id == "vHandTrackingCoordinates") {
      this.showVAHandTrackingModalModal();
    }
  };
  public eventStartTeaching($event): void {
    console.log("event start teaching", $event);
    // let a=$event.data;
    // a["boxPosition"]=2;
    // a["boxProjectionArea"]="x=40,y=80,width=100,height=480";
    // a["boxtypeName"]="Type 3";
    // a["handTrackingCoordinates"]="x=45,y=50,z=15";
    // a["material"]="2432 000 222";
    // a["p2lPosNr"]="20";

  }

  public eventOk($event): void {

  }

  ngOnInit() {
    this.getAllActiveAssistID();
    this.getProductTypes();
  }


  /*                 #### Sensor Actor ####                  */

  public sensorActorData: Array<any> = [];
  public addPictolightTab = false;

  public getSensorActorData(activeAssistId) {
    if (this.selectedTab == "DEVICE_MANAGEMENT_LOCAL.SENSOR_ACTOR") {
      this.deviceManagementLocalService.getAllSensorModuleByActiveAssistId(activeAssistId).then(res => {
        this.sensorActorData = res;
      });
    }
  }

  public setSelectedSensor(id: any, index: number): void {
    if ((!this.selectedActiveAssistId) || typeof (this.selectedActiveAssistId) != "number") {      
      this.notificationService.warning("Kindly select an Active Assist from the dropdown");
    } else if (id) {
      this.deviceManagementLocalService.getAllSensorModuleBySensorModuleId(id).then(res => {
        this.sensorActorData[index].tableData = res.sensorModulePort;
        this.viewSelectedmodule(index);
      }).catch(err => { console.log("Error :", err) });
    }
    else {
      this.viewSelectedmodule(index);
    }
  }

  public addNewSensor(): void {
    let pickToMods = [];
    for (let i = 0; i < this.sensorActorData.length; i++) {
      if (this.sensorActorData[i].moduleType == 'Pick-To-Light') {
        pickToMods.push(this.sensorActorData);
      }
    }

    for (let i = 0; i < this.sensorActorData.length; i++) {
      if (!this.sensorActorData[i].id) {
        this.enableAdd = false;
        break;
      }
      this.enableAdd = true;
      if (this.sensorActorData[i].selected) {
        this.sensorActorData[i].selected = false;
        break;
      }
    }

    if (pickToMods.length == 13) {
      this.notificationService.warning("Only Limited Pick To Lights can be added");
    } else if ((!this.selectedActiveAssistId) && (typeof (this.selectedActiveAssistId) != "number")) {
      this.notificationService.warning("Kindly select an Active Assist from the dropdown");
    } else {
      if (this.enableAdd) {
        let _sensorData = { "activeAssistId": this.selectedActiveAssistId, "moduleName": "", "isEnabled": 1, "ip": "", "moduleType": "Pick-To-Light", "selected": true };
        this.sensorActorData.push(_sensorData);
      }
    }
  }

  public deleteSensor(): void {
    for (let i = 0; i < this.sensorActorData.length; i++) {
      if (this.sensorActorData[i].selected && this.sensorActorData[i].moduleType == "Pick-To-Light") {
        this.deviceManagementLocalService.deleteSensorModule(this.sensorActorData[i].id).then(res => {
          console.log(this.sensorActorData[i]);
          this.getSensorActorData(this.selectedActiveAssistId);
          this.DeleteSystemLightModal.hide();
          this.notificationService.success("Selected PickToLight deleted Successfully");
        }).catch(err => { console.log("Error: ", err); });
        // this.sensorActorData.splice(i, 1);       
      } else {
        if (this.sensorActorData[i].selected && this.sensorActorData[i].moduleType != "Pick-To-Light") {
          this.DeleteSystemLightModal.hide();
          this.notificationService.warning("Kindly select a PickToLight module to delete");
          break;
        }
      }
    }
  };

  public viewSelectedmodule(index) {
    for (let i = 0; i < this.sensorActorData.length; i++) {
      this.sensorActorData[i].isEnabled = 1;
      if (this.sensorActorData[i].selected) {
        this.sensorActorData[i].selected = false;
        break;
      }
    }
    this.sensorActorData[index].selected = true;
  }

  public findType(dataVal) {
    return typeof dataVal;
  }
  /** ----------------------- End of Sensor Actor ----------------------- **/



  /*                 #### Virtual Areas ####                  */

  public getProductTypes(): void {
    this.deviceManagementLocalService.getProductTypes().then(res => {
      this.productTypeData = res.content;
    }).catch(err => { console.log("Error: ", err); });
  };

  public updateProjectionarea(): void {
    console.log(this.projectionFormData);
  }

  @Input() data: Object;

  ngOnChanges() {
    if (this.data)
      this.projectionFormData = this.data;
  }
}
