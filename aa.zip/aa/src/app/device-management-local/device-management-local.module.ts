import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { TabsModule,ModalModule } from 'ng2-bootstrap';
import { Ng2SmartTableModule } from '../smart-table';
import { TranslateModule } from '@ngx-translate/core';

import { DeviceManagementLocalComponent } from './device-management-local.component';
import { DeviceManagementLocalRoutingModule } from './device-management-local-routing.module';


//Components
import { ProductIdentificationComponent } from './expert-setting/product-identification/product-identification';
import { CameraComponent } from './expert-setting/camera/camera';
import { BeamerComponent } from './expert-setting/beamer/beamer';
import { HandTrackingComponent } from './expert-setting/hand-tracking/hand-tracking';

// Adding Sensor Actor components 
import { SystemLightComponent } from './sensor-actor/system-light/system-light';
import { PushButtonComponent } from './sensor-actor/push-button/push-button';
import { ScrewDriverComponent } from './sensor-actor/screw-driver/screw-driver';
import { P2LComponent } from './sensor-actor/p2l/p2l';
import { P2LAddComponent } from './sensor-actor/p2l-add/p2l-add';

@NgModule({
  imports: [
    DeviceManagementLocalRoutingModule,
    CommonModule,
    FormsModule,
    Ng2SmartTableModule,
    TranslateModule,
    TabsModule.forRoot(),
    ModalModule.forRoot()
  ],
  declarations: [ DeviceManagementLocalComponent,ProductIdentificationComponent,CameraComponent,BeamerComponent,HandTrackingComponent, SystemLightComponent,PushButtonComponent,ScrewDriverComponent,P2LComponent, P2LAddComponent]
})
export class DeviceManagementLocalModule { }
