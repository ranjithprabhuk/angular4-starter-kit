import { Injectable } from '@angular/core';
import { URLSearchParams } from '@angular/http';
import { ApiService } from '../app.service';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class DeviceManagementLocalService {

    constructor(private apiService: ApiService) { 
        //this.getDetails();
    }

    //protected apiEndPointAssembly: string = this.apiService.baseUrl.assemblyManagementServicePort +"/";
    protected apiEndPointAssembly: string = "";

    public assemblyhost = "assemblyManagementService";

    //protected apiEndPoint: string = this.apiService.baseUrl.deviceManagementServicePort +"/";
    protected apiEndPoint: string = "";

    public host = "deviceManagementService";

    getDetails(): void {
        this.getExternalProperties().then((res) => {
            this.apiEndPoint = res.deviceManagementServicePort + "/";
            this.apiEndPointAssembly = res.assemblyManagementServicePort + "/";
        });
    }

    getExternalProperties(): Promise<any> {
        return this.apiService.getExternalApplicationProperties().then(res => { return Promise.resolve(res) });
    }


    //to get the Active Assist ID - DropDown
    getAllActiveAssistIDData(parameter?: any): Promise<any> {
        let params: URLSearchParams = new URLSearchParams();
        return this.apiService.get(this.host, this.apiEndPoint + "getAllActiveAssistID")
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    /**
    * Expert Settings 
    * getProductIndetificationData()- to get Product Indetification Data
    * getActiveAssistCameraData()- to get ActiveAssist Camera Data
    */

    //to get the Product Indetification data
    getProductIndetificationData(parameter?: any): Promise<any> {
        let params = "?activeAssistId=" + parameter;
        return this.apiService.get(this.host, this.apiEndPoint + "getProductIndetification" + params)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }


    //to get the Hand Tracking data
    getHandTrackingData(parameter?: any): Promise<any> {
        let params = "?inputActiveAssistId=" + parameter;
        return this.apiService.get(this.host, this.apiEndPoint + "getHandTracking" + params)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }


    //to get the Beamer data
    getBeamerData(parameter?: any): Promise<any> {
        let params = "?activeAssistId=" + parameter;
        return this.apiService.get(this.host, this.apiEndPoint + "getActiveAssistBeamer" + params)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    //to get the ActiveAssist Camera data
    getActiveAssistCameraData(parameter?: any): Promise<any> {
        let params = "?activeAssistId=" + parameter;
        return this.apiService.get(this.host, this.apiEndPoint + "getActiveAssistCamera" + params)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }



    //to save Active Assist Camera
    saveActiveAssistCameraData(parameter?: any): Promise<any> {
        return this.apiService.create(this.host, this.apiEndPoint + "saveActiveAssistCamera", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }


    //to save Beamer
    saveBeamerData(parameter?: any): Promise<any> {
        return this.apiService.create(this.host, this.apiEndPoint + "saveActiveAssistBeamer", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }



    //to save HandTracking
    saveHandTrackingData(parameter?: any): Promise<any> {
        return this.apiService.create(this.host, this.apiEndPoint + "saveHandTracking", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }



    //to save ProductIndetification
    saveProductIndetificationData(parameter?: any): Promise<any> {
        return this.apiService.create(this.host, this.apiEndPoint + "saveProductIndetification", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    //....................Sensor Module----------------------------

    //Sensor actor API Call create
    //      // to save a new sensor Module(create)
    createSensorModule(parameter?: any): Promise<any> {
        return this.apiService.create(this.host, this.apiEndPoint + "createSensorModule", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }


    /* Sensor Module get all sensor module by passing active assist ID */
    getAllSensorModuleByActiveAssistId(parameter?: any): Promise<any> {
        let params = "?activeAssistId=" + parameter;
        return this.apiService.get(this.host, this.apiEndPoint + "getAllSensorModule" + params)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }

    /* Sensor Module get all sensor module by passing active assist ID */
    getAllSensorModuleBySensorModuleId(parameter?: any): Promise<any> {
        //  let params: URLSearchParams = new URLSearchParams();
        return this.apiService.get(this.host, this.apiEndPoint + "getSensorModuleById/" + parameter)

            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }


    //to update Sensor Module (edit)
    updateSensorModule(parameter?: any): Promise<any> {console.log(parameter);
        return this.apiService.update(this.host, this.apiEndPoint + "updateSensorModule", parameter)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }


    // Selete sensor module
    deleteSensorModule(parameter?: any): Promise<any> {
        let params = "?sensorModuleId=" + parameter;
        return this.apiService.delete(this.host, this.apiEndPoint + "deleteSensorModule" + params)
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }
    //....................Sensor Module----------------------------

    //to get the list of Product Types
    getProductTypes(parameter?: any): Promise<any> {
        return this.apiService.get(this.assemblyhost, this.apiEndPointAssembly + "getProductTypes")
            .then(res => { return Promise.resolve(res) })
            .catch(err => { return Promise.reject(err) });
    }


}
