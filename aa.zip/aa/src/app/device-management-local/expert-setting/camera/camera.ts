import { Component, Input, ViewChild } from '@angular/core';
import { ModalDirective } from 'ng2-bootstrap/modal';
import { TranslateService } from '@ngx-translate/core';
import { ToastrService } from 'ngx-toastr';
import { DeviceManagementLocalService } from '../../device-management-local.service';
import { AuthenticationService } from '../../../authentication/authentication.service';

@Component({
    selector: "camera",
    templateUrl: "./camera.html",
    styleUrls: ["./camera.css"]
})


export class CameraComponent {
    @ViewChild('SaveCameraActiveAssistModal') public SaveCameraActiveAssistModal: ModalDirective;
    @Input() data: Object;
    constructor(private deviceManagementLocalService: DeviceManagementLocalService,
        private translate: TranslateService, private notificationService: ToastrService,
        private authService: AuthenticationService) {
        this.checkPermissions();
        this.expertSettingPermission = this.authService.appPermissions["Expert Settings"];
    }

    public cameraActiveAssistData: any = {};
    public expertSettingPermission: boolean = false;

    //to update an Product Indetification
    public updatecameraActiveAssist(): void {
        let camera = this.cameraActiveAssistData;
        console.log("data camera>>", camera);
        let data = {
            "cameraMinDepth": camera.cameraMinDepth,
            "cameraMaxDepth": camera.cameraMaxDepth,
            "id":  (camera.id) ? camera.id : 0,
            "cameraDistance": camera.cameraDistance,
            "cameraFlipHorizontal": (camera.cameraFlipHorizontal) ? 1 : 0,
            "cameraFlipVertical": (camera.cameraFlipVertical) ? 1 : 0,
            "flipSensors": (camera.flipSensors) ? 1 : 0,
            "displayBoxesOnDebugScreen": (camera.displayBoxesOnDebugScreen) ? 1 : 0,
            "activeAssistId": camera.activeAssistId,
        }
        this.deviceManagementLocalService.saveActiveAssistCameraData(data).then(res => {
            this.SaveCameraActiveAssistModal.hide();
        });

    }

    public checkPermissions(): void {
        if (this.authService.appPermissions == undefined) {
            this.authService.logout();
        }
    }




    ngOnChanges() {
        console.log("data>>", this.data);
        if (this.data)
            this.cameraActiveAssistData = this.data;
    }

}