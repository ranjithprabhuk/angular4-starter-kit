import { Component, Input, ViewChild } from '@angular/core';
import { ModalDirective } from 'ng2-bootstrap/modal';
import { TranslateService } from '@ngx-translate/core';
import { ToastrService } from 'ngx-toastr';
import { DeviceManagementLocalService } from '../../device-management-local.service';
import { AuthenticationService } from '../../../authentication/authentication.service';
@Component({
    selector: "product-identification",
    templateUrl: "./product-identification.html",
    styleUrls: ["./product-identification.css"],
    providers: [DeviceManagementLocalService]
})

export class ProductIdentificationComponent {
    @ViewChild('SaveProductIdentificationModal') public SaveProductIdentificationModal: ModalDirective;
    @Input() data: Object;
    @Input() passactvid: any;
    constructor(private deviceManagementLocalService: DeviceManagementLocalService,
        private translate: TranslateService, private notificationService: ToastrService,
        private authService: AuthenticationService) {
        this.checkPermissions();
        this.expertSettingPermission = this.authService.appPermissions["Expert Settings"];
    }

    public productIdentificationData: any = {};
    public expertSettingPermission: boolean = false;

    public checkPermissions(): void {
        if (this.authService.appPermissions == undefined) {
            this.authService.logout();
        }
    }



    //to update an Product Indetification
    public updateproductIndetification(): void {
        let flag_AA = false;
        let product = this.productIdentificationData;
        console.log("data product>>", product);
        let data = {
            "activeAssistId": product.activeAssistId,
            "busCouplerRemoteIP": product.busCouplerRemoteIP,
            "id": product.id,
            "productNumberFormat": product.productNumberFormat,
            "rfidAntennaPower": product.rfidAntennaPower,
            "rfidModuleRemoteIP": product.rfidModuleRemoteIP,
            "rfidModuleRemotePort": product.rfidModuleRemotePort,
        }
        let checkIPFormat = new RegExp("^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$");
        let correctIP = checkIPFormat.test(data.busCouplerRemoteIP);
        let checkIPFormatrfid = new RegExp("^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$");
        let correctIPrfid = checkIPFormat.test(data.rfidModuleRemoteIP);
        if (!correctIP) {
            flag_AA = true;
            this.notificationService.warning("Kindly give a valid IP address for Bus couplerRemoteIP");
        } else if (!correctIPrfid) {
            flag_AA = true;
            this.notificationService.warning("Kindly give a valid IP address for RFID Module");
        } else if (data.rfidModuleRemotePort < 0 && data.rfidModuleRemotePort > 65535) {
            flag_AA = true;
            this.notificationService.warning("Kindly give a valid Port Number for RFID");
        } else {
            this.deviceManagementLocalService.saveProductIndetificationData(data).then(res => {
                this.notificationService.success("Product Identification updated succesfully")
                this.SaveProductIdentificationModal.hide();
            });
        }
    }

    cancelData(d) {
        this.productIdentificationData = Object.assign({}, this.data);
    }

    checkNumber(event) {
        let charCode = (event.which) ? event.which : event.keyCode;
        if (charCode != 9 && charCode !== 8 && charCode !== 46 && charCode !== 37 && charCode !== 39 && charCode !== 38 && charCode !== 40 && (charCode < 48 || charCode > 57)) { return false }
        else { return true }
    }



    ngOnChanges() {

        if (this.data)
            this.productIdentificationData = Object.assign({}, this.data);

        console.log("activeassistid", this.passactvid);
        if (this.passactvid)
            this.productIdentificationData.activeAssistId = this.passactvid;

    }

}