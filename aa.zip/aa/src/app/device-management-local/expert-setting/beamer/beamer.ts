import { Component, Input, ViewChild } from '@angular/core';
import { ModalDirective } from 'ng2-bootstrap/modal';
import { TranslateService } from '@ngx-translate/core';
import { ToastrService } from 'ngx-toastr';
import { DeviceManagementLocalService } from '../../device-management-local.service';
import { AuthenticationService } from '../../../authentication/authentication.service';

@Component({
    selector: "beamer",
    templateUrl: "./beamer.html",
    styleUrls: ["./beamer.css"],
    providers: [DeviceManagementLocalService]
})

export class BeamerComponent {
    @ViewChild('SaveBeamerModal') public SaveBeamerModal: ModalDirective;
    @Input() data: Object;
    constructor(private deviceManagementLocalService: DeviceManagementLocalService,
        private translate: TranslateService, private notificationService: ToastrService,
        private authService: AuthenticationService) {
            this.checkPermissions();
            this.expertSettingPermission = this.authService.appPermissions["Expert Settings"];

    }

    public beamerData: any = {};
    public expertSettingPermission : boolean = false;



    //to update an Beamer
    public updatebeamer(): void {
        let beamer = this.beamerData;
        beamer.enableRightBeamer = (beamer.enableRightBeamer) ? 1 : 0;
        beamer.enableLeftBeamer = (beamer.enableLeftBeamer) ? 1 : 0;
        let data = {
            "id":  (beamer.id) ? beamer.id : '',
            "activeAssistId": beamer.activeAssistId,
            "enableRightBeamer":  (beamer.enableRightBeamer) ? beamer.enableRightBeamer : '',
            "enableLeftBeamer": (beamer.enableLeftBeamer) ? beamer.enableLeftBeamer : '',
        }
        this.deviceManagementLocalService.saveBeamerData(data).then(res => {
            this.SaveBeamerModal.hide();
        });

    }

    public checkPermissions(): void {
        if (this.authService.appPermissions == undefined) {
            this.authService.logout();
        }
    }



    ngOnChanges() {
        console.log("data>>", this.data);
        if (this.data)
            this.beamerData = this.data;
    }

}