import { Component, Input, ViewChild } from '@angular/core';
import { ModalDirective } from 'ng2-bootstrap/modal';
import { TranslateService } from '@ngx-translate/core';
import { ToastrService } from 'ngx-toastr';
import { DeviceManagementLocalService } from '../../device-management-local.service';
import { AuthenticationService } from '../../../authentication/authentication.service';
@Component({
    selector: "hand-tracking",
    templateUrl: "./hand-tracking.html",
    styleUrls: ["./hand-tracking.css"],
    providers: [DeviceManagementLocalService]
})

export class HandTrackingComponent {
    @ViewChild('SaveHandTrackingModal') public SaveHandTrackingModal: ModalDirective;
    @Input() data: Object;
    constructor(private deviceManagementLocalService: DeviceManagementLocalService,
        private translate: TranslateService, private notificationService: ToastrService,
        private authService: AuthenticationService) {
        this.checkPermissions();
        this.expertSettingPermission = this.authService.appPermissions["Expert Settings"];
    }

    public handTrackingData: any = {};
    public expertSettingPermission: boolean = false;

    public checkPermissions(): void {
        if (this.authService.appPermissions == undefined) {
            this.authService.logout();
        }
    }




    //to update an handTracking
    public updatehandTracking(): void {
        let handTracking = this.handTrackingData;
        console.log("data handTracking>>", handTracking);
        let data = {
            "activeAssistId":  handTracking.activeAssistId,
            "id": (handTracking.id) ? handTracking.id : 0 ,
            "buttonActivationTimer": handTracking.buttonActivationTimer,
            "assembleActivationTimer": handTracking.assembleActivationTimer,
            "handOutsideCameraTimeoutInSeconds": handTracking.handOutsideCameraTimeoutInSeconds,
            "boxDetectionXOffset": handTracking.boxDetectionXOffset,
            "boxDetectionYOffset": handTracking.boxDetectionYOffset,
            "boxDetectionZOffset": handTracking.boxDetectionZOffset,
            "boxDetectionAngledOffset": handTracking.boxDetectionAngledOffset,
            "rowsToIgnoreTop": handTracking.rowsToIgnoreTop,
            "rowsToIgnoreBottom": handTracking.rowsToIgnoreBottom,
            "columnsToIgnoreLeft": handTracking.columnsToIgnoreLeft,
            "columnsToIgnoreRight": handTracking.columnsToIgnoreRight,
            "enableFastPicktoLightModules": (handTracking.enableFastPicktoLightModules) ? 1 : 0,
            "autoErrorConfirm": (handTracking.autoErrorConfirm) ? 1 : 0,
            "enableBackgroundLearningDuringAssembly": (handTracking.enableBackgroundLearningDuringAssembly) ? 1 : 0,
            "zTeachingDistanceOffsetFromRail": handTracking.zTeachingDistanceOffsetFromRail,
            "cameraBounceTimerRail": handTracking.cameraBounceTimerRail,
            "cameraBounceTimerVirtualButton": handTracking.cameraBounceTimerVirtualButton,
            "cameraDebounceMaxFrameCount": handTracking.cameraDebounceMaxFrameCount,
            "cameraMinRegionActivationDistance": handTracking.cameraMinRegionActivationDistance,
            "cameraHandMinBoundingSize": handTracking.cameraHandMinBoundingSize,
        }
        this.deviceManagementLocalService.saveHandTrackingData(data).then(res => {
            this.SaveHandTrackingModal.hide();
        });

    }


    ngOnChanges() {
        console.log("data>>", this.data);
        if (this.data)
            this.handTrackingData = this.data;
    }

}