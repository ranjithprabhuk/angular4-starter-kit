import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DeviceManagementLocalService } from './device-management-local.service';
import { DeviceManagementLocalComponent } from './device-management-local.component';


// Adding Expert-Setting components 
import { ProductIdentificationComponent } from './expert-setting/product-identification/product-identification';
import { CameraComponent } from './expert-setting/camera/camera';
import { BeamerComponent } from './expert-setting/beamer/beamer';
import { HandTrackingComponent } from './expert-setting/hand-tracking/hand-tracking';

// Adding Sensor Actor components 
import { SystemLightComponent } from './sensor-actor/system-light/system-light';
import { PushButtonComponent } from './sensor-actor/push-button/push-button';
import { ScrewDriverComponent } from './sensor-actor/screw-driver/screw-driver';
import { P2LComponent } from './sensor-actor/p2l/p2l';
import { P2LAddComponent } from './sensor-actor/p2l-add/p2l-add';

const DeviceManagementLocalRoutes: Routes = [
  {
    path: '',
    component: DeviceManagementLocalComponent,  
    data: {
      title: 'Device Management'
    }
  }
];


@NgModule({
  imports: [
    RouterModule.forChild(DeviceManagementLocalRoutes)
  ],
  exports: [
    RouterModule
  ],
  providers: [DeviceManagementLocalService]
})
export class DeviceManagementLocalRoutingModule { }



