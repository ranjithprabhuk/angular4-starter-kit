import { Component } from '@angular/core';
import { SensorActorConfig } from '../sensor-actor-config';

@Component({
    selector : "screw-driver",
    templateUrl: "./screw-driver.html",
    styleUrls : ["./screw-driver.css"]
})

export class ScrewDriverComponent {
    public SensorActorConfig = new SensorActorConfig();
    public settingsSensorActorScreDriver: any = this.SensorActorConfig.SensorActorScrewDriverSettings;
    public _sensorActorScrewDriverData=[
        {
          port: "Port 1",
          name:"ScrewDr1",
          test:"",
          result:"",
          
        },
            {
          port: "Port 2",
          name:"ScrewDr2",
          test:"",
          result:"",
          
        },
         {
          port: "Port 3",
          name:"ScrewDr3",
          test:"",
          result:"",
          
        },
         {
          port: "Port 4",
          name:"ScrewDr4",
          test:"",
          result:"",
          
        },
         
    ];

}