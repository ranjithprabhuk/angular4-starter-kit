export class SensorActorConfig {

    //pagination  settings
    public paginationSettings: Object = {
    display: true,
    perPage: 10
    };
    //table configuration forVirtualAreasSettings
    
    public SensorActorSystemLightSettings: Object = {
         hideSubHeader: true,
        actions: {
            columnTitle: 'Actions',
            add: false,
            edit: false,
            delete: false,
            copy: false,
            move: false,
            position: 'left', // left|right
        },
        columns: {
            color: {
                title: 'Color',
                filter: false,
                minWidth: "50px"
            },
            event: {
                title: 'Event',
                filter: false,
                minWidth: "50px"
            },
           
           
         
        },
        pager: this.paginationSettings
    };

    //table configuration pushbutton
    
    public SensorActorPushButtonSettings: Object = {
        actions: {
            columnTitle: 'Actions',
            add: false,
            edit: false,
            delete: false,
            copy: false,
            move: false,
            position: 'left', // left|right
        },
        columns: {
            port: {
                title: 'Port',
                filter: false,
                minWidth: "50px"
            },
            name: {
                title: 'Name',
                filter: false,
                minWidth: "50px"
            }, 
        },
        pager: this.paginationSettings
    };
    public SensorActorScrewDriverSettings: Object = {
        actions: {
            columnTitle: 'Actions',
            add: false,
            edit: true,
            delete: false,
            copy: false,
            move: false,
            position: 'left', // left|right
        },
        columns: {
            port: {
                title: 'Port',
                filter: false,
                minWidth: "100px",
                disabled: true
            },
            portname: {
                title: 'Name',
                filter: true,
                minWidth: "106px"
            },
            test: {
                title: 'Test',
                filter: false,
                minWidth: "50px",
                disabled: true,
                type:"button",
                buttonText : "Test",
                
            },
             result: {
                title: 'Result',
                filter: false,
                minWidth: "50px",
                disabled: true,
                type:"circle",
                buttonText:"",

            }
           
           
         
        },
        pager: this.paginationSettings
    };


    //table configuration Pick-To-Light

    public SensorActorP2LSettings: Object = {
        actions: {
            columnTitle: 'Actions',
            add: false,
            edit: true,
            delete: false,
            copy: false,
            move: false,
            position: 'left', // left|right
        },
        columns: {
            port: {
                title: 'Port',
                filter: false,
                minWidth: "100px",
                disabled: true
            },
            portname: {
                title: 'Pos Nr',
                filter: true,
                minWidth: "106px",
            },
            test: {
                title: 'Test',
                filter: false,
                minWidth: "50px",
                disabled: true,
                type:"button",
                buttonText : "Test",
            },
             resultout: {
                title: 'Result Out',
                filter: false,
                minWidth: "50px",
                disabled: true,
                type:"circle",
                buttonText:"",
            }
           
         
        },
         pager: this.paginationSettings
    };
        
    public SensorActorP2LAddSettings: Object = {
        actions: {
            columnTitle: 'Actions',
            add: false,
            edit: false,
            delete: false,
            copy: false,
            move: false,
            position: 'left', // left|right
        },
        columns: {
            port: {
                title: 'Port',
                filter: false,
                minWidth: "100px",
                disabled: true
            },
            portname: {
                title: 'Pos Nr',
                filter: false,
                minWidth: "106px",
            },
            test: {
                title: 'Test',
                filter: false,
                minWidth: "50px",
                disabled: true,
                type:"button",
                buttonText : "Test",
            },
             resultout: {
                title: 'Result Out',
                filter: false,
                minWidth: "50px",
                disabled: true,
                type:"circle",
                buttonText:"",
            }
        },
        pager: this.paginationSettings
    };
    
    
}