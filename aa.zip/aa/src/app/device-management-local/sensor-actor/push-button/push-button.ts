import { Component } from '@angular/core';
import { SensorActorConfig } from '../sensor-actor-config';

@Component({
    selector : "push-button",
    templateUrl: "./push-button.html",
    styleUrls : ["./push-button.css"]
})

export class PushButtonComponent {
     public SensorActorConfig = new SensorActorConfig();
    public settingsSensorActorPushButton: any = this.SensorActorConfig.SensorActorPushButtonSettings;
    public _sensorActorPushButton=[
        {
          port: "Port 1",
          name:"Confirm",
          
        },
           {
          port: "Port 2",
          name:"Forward",
        
        },
         
           {
          port: "Port 3",
          name:"Backward",
          
        },
         
    ];

}