
import { Component, ViewChild, Input } from '@angular/core';
import { Ng2SmartTableModule, LocalDataSource } from '../../../table';
import { ModalDirective } from 'ng2-bootstrap/modal';
import { TabsetComponent } from 'ng2-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { SensorActorConfig } from '../sensor-actor-config';

import { DeviceManagementLocalService } from '../../device-management-local.service';
import { DeviceManagementLocalComponent } from '../../device-management-local.component';
import { ToastrService } from 'ngx-toastr';




@Component({
    selector : "system-light",
    templateUrl: "./system-light.html",
    styleUrls : ["./system-light.css"],
     providers: [DeviceManagementLocalService]
})

export class SystemLightComponent {

     @ViewChild('SaveSystemLightModal') public SaveSystemLightModal: ModalDirective;

    constructor(private deviceManagementLocalService: DeviceManagementLocalService,private deviceManagementLocalComponent: DeviceManagementLocalComponent,
       private translate: TranslateService, private notificationService: ToastrService) {
    }

     public SensorActorConfig = new SensorActorConfig();
     public settingsSensorActor: any = this.SensorActorConfig.SensorActorSystemLightSettings;

     public SensorActorPushButtonSettings: any = this.SensorActorConfig.SensorActorPushButtonSettings;
     public SensorActorScrewDriverSettings: any = this.SensorActorConfig.SensorActorScrewDriverSettings;
      public SensorActorP2LSettings: any = this.SensorActorConfig.SensorActorP2LSettings;
      public SensorActorP2LAddSettings: any = this.SensorActorConfig.SensorActorP2LAddSettings;

     
     public _sensorActorSystemLightData=[
        {
          color: "red",
          event:"error",          
        },{
          color: "yello",
          event:"support needed",          
        },{
          color: "green",
          event:"ok",
        },         
    ];

    public _sensorActorPushButton=[
        {
          port: "Port1",
          name:"Confirm",          
        },{
          port: "Port2",
          name:"Forward",        
        },{
          port: "Port3",
          name:"Backward",          
        },
    ];
    public _sensorActorNewpickTolight = [
        {
            port: "Port1",
            portId: 0,
            portname: "0"
        },{
            port: "Port2",
            portId: 0,
            portname: "0"
        },{
            port: "Port3",
            portId: 0,
            portname: "0"
        },{
            port: "Port4",
            portId: 0,
            portname: "0"
        }
    ];
    
    public updateModules(): void {
        let flag_AA=false;
        let individualModules = this.moduleData;        
        let data = {
            "activeAssistId": this.passactvid,
            "id":  individualModules.id,
            "ip":  individualModules.ip,
            "isEnabled": individualModules.isEnabled,
            "moduleName":individualModules.moduleName,
            "moduleType":individualModules.moduleType,
            "sensorModulePort": [                
            ]
        }
                let checkIPFormat=new RegExp("^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$");
                let correctIP=checkIPFormat.test(data.ip);
                if(!correctIP)
                {
                    flag_AA=true;
                    this.notificationService.warning("Kindly give a valid IP address ");
                }
                else{
        this.deviceManagementLocalService.updateSensorModule(data).then(res => {            
            this.notificationService.success("Updated Successfully");
        }).catch(err => {             
            console.log("Error: ", err); });
    }
}
    public updateTableInfo(row: any): void{
        let selectedScredrivertData = row.newData;        
        let moduleInfo = this.moduleData;
         let data = {
            "activeAssistId": this.passactvid,
            "id":  moduleInfo.id,
            "ip":  moduleInfo.ip,
            "isEnabled": moduleInfo.isEnabled,
            "moduleName":moduleInfo.moduleName,
            "moduleType":moduleInfo.moduleType,
            "sensorModulePort": [
                {
                    "port": selectedScredrivertData.port,
                    "portId": selectedScredrivertData.portId,
                    "portname": selectedScredrivertData.portname
                }
            ]
        }        
        this.deviceManagementLocalService.updateSensorModule(data).then(res => {          
            row.confirm.resolve(data.sensorModulePort[0]);
            this.notificationService.success("Table info Updated Successfully");
        }).catch(err => { console.log("Error: ", err); });
    }

    public createNewPicktoLight(row: any): void {
        let selectedTableData = (row) ? row.newData  : null;
        let individualModules = this.moduleData;
        individualModules.isEnabled = (individualModules.isEnabled) ? 1 : 0 ;        
        let data =  (selectedTableData) ? {
            "activeAssistId": individualModules.activeAssistId,
            "id":  "",
            "ip":  individualModules.ip,
            "isEnabled": individualModules.isEnabled,
            "moduleName":individualModules.moduleName,
            "moduleType":"Pick-To-Light",
            "sensorModulePort": [
                {
                    "port": selectedTableData.port,
                    "portId": selectedTableData.portId,
                    "portname": selectedTableData.portname
                }
            ]
        }  : {
            "activeAssistId": individualModules.activeAssistId,
            "id":  "",
            "ip":  individualModules.ip,
            "isEnabled": individualModules.isEnabled,
            "moduleName":individualModules.moduleName,
            "moduleType": "Pick-To-Light",            
            "sensorModulePort" : this._sensorActorNewpickTolight
        };
        
        this.deviceManagementLocalService.createSensorModule(data).then(res => {                        
            this.moduleData.id = res.id;
            this.moduleData.tableData = res.sensorModulePort;
            this.notificationService.success("Module Created Successfully");
        }).catch(err => {console.log("Error: ", err); });
    }

    public backToDefaultPage(id): void{
        this.deviceManagementLocalComponent.getSensorActorData(id);
    }

    public findType(val){
        return this.deviceManagementLocalComponent.findType(val);
    }

    @Input() data: Object;   
    @Input() passactvid: any;

    public moduleData: any = {};
    public updatesensorModule(): void {
        let sensorModule = this.moduleData;        
        let data = {
            "activeAssistId": sensorModule.activeAssistId,
            "ip": sensorModule.ip,
            "id":  sensorModule.id,
            "moduleName": sensorModule.moduleName,
            "moduleType": sensorModule.moduleType,
            "isEnabled":  sensorModule.isEnabled=0,
        }
        this.deviceManagementLocalService.createSensorModule(data).then(res => {
            // this.SaveProductIdentificationModal.hide();
        });
    }

  
    ngOnChanges() {        
        if (this.data)
            this.moduleData = this.data;
    }
    

}