import { Component } from '@angular/core';
import { SensorActorConfig } from '../sensor-actor-config';

@Component({
    selector : "p2l-add",
    templateUrl: "./p2l-add.html",
    styleUrls : ["./p2l-add.css"]
})

export class P2LAddComponent {
     public SensorActorConfig = new SensorActorConfig();
     public settingsSensorActorP2LAdd: any = this.SensorActorConfig.SensorActorP2LAddSettings;
     public _sensorActorP2LAddData=[
        {
          port: "Port 1",
          posnr:"10",
          test:"Test",
          resultout:"",
          
        },
           {
        port: "Port 1",
          posnr:"11",
          test:"Test",
          resultout:"",
        
        },
         
           {
          port: "Port 1",
          posnr:"12",
          test:"Test",
          resultout:"",
          
        },
          {
          port: "Port 1",
          posnr:"13",
          test:"Test",
          resultout:"",
          
        },
         
    ];
    // Active Assist Tab Buttons
  public onButtonClick(event): void {
    let columnTitle = event.getColumn().title;
    switch (columnTitle) {
      case "Test":
      alert("testing...")
      //  this.RestoreModal.show();
        break;
        
    }
  };
}