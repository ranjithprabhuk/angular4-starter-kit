import { Injectable,OnInit } from '@angular/core';
import { Headers, Http, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Observable';

import { ToastrService } from 'ngx-toastr';

import { LoaderService } from '../shared/loader';
import 'rxjs/add/operator/toPromise';
import { environment } from '../../environments/environment';
import { WorkerBaseService } from './worker-base.service';

@Injectable()

export class UserProfileService extends WorkerBaseService implements OnInit {   
    protected hostName: string = 'userManagementService';
   
    constructor(protected http: Http, public loader: LoaderService, public notification: ToastrService) { 
      super(http,loader,notification);
      console.log("WorkerBaseService");    
    }

    ngOnInit() {
    }

    getHostName(): string {
        return this.hostName;
    }   
}
