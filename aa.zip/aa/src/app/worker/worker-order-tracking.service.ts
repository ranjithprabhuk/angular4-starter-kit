import { Injectable,OnInit } from '@angular/core';
import { URLSearchParams } from '@angular/http';
import { ApiService } from '../app.service';
import { WorkerBaseService } from './worker-base.service';

import 'rxjs/add/operator/toPromise';


@Injectable()
export class WorkerOrderTrackingService {
    protected apiEndPoint: string =   "OrderTrackingService.svc/";
    
    constructor(protected apiService: WorkerBaseService) {         
       // super(apiService);
         console.log("WorkerOrderTrackingService");
    }   
   

    //to get the product type table data
    getProductTypes(): Promise<any> {          
        return this.apiService.doGet(this.apiEndPoint+"GetProductTypes")
            .then(res => { return Promise.resolve(res)})
            .catch(err => { return Promise.reject(err)});
    }    

    //to get all assigned production order data
    getAssignedProductionOrders(): Promise<any> {  
        return this.apiService.doGet(this.apiEndPoint+"GetassignedOrders" )
            .then(res => { return Promise.resolve(res)})
            .catch(err => { return Promise.reject(err)});
    }  
        
    //to get all unassigned production order data
    getUnAssignedProductionOrders(): Promise<any> {  
        return this.apiService.doGet(this.apiEndPoint+"GetUnassignedOrders" )
            .then(res => { return Promise.resolve(res)})
            .catch(err => { return Promise.reject(err)});
    }  

    getIsProductionPossible(productTypeNumber: string): Promise<any> {  
        return this.apiService.doGet(this.apiEndPoint+"GetIsProductionPossible/" + productTypeNumber)
            .then(res => { return Promise.resolve(res)})
            .catch(err => { return Promise.reject(err)});
    } 
}
