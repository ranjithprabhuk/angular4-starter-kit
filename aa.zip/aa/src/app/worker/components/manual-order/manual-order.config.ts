import { TranslateService,TranslationChangeEvent } from '@ngx-translate/core';
export class ManualOrderConfig {

    constructor(private translate:TranslateService) {

    }

    //pagination  settings
    public paginationSettings: Object = {
        display: false,
        perPage: 10
    };

    //table configuration for manual order
    public manualOrderSettings: Object = {
        actions: {
            columnTitle: '',
            add: false,
            edit: false,
            delete: false,
            copy: false,
            move: false,
            position: 'left', // left|right
        },
        columns: {
            productTypeNumber: {
                title: this.translate.instant("WORKER_MANUAL_ORDER.PRODUCT_TYPE_NUMBER"), 
                filter: true
            },
            productTypeName: {
                title: this.translate.instant("WORKER_MANUAL_ORDER.PRODUCT_TYPE_NAME"), 
                filter: true
            },
            description: {
                title: this.translate.instant("WORKER_MANUAL_ORDER.PRODUCT_TYPE_DESCRIPTION"), 
                filter: true
            },
        },
        pager: this.paginationSettings,
        serverSidePagination: {
            itemsPerPage: 10,
            page: 1,
            totalItems: 0
        }
    }

    public updateSettings() {  
        this.manualOrderSettings = {
            actions: {
                columnTitle: '',
                add: false,
                edit: false,
                delete: false,
                copy: false,
                move: false,
                position: 'left', // left|right
            },
            columns: {
                productTypeNumber: {
                    title: this.translate.instant("WORKER_MANUAL_ORDER.PRODUCT_TYPE_NUMBER"), 
                    filter: true
                },
                productTypeName: {
                    title: this.translate.instant("WORKER_MANUAL_ORDER.PRODUCT_TYPE_NAME"), 
                    filter: true
                },
                description: {
                    title: this.translate.instant("WORKER_MANUAL_ORDER.PRODUCT_TYPE_DESCRIPTION"), 
                    filter: true
                },
            },
            pager: this.paginationSettings,
            serverSidePagination: {
                itemsPerPage: 10,
                page: 1,
                totalItems: 0
            }
        }
    }
}