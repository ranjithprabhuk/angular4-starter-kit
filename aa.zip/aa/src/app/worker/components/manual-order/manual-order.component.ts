import { Component , OnInit} from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ManualOrderConfig } from './manual-order.config';
import { WorkerOrderTrackingService } from '../../worker-order-tracking.service';
import { WorkerAssemblyService } from '../../worker-assembly.service';
import { Ng2SmartTableModule, LocalDataSource } from '../../../table';
import { LoaderService } from '../../../shared/loader';
import { ToastrService } from 'ngx-toastr';
import { TranslateService,TranslationChangeEvent } from '@ngx-translate/core';

@Component({
    templateUrl: "./manual-order.html",
    styleUrls: ["./manual-order.css"],
    providers: [WorkerAssemblyService,WorkerOrderTrackingService]
})

export class ManualOrderComponent implements OnInit {

    constructor(private workerService: WorkerAssemblyService, 
                private manualOrderService: WorkerOrderTrackingService,
                private loader: LoaderService, 
                private notification: ToastrService,
                private router: Router,
                private translate:TranslateService) {
        this.manualOrderData = new LocalDataSource ();        
    }
    
    ngOnInit() {        
       this.translate.onLangChange.subscribe((event: TranslationChangeEvent) => {
            this.doTranslate();
       });
       this.getOrders();
    }
    

    public manualOrderData: LocalDataSource;   
    
    public manualOrderConfig: ManualOrderConfig = new ManualOrderConfig(this.translate);
    public firstQuantityColumn: number = 0;
    public secondQuantityColumn: number = 0;
    public thirdQuantityColumn: number = 0;    

    private quantityNumber: number = 0;
    private selectedManualOrder : any;
    private isProductionPossible : string ;

    doTranslate() {   
        this.manualOrderConfig.updateSettings();
        this.manualOrderData.refresh();     
    }

    //get the table data for product types
    public getOrders(): void {
        //call the manual order service to get the data
        this.manualOrderService.getProductTypes().then(res => {           
            console.log("response",res);          
            
            this.manualOrderData.load(res.content);            

            if (res.content.length > 0) {
                this.selectedManualOrder = res.content[0];
            }
            //this.manualOrderData.reset(true);
        }).catch(
            err => { 
                console.log("Error: ", err); 
            }
        );            
    };

    public selectManualOrder(event: any): void {
        if (event.isSelected) {
            console.log("data>>", event);
            this.selectedManualOrder = event.data;  
        } else {
            this.selectedManualOrder = null;
        }
        
    };

    //increase the quantity
    public increaseQuantity(value: number): number {
        if (value === 9) return 0;
        else {} return ++value;
    };

    //decrease the quantity
    public decreaseQuantity(value: number): number {
        if (value === 0) return 9;
        else return --value;
    };

    public calculateQuantity () {
        let quantityString: string = this.firstQuantityColumn.toString() + this.secondQuantityColumn.toString() + this.thirdQuantityColumn.toString();    
        this.quantityNumber = Number.parseInt(quantityString);
        console.log ("quantity " , this.quantityNumber);
    }

    public startAssemblyPlan () {
        console.log("selected order: ", this.selectedManualOrder);
        this.calculateQuantity();
        if (this.quantityNumber <= 0) {
            this.showError("Quantity must be greater than 0");
            return;
        }

        if (this.selectedManualOrder != null) {          
            this.manualOrderService.getIsProductionPossible(this.selectedManualOrder.productTypeNumber).then(res=> {
                    console.log("response", res);
                    this.isProductionPossible = res;
                    let param = {
                        "productTypeNumber" : this.selectedManualOrder.productTypeNumber,
                        "quantity" : this.quantityNumber,
                        "isManual" : 1
                    };
                    
                    console.log ("param " , param);
                     if ( this.isProductionPossible == "YES") {
                        // if ok, then call start assembly process
                        this.workerService.startAssemblyProcess(param).then (res => {
                            let stepAmt = res.size;
                            // navigate to assemply instruction
                            this.router.navigate(['/worker/assembly-assist/' + stepAmt + '/' + this.quantityNumber]);
                        }).catch(err => {
                            console.log("Error: ", err); 
                        });
                     }
                    
                }
            ).catch(err => {
                console.log("Error: ", err); 
            });
        }       
    }

    public cancel() {
        this.router.navigate(['/worker/order-type-selection']);
    }

     //for error handling
    public showError(error: any): void {
        console.error('An error occurred', error);
        this.notification.error(error);        
        this.loader.loader.emit(false);        
    }
}