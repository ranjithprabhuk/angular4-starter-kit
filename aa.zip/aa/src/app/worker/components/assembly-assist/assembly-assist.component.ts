import { Component, ViewChild, OnInit } from '@angular/core';
import { ModalDirective } from 'ng2-bootstrap';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { WorkerAssemblyService } from '../../worker-assembly.service';
import { LoaderService } from '../../../shared/loader';
import { ToastrService } from 'ngx-toastr';
import { StompConfig } from '@stomp/ng2-stompjs';
import { stompConfig } from '../../worker.config';
import { Message } from '@stomp/stompjs';
import { Subscription } from 'rxjs/Subscription';
import { Observable } from 'rxjs/Observable';
import { WorkerStompService } from '../../worker-stomp.service';
import { WorkerAuthenticationService } from '../../worker-authentication.service';
import { environment } from '../../../../environments/environment';
import { AuthenticationService } from '../../../authentication/authentication.service';

@Component({
    templateUrl: "./assembly-assist.html",
    styleUrls: ["./assembly-assist.css"],
    providers: [WorkerAssemblyService, WorkerAuthenticationService
    ]
})

export class AssemblyAssistComponent implements OnInit {
    cancelForm: FormGroup;
    stopAssemblyForm: FormGroup;
    skipForm: FormGroup;
    forwarOnOFForm: FormGroup;
    manualModeForm: FormGroup;
    private _stompService: WorkerStompService;

    constructor(private assemblyService: WorkerAssemblyService,
        private authService: WorkerAuthenticationService,
        private router: Router,
        private route: ActivatedRoute,
        private loader: LoaderService,
        private notification: ToastrService,
        private formBuilder: FormBuilder,
        private authenticationService: AuthenticationService
    ) {
        this.shutDownPermission = this.authenticationService.appPermissions["Program restart and System reboot"];
        this.fwBwEnable = this.authenticationService.appPermissions["Jump between worksteps"];
        this.skipProcessEnable = this.authenticationService.appPermissions["Jump between worksteps"];
        this.pauseOrdersPermission = this.authenticationService.appPermissions["Pause Orders"];

        window.onresize = (e) => {
            //this.mediaContainerheight = this.getMediaContainerHeight();
        };
        //this.contextRoot  = this.assemblyService.getContextRoot();    

        // Load port and host from application properties here
        this.assemblyService.getApplicationProperties().then(res => {
            console.log("response", res);
            this.contextRoot = res.activeAssistServiceHost + res.activeAssistServicePort + "/" + this.assemblyService.getApiEndpoint();
        }).catch(err => { console.log("Error: ", err); });
    };

    @ViewChild('skipProcessStepModal') public skipProcessStepModal: ModalDirective;
    @ViewChild('cancelAssemblyModal') public cancelAssemblyModal: ModalDirective;
    @ViewChild('stopAssemblyModal') public stopAssemblyModal: ModalDirective;
    @ViewChild('forwardBackWardFunctionModal') public forwardBackWardFunctionModal: ModalDirective;
    @ViewChild('manualConfirmModeModal') public manualConfirmModeModal: ModalDirective;
    @ViewChild('confirmShutdownModal') public confirmShutdownModal: ModalDirective;

    public mediaContainerheight: number = 0;
    private fwBwEnable: boolean = false;
    private skipProcessEnable: boolean = false;
    private confirmEnable: boolean = true;
    private manualModeEnable: boolean = false;
    private shutdownClicked: boolean = false;
    private stepAmount: number = 1;
    private currentStep: number = 1;
    private lastStep: number = 1;
    private isManual: number = 0;
    private quantity: number = 0;
    private completedQuantity: number = 1;
    private allSteps: Array<StepBox> = [];
    private stepStyle: string = 'btn';
    private medias: Array<any> = [];
    private isLoading: boolean = true;
    private contextRoot: string;
    private activeAssistId: string = 'AA-Santhosh2';
    private userId: number = 1;
    private fontSize: number = 12;

    // Stream of messages
    private subscription: Subscription;
    public messages: Observable<Message>;

    // Subscription status
    public subscribed: boolean;

    // used for step pagination 
    private stepSize: number = 10;
    previousEnabled: boolean = false;
    nextEnabled: boolean = false;
    processFinished: boolean = false;
    totalSteps: number;

    private stepHeader: StepHeader = new StepHeader();

    private stepInfo: any = { 'mediaIdInfo': {} };

    // permissions 
    public shutDownPermission: boolean = false;
    public pauseOrdersPermission: boolean = false;
    public jumpBetweenStepsPermission: boolean = false;

    //set the height of the media containers
    getMediaContainerHeight(): number {
        let documentHeight = window.innerHeight;
        let notesHeight = document.getElementById("notes").offsetHeight;
        let instructionsHeight = document.getElementById("instructions").offsetHeight;
        let footerButtonsHeight = document.getElementById("footer-buttons").offsetHeight;

        return documentHeight - notesHeight - instructionsHeight - footerButtonsHeight - 315;
    };

    ngOnInit() {
        this.mediaContainerheight = this.getMediaContainerHeight();
        this.buildForm();
        this.getRequestParameters();
        this.initStep(this.currentStep);
        this.connectToStomp();
        this.getUserPreference();
    }

    onResize() {
        this.mediaContainerheight = this.getMediaContainerHeight();
    }

    ngOnDestroy() {
        this.unsubscribe();
        this._stompService.disconnect();
    }

    getRequestParameters() {
        this.route.params.subscribe((params: Params) => {
            this.stepAmount = +params['steps'];
            this.quantity = +params['quantity'];
        });

        this.route.queryParams.subscribe(params => {
            this.currentStep = +params['currentStep'] || 1;
            this.completedQuantity = +params['completedQty'] || 1;
            this.fwBwEnable = (params['fwBwEnable'] || "false") == "true";
            this.skipProcessEnable = (params['skipProcessEnable'] || "false") == "true";
            this.manualModeEnable = (params['manualModeEnable'] || "false") == "true";
            this.activeAssistId = String(+params['activeAssistId'] || 'AA-Santhosh2');
        });
    }

    updateQueryParam() {
        this.router.navigate([],
            {
                queryParams:
                {
                    currentStep: this.currentStep,
                    completedQty: this.completedQuantity,
                    fwBwEnable: this.fwBwEnable,
                    skipProcessEnable: this.skipProcessEnable,
                    manualModeEnable: this.manualModeEnable,
                    activeAssistId: this.activeAssistId
                }
            });
    }

    buildForm() {
        this.cancelForm = this.stopAssemblyForm = this.formBuilder.group({
            saveOrder: ['', []],
            comment: ['', []]
        });

        this.skipForm = this.forwarOnOFForm = this.manualModeForm = this.formBuilder.group({
            activeAssistId: ['', [Validators.required]],
            supervisorId: ['', [Validators.required]],
            superPassword: ['', [Validators.required]]
        });
    }

    bindData(res: any) {
        this.isLoading = false;
        if (res != null && res.content != null) {
            this.stepInfo = res.content[0];
            this.medias = [];
            if (this.stepInfo.mediaIdLeft != null && this.stepInfo.mediaIdLeft.mediaLink != null) {
                let mediaLink: string = this.stepInfo.mediaIdLeft.mediaLink;
                this.stepInfo.mediaIdLeft.mediaLink = mediaLink.replace(/\\/g, "/");
                this.medias.push(this.stepInfo.mediaIdLeft);
            }
            if (this.stepInfo.mediaIdRight != null && this.stepInfo.mediaIdRight.mediaLink != null) {
                let mediaLink: string = this.stepInfo.mediaIdRight.mediaLink;
                this.stepInfo.mediaIdRight.mediaLink = mediaLink.replace(/\\/g, "/");
                this.medias.push(this.stepInfo.mediaIdRight);
            }
            let mediaLink: string = this.stepInfo.mediaIdInfo.mediaLink;
            this.stepInfo.mediaIdInfo.mediaLink = mediaLink.replace(/\\/g, "/");
            this.stepHeader.productId = res.productId;
            this.stepHeader.productTypeNumber = res.productTypeNumber;
            this.stepHeader.productionOrderNumber = res.productionOrderNumber;
            this.stepHeader.amount = this.currentStep + "/" + this.quantity;
            this.manualModeEnable = this.stepInfo.IsConfimationEnable;
        }
    }

    getUserPreference() {
        this.authService.getUserProfile(this.userId).then(res => {
            let userDetail = res;
            let user = userDetail.userPreference.user;
            this.fontSize = userDetail.userPreference.fontsize;
        }).catch(err => { this.handleError(err); });
    }

    connectToStomp() {
        // Load port and host from application properties here
        this.assemblyService.getApplicationProperties().then(res => {
            console.log("response", res);
            stompConfig.url = res.stompServerUrl;
            console.log("stompConfig", stompConfig);
            this._stompService = new WorkerStompService(stompConfig);
            this.subscribed = false;
            this.subscribe();
        }).catch(err => { console.log("Error: ", err); });
    }

    resetSteps() {
        this.currentStep = 1;
        this.lastStep = 1;
        this.allSteps = [];
        this.updateStep();
        this.changeStep(1);
    }

    startNewOrder() {
        let order = this.assemblyService.getCachedOrder();
        if (order != null) {
            order.quantityCompleted = this.completedQuantity;
            order.stepInProgress = "0";
            order.productId = 0;
            this.assemblyService.startAssemblyProcess(order).then(res => {
                this.stepAmount = res.size;
                this.resetSteps();
                this.bindData(res);
                this.completedQuantity++;
            }).catch(err => {
                console.log("Error: ", err);
            });
        }
    }

    initStep(step: number) {
        this.assemblyService.goToStep(step).then(res => {
            this.bindData(res);
            this.updateStep();
            this.changeStep(1);
            this.currentStep = step;
            this.lastStep = step;
            this.changeState();
        }).catch(err => { this.handleError(err); });
    }

    changeState() {
        if (this.skipProcessEnable) {
            this.stepStyle = 'btn-clickable';
            this.fwBwEnable = true;
        }
        this.confirmEnable = this.fwBwEnable == false;
        this.previousEnabled = this.currentStep > 1 && this.fwBwEnable;
        this.nextEnabled = this.currentStep < this.lastStep && this.fwBwEnable;
    }

    showStep(stepNumber) {
        if (this.skipProcessEnable) {
            this.assemblyService.goToStep(stepNumber).then(res => {
                this.bindData(res);
                this.changeStep(stepNumber);
                this.lastStep = this.currentStep;
                this.updateQueryParam();
            }).catch(err => { this.handleError(err); });
        }
    }

    cancelAssemblyProcess({ value, valid }: { value: any, valid: boolean }) {
        console.log("cancelForm ", value);
        let param = { "Comments": value.comment, "OrderNo": this.stepHeader.productionOrderNumber };
        if (this.shutdownClicked) {
            this.cancelAssemblyModal.hide();
            this.confirmShutdownModal.show();
        } else {
            this.assemblyService.cancelAssemblyProcess(param).then(res => {
                this.cancelAssemblyModal.hide();

                // navigate to manual order/production order
                this.router.navigate(['/worker/order-type-selection']);
            }).catch(err => { this.handleError(err); });
        }
    }

    stopAssemblyProcess({ value, valid }: { value: any, valid: boolean }) {
        let param = { "Comments": value.comment, "OrderNo": this.stepHeader.productionOrderNumber };
        this.assemblyService.stopAssemblyProcess(param).then(res => {
            this.stopAssemblyModal.hide();

            // navigate to manual order/production order
            this.router.navigate(['/worker/order-type-selection']);
        }).catch(err => { this.handleError(err); });

    }

    doShutdown() {
        // Call C# API to shut down system.
        console.log("shutting down");
        this.assemblyService.shutDown().then(res => {
            this.confirmShutdownModal.hide();
        }).catch(err => {
            this.showError("There was error while shutting down the system");
            this.handleError(err);
        });
    }

    stepForward() {
        if (this.fwBwEnable && this.nextEnabled) {
            this.assemblyService.getNextStep().then(res => {
                this.bindData(res);
                this.previousNext(1);
            }).catch(err => { this.handleError(err); });
        } else {
            this.showError('FW/BW function is off');
        }
    }

    stepBack() {
        if (this.fwBwEnable && this.previousEnabled) {
            this.assemblyService.getPreviousStep().then(res => {
                this.bindData(res);
                this.previousNext(-1);
            }).catch(err => { this.handleError(err); });
        } else {
            this.showError('FW/BW function is off');
        }
    }

    confirmStep() {
        if (this.confirmEnable) {
            let param = {};
            this.assemblyService.confirmStep().then(res => {
                this.bindData(res);
                if (res == null && this.completedQuantity == this.quantity) {
                    // process completed   
                    localStorage.removeItem('cachedOrder');
                    this.router.navigate(['/worker/order-type-selection']);
                } else {
                    this.lastStep = this.currentStep + 1;
                    this.previousNext(1);
                    this.updateQueryParam();
                }
            }).catch(err => { this.handleError(err); });
        }
    }

    enableSkipProcess({ value, valid }: { value: any, valid: boolean }) {
        if (!this.processFinished) {
            console.log("sumbit data", value);
            let param = { username: value.supervisorId, password: value.superPassword };
            this.authService.authenticateUser(param).then(res => {
                this.skipProcessEnable = true;
                this.stepStyle = 'btn-clickable';
                this.fwBwEnable = true;
                this.previousEnabled = this.currentStep > 1 && this.fwBwEnable;
                this.nextEnabled = this.currentStep < this.lastStep && this.fwBwEnable;
                this.confirmEnable = false;
                this.updateQueryParam();
            })
                .catch(err => {
                    // Login failed then call C# API to login with default password
                    this.showError('Invalid user id or password');
                })
        } else {
            this.showError('Process completed! Could not enable Skip Process');
        }

        this.skipProcessStepModal.hide();
    }

    enableForwarBackward({ value, valid }: { value: any, valid: boolean }) {
        console.log("sumbit data", value);
        let param = { username: value.supervisorId, password: value.superPassword };
        this.authService.authenticateUser(param).then(res => {
            this.fwBwEnable = !this.fwBwEnable;
            this.confirmEnable = this.fwBwEnable == false;
            this.previousEnabled = this.currentStep > 1 && this.fwBwEnable;
            this.nextEnabled = this.currentStep < this.lastStep && this.fwBwEnable;
            this.updateQueryParam();
            this.forwardBackWardFunctionModal.hide();
        })
            .catch(err => {
                // Login failed then call C# API to login with default password
                this.showError('Invalid user id or password');
            })
    }

    enableManualMode({ value, valid }: { value: any, valid: boolean }) {
        console.log("sumbit data", value);
        let param = { username: value.supervisorId, password: value.superPassword };
        this.authService.authenticateUser(param).then(res => {
            this.manualModeEnable = true;
            this.confirmEnable = true;
            this.updateQueryParam();
            this.assemblyService.setConfirmation().then(res => {
                this.manualConfirmModeModal.hide();
            }).catch(err => { this.handleError(err); });
        })
            .catch(err => {
                // Login failed then call C# API to login with default password
                this.showError('Invalid user id or password');
            })
    }

    disableSkipProcess() {
        this.skipProcessEnable = false;
        this.stepStyle = 'btn';
        this.confirmEnable = this.fwBwEnable == false;
        this.updateQueryParam();
    }

    disableManualMode() {
        this.assemblyService.setConfirmation().then(res => {
            this.manualModeEnable = false;
            this.updateQueryParam();
        }).catch(err => { this.handleError(err); });
    }

    updateStep() {
        console.log("current step ", this.currentStep);
        if (this.stepAmount && this.stepSize) {
            this.totalSteps = this.stepSize < this.stepAmount ? this.stepSize : this.stepAmount;
            //if (this.stepAmount >= this.stepSize) {
            for (let i = 1; i < this.totalSteps + 1; i++) {
                let stepId: number = i;
                let stepData = new StepBox(stepId, "Step " + i, 'btn-default');
                if (i == 1) {
                    stepData = new StepBox(stepId, "Step " + i, 'btn-primary');
                }
                this.allSteps.push(stepData);
            }
            //  }
            return;
        }
    }

    previousNext(direction: number) {
        console.log("current step ", this.currentStep);
        let step: number = this.currentStep;
        if (direction == -1) {
            if (step > 1) {
                let stepFirst = this.allSteps[0];
                if (step <= stepFirst.id) {
                    this.allSteps.pop();
                    let stepData = new StepBox(step - 1, "Step " + (step - 1), 'btn-default');
                    this.allSteps.unshift(stepData);
                }
                step--;
            }
        } else {
            if (step < this.stepAmount) {
                let rightMargin: number = this.totalSteps - 1;
                let stepLast = this.allSteps[rightMargin];
                if (step >= stepLast.id) {
                    this.allSteps.shift();
                    let stepData = new StepBox(step + 1, "Step " + (step + 1), 'btn-default');
                    this.allSteps.push(stepData);
                }
                step++;
            } else if (this.completedQuantity < this.quantity) {
                //this.completedQuantity++;
                this.startNewOrder();
            } else {
                this.processFinished = true;
            }
        }
        this.changeStep(step);
    }

    changeStep(step: number) {
        if (this.currentStep === step) return;
        this.currentStep = step;
        this.previousEnabled = this.currentStep > 1 && this.fwBwEnable;
        this.nextEnabled = this.currentStep < this.lastStep && this.fwBwEnable;
    }

    public subscribe() {
        console.log("calling subscribe");
        if (this.subscribed) {
            return;
        }

        // Stream of messages
        this.messages = this._stompService.subscribe('/Stomp/NextStep');

        // Subscribe a function to be run on_next message
        this.subscription = this.messages.subscribe(this.on_next);

        this.subscribed = true;
    }

    public unsubscribe() {
        console.log("calling unsubscribe");
        if (!this.subscribed) {
            return;
        }

        // This will internally unsubscribe from Stomp Broker
        // There are two subscriptions - one created explicitly, the other created in the template by use of 'async'
        this.subscription.unsubscribe();
        this.subscription = null;
        this.messages = null;
        this.subscribed = false;
    }

    /** Consume a message from the _stompService */
    public on_next = (message: Message) => {
        // Log it to the console
        console.log("Received message from server: ", message);
        let moduleName = message.body;
        //this.confirmStep();
        this.assemblyService.getDataByModuleName(moduleName).then(res => {
            this.bindData(res);
            this.lastStep = this.currentStep;
            this.previousNext(1);
        }).catch(err => {
            console.log("Error: ", err);
        });
    }

    public handleError(error: any) {
        this.isLoading = false;
        this.cancelAssemblyModal.hide();
        console.log("Error: ", error);
    }

    //for error handling
    public showError(error: any): void {
        console.error('An error occurred', error);
        this.notification.error(error);
        this.loader.loader.emit(false);
    }

    public showInfo(info: any): void {
        this.notification.info(info);
        this.loader.loader.emit(false);
    }

    public checkPermissions(): void {
        if (this.authenticationService.appPermissions == undefined) {
            this.authenticationService.logout();
        }
    }

    public checkShutdown(permission: boolean): void {
        if (permission) {
            this.shutdownClicked = true;
            this.cancelAssemblyModal.show();
        }
    }

    public skipSteps(permission: boolean): void {
        if (permission) {
            this.skipProcessStepModal.show();
        }
    };

    public cancelAssembly(permission: boolean): void {
        if (permission) {
            this.cancelAssemblyModal.show();
        }
    }

    public stopAssembly(permission: boolean): void {
        if (permission) {
            this.stopAssemblyModal.show();
        }
    }
}

export class StepBox {
    public style: string;
    public name: string;
    public id: number;

    constructor(id: number, name: string, style: string) {
        this.style = style;
        this.name = name;
        this.id = id;
    }
}

export class StepHeader {
    public productionOrderNumber: string;
    public productTypeNumber: string;
    public productId: number;
    public amount: string;

    /*
    constructor ( productionOrderNumber :string, productId: number, amount :string) {
        this.productionOrderNumber = productionOrderNumber;
        this.amount = amount;
        this.productId =productId;
    }*/
}