import { Component, OnInit, OnDestroy } from '@angular/core';
import { StompConfig } from '@stomp/ng2-stompjs';
import { Message } from '@stomp/stompjs';
import { Subscription } from 'rxjs/Subscription';
import { Observable } from 'rxjs/Observable';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { WorkerAssemblyService } from '../../worker-assembly.service';
import { WorkerStompService } from '../../worker-stomp.service';
import { stompConfig } from '../../worker.config';
import { environment } from '../../../../environments/environment';
import { AuthenticationService } from '../../../authentication/authentication.service';

@Component({
  templateUrl: "./order-type-selection.html",
  styleUrls: ["./order-type-selection.css"],
  providers: [
    WorkerAssemblyService
  ]
})


export class OrderTypeSelectionComponent implements OnInit, OnDestroy {
  private _stompService: WorkerStompService;

  // Stream of messages
  private subscription: Subscription;
  public messages: Observable<Message>;
  public productionOrderPermission: boolean = false;
  public manualOrderPermission: boolean = false;

  // Subscription status
  public subscribed: boolean;

  /** Constructor */
  constructor(private assemblyService: WorkerAssemblyService, private authService: AuthenticationService,
    private router: Router) {
    this.checkPermissions();
  }

  ngOnInit() {
    // Load port and host from application properties here   
    this.assemblyService.getApplicationProperties().then(res => {
      console.log("response", res);
      stompConfig.url = res.stompServerUrl;
      console.log("stompConfig", stompConfig);
      this._stompService = new WorkerStompService(stompConfig);
      this.subscribed = false;
      this.subscribe();
    }).catch(err => { console.log("Error: ", err); });
  }

  public subscribe() {
    if (this.subscribed) {
      return;
    }

    // Stream of messages
    this.messages = this._stompService.subscribe('/Stomp/RFIDScanner');

    // Subscribe a function to be run on_next message
    this.subscription = this.messages.subscribe(this.on_next);

    this.subscribed = true;
  }

  public unsubscribe() {
    console.log("calling unsubscribe");
    if (!this.subscribed) {
      return;
    }

    // This will internally unsubscribe from Stomp Broker
    // There are two subscriptions - one created explicitly, the other created in the template by use of 'async'
    this.subscription.unsubscribe();
    this.subscription = null;
    this.messages = null;

    this.subscribed = false;
  }

  ngOnDestroy() {
    this.unsubscribe();
    this._stompService.disconnect();
  }

  /** Consume a message from the _stompService */
  public on_next = (message: Message) => {
    // Log it to the console
    console.log("Received message from server: ", message);
    let moduleName = message.body;
    this.startAssemblyPlan(moduleName);
  }

  public startAssemblyPlan(moduleName) {
    this.assemblyService.getDataByModuleName(moduleName).then(res => {
      let stepAmt = res.size;

      // navigate to assemply instruction
      this.router.navigate(['/worker/assembly-assist/' + stepAmt + '/1']);
    }).catch(err => {
      console.log("Error: ", err);
    });
  }

  //navigate to production order page
  public navigateToProductionOrder(): void {
    if (this.productionOrderPermission) {
      this.router.navigate(['/worker/production-order']);
    }
  }

  //navigate to manual order page
  public navigateToManualOrder(): void {
    if (this.manualOrderPermission) {
      this.router.navigate(['/worker/manual-order']);
    }
  }


  //check for the permissions
  public checkPermissions(): void {
    if (this.authService.appPermissions != undefined) {
      this.productionOrderPermission = this.authService.appPermissions["Order Production"];
      this.manualOrderPermission = this.authService.appPermissions["Manual Production"];
    } else {
      this.authService.logout();
    }
  }
}