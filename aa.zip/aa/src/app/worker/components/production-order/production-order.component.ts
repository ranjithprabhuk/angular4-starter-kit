import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ProductionOrderConfig } from './production-order.config';
import { WorkerOrderTrackingService } from '../../worker-order-tracking.service';
import { WorkerAssemblyService } from '../../worker-assembly.service';

import { TranslateService,TranslationChangeEvent } from '@ngx-translate/core';
import { Ng2SmartTableModule, LocalDataSource } from '../../../table';
import { LoaderService } from '../../../shared/loader';
import { ToastrService } from 'ngx-toastr';

@Component({
    templateUrl: "./production-order.html",
    styleUrls: ["./production-order.css"],
    providers: [WorkerAssemblyService,WorkerOrderTrackingService]
})

export class ProductionOrderComponent implements OnInit {

    constructor(private assemblyService: WorkerAssemblyService, 
                private productionOrderService: WorkerOrderTrackingService,
                private loader: LoaderService, 
                private notification: ToastrService,
                private router: Router,
                private translate:TranslateService) {
        this.assignedOrderData = new LocalDataSource ();
        this.unassignedOrderData = new LocalDataSource ();
    }

    public  selectedTab: String = 'WORKER_PRODUCTION_ORDER.ASSIGNED_PRODUCTION_ORDER_TAB';
    private assignedOrderType: ProductionOrderType = ProductionOrderType.Assigned;
    private productionOrderType = ProductionOrderType;
    public  productionOrderSettings: ProductionOrderConfig = new ProductionOrderConfig(this.translate);    
    private isProductionPossible : string ;  
    public  assignedOrderData: LocalDataSource;    
    public  unassignedOrderData: LocalDataSource;    

    private selectedProdOrder: any;  
   
    ngOnInit() {       
       this.translate.onLangChange.subscribe((event: TranslationChangeEvent) => {
            this.doTranslate();
       });
       this.getOrders(this.assignedOrderType);
    }

    doTranslate() {   
        this.productionOrderSettings.updateSettings();
        this.assignedOrderData.refresh();
        this.unassignedOrderData.refresh();
    }

    private bindData(res:any) {      
        this.assignedOrderData.empty();
        if (res != null && res.length > 0) {
            this.selectedProdOrder = res[0];
            res.forEach(element => {
                if (element.productionOrderEndDate != null && element.productionOrderEndDate != "") {
                    element.productionOrderEndDateStr = new Date(element.productionOrderEndDate).toLocaleString();
                }
                if (element.productionOrderStartDate != null && element.productionOrderStartDate != "") {
                    element.productionOrderStartDateStr = new Date(element.productionOrderStartDate).toLocaleString();
                } 
                this.assignedOrderData.append(element);
            });
        }       
    }

     //get the table data for product types
    public getOrders(orderType : ProductionOrderType): void { 
        console.log("orderType",orderType);

        //call the manual order service to get the data
        if (orderType == ProductionOrderType.Assigned) {
            this.productionOrderService.getAssignedProductionOrders().then(res => {                
                console.log("response",res);               
            
                this.bindData(res);
            }).catch(err => { console.log("Error: ", err); });         
        } else {
            this.productionOrderService.getUnAssignedProductionOrders().then(res => {                
                console.log("response",res);               
            
                this.unassignedOrderData.load(res);
                if (res.length > 0) {
                    this.selectedProdOrder = res[0];
                }               
            }).catch(err => { console.log("Error: ", err); });         
        }   
    };

    public selectProductionOrder(event: any): void {
        if (event.isSelected) {
            console.log("data>>", event);
            this.selectedProdOrder = event.data;  
        } else {
            this.selectedProdOrder = null;
        }              
    };

    public startAssemblyPlan () {
        console.log("selected order: ", this.selectedProdOrder);
        if ( this.selectedProdOrder != null) {
           
            this.productionOrderService.getIsProductionPossible(this.selectedProdOrder.productTypeNumber).then(res=> {
                    console.log("response", res);
                    this.isProductionPossible = res;
                    
                    if ( this.isProductionPossible == "YES") {
                        let step :number = 0;
                        if (this.selectedProdOrder.stepInProgress == "") {
                            this.selectedProdOrder.stepInProgress = "0";
                        } else {
                            step = parseInt(this.selectedProdOrder.stepInProgress);
                        }

                       
                        // if ok, then call start assembly process
                        if (this.selectedProdOrder.productId == 0) {
                            this.assemblyService.startAssemblyProcess(this.selectedProdOrder).then (res => {
                                let stepAmt = res.size;

                                // navigate to assemply instruction
                                this.router.navigate(['/worker/assembly-assist/' + stepAmt + '/' + this.selectedProdOrder.quantity],
                                { queryParams: 
                                    { 
                                        currentStep:  step + 1,
                                        completedQty: this.selectedProdOrder.quantityCompleted + 1 ,
                                        activeAssistId:  this.selectedProdOrder.activeAssistId                               
                                    }
                                });
                            }).catch(err => {
                                console.log("Error: ", err); 
                            }); 
                        } else {
                            this.assemblyService.continueAssemblyProcess(this.selectedProdOrder).then (res => {
                                let stepAmt = res.size;

                                // navigate to assemply instruction
                                this.router.navigate(['/worker/assembly-assist/' + stepAmt + '/' + this.selectedProdOrder.quantity],
                                { queryParams: 
                                    { 
                                        currentStep:  step + 1,
                                        completedQty: this.selectedProdOrder.quantityCompleted + 1,
                                        activeAssistId:  this.selectedProdOrder.activeAssistId                                        
                                    }
                                });
                            }).catch(err => {
                                console.log("Error: ", err); 
                            }); 
                        }
                    }
                }
            ).catch(err => {
                console.log("Error: ", err); 
            });                
        }       
    }


    public cancel() {
        this.router.navigate(['/worker/order-type-selection']);
    }

     //for error handling
    public handleError(error: any): Promise<any> {
        console.error('An error occurred', error);
        this.notification.error("Missing materials/devices");        
        this.loader.loader.emit(false);
        return Promise.reject(error.message || error);
    }

}

export enum ProductionOrderType {
  Unassigned = 0,
  Assigned = 1
}