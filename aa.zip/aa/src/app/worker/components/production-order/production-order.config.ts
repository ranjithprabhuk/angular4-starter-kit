import { TranslateService,TranslationChangeEvent } from '@ngx-translate/core';

export class ProductionOrderConfig {
  
    constructor(private translate:TranslateService) {

    }

     //pagination  settings
    public paginationSettings: Object = {
        display: false,
        perPage: 10
    };

    //table configuration for manual order
    public productionOrderSettings: Object = {
        actions: {
            columnTitle: '',
            add: false,
            edit: false,
            delete: false,
            copy: false,
            move: false,
            position: 'left', // left|right
        },  
        columns: {           
            customOrderNumber: {
                title: this.translate.instant("WORKER_PRODUCTION_ORDER.CUSTOMER_ORDER_NUMBER"),
                filter: true
            },                    
            productionOrderNumber: {
                title: this.translate.instant("WORKER_PRODUCTION_ORDER.PRODUCTION_ORDER_NUMBER"),
                filter: true
            },          
            productTypeNumber: {
                title: this.translate.instant("WORKER_PRODUCTION_ORDER.PRODUCT_TYPE_NUMBER"),
                filter: true
            }, 
            quantity: {
                title: this.translate.instant("WORKER_PRODUCTION_ORDER.QUANTITY"),
                filter: true
            },           
            status: {
                title: this.translate.instant("WORKER_PRODUCTION_ORDER.ORDER_STATUS"),
                filter: true
            },
            productionOrderStartDateStr: {
                title: this.translate.instant("WORKER_PRODUCTION_ORDER.ACTUAL_START_DATE"),
                filter: true                
            },
            productionOrderEndDateStr: {
                title: this.translate.instant("WORKER_PRODUCTION_ORDER.ACTUAL_END_DATE"),
                filter: true               
            }
        },
        pager: this.paginationSettings,
        serverSidePagination: {
            itemsPerPage: 10,
            page: 1,
            totalItems: 0
        }
    }

     public updateSettings() {   
        this.productionOrderSettings = {
            actions: {
                columnTitle: '',
                add: false,
                edit: false,
                delete: false,
                copy: false,
                move: false,
                position: 'left', // left|right
            },  
            columns: {           
                customOrderNumber: {
                    title: this.translate.instant("WORKER_PRODUCTION_ORDER.CUSTOMER_ORDER_NUMBER"),
                    filter: true
                },                    
                productionOrderNumber: {
                    title: this.translate.instant("WORKER_PRODUCTION_ORDER.PRODUCTION_ORDER_NUMBER"),
                    filter: true
                },          
                productTypeNumber: {
                    title: this.translate.instant("WORKER_PRODUCTION_ORDER.PRODUCT_TYPE_NUMBER"),
                    filter: true
                }, 
                quantity: {
                    title: this.translate.instant("WORKER_PRODUCTION_ORDER.QUANTITY"),
                    filter: true
                },           
                status: {
                    title: this.translate.instant("WORKER_PRODUCTION_ORDER.ORDER_STATUS"),
                    filter: true
                },
                productionOrderStartDateStr: {
                    title: this.translate.instant("WORKER_PRODUCTION_ORDER.ACTUAL_START_DATE"),
                    filter: true                
                },
                productionOrderEndDateStr: {
                    title: this.translate.instant("WORKER_PRODUCTION_ORDER.ACTUAL_END_DATE"),
                    filter: true               
                }
            },
            pager: this.paginationSettings,
            serverSidePagination: {
                itemsPerPage: 10,
                page: 1,
                totalItems: 0
            }
        };
    }
}