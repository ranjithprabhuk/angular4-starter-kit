import { Injectable } from '@angular/core';
import { ApiService } from '../app.service';
import { WorkerBaseService } from './worker-base.service';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/delay';

@Injectable()
export class WorkerAssemblyService {
    protected apiEndPoint: string = "AssemblyService.svc/";    

    constructor(protected apiService: WorkerBaseService) { 
         console.log("WorkerAssemblyService");
    }  
   
    getCachedOrder() : any {
        return JSON.parse(localStorage.getItem('cachedOrder'));
    }

    startAssemblyProcess(param: any) : Promise<any> {        
        localStorage.setItem('cachedOrder', JSON.stringify(param) );
        return this.apiService.doPost(this.apiEndPoint + "StartOrder", param)
            .then(res => { return Promise.resolve(res)})
            .catch(err => { return Promise.reject(err)});
    }

    continueAssemblyProcess(param: any) : Promise<any> {        
        localStorage.setItem('cachedOrder', JSON.stringify(param) );
        return this.apiService.doPost(this.apiEndPoint + "continueAssembly", param)
            .then(res => { return Promise.resolve(res)})
            .catch(err => { return Promise.reject(err)});
    }

    cancelAssemblyProcess(param: any) : Promise<any> {
        return this.apiService.doPost(this.apiEndPoint + "cancelAssembly", param)
            .then(res => { return Promise.resolve(res)})
            .catch(err => { return Promise.reject(err)});
    }

    stopAssemblyProcess(param: any) {
        localStorage.removeItem('cachedOrder');
        return this.apiService.doPost(this.apiEndPoint + "stopAssembly", param)
            .then(res => { return Promise.resolve(res)})
            .catch(err => { return Promise.reject(err)});       
    }

    setConfirmation() {
        localStorage.removeItem('cachedOrder');
        return this.apiService.doGet(this.apiEndPoint + "SetConfirmation")
            .then(res => { return Promise.resolve(res)})
            .catch(err => { return Promise.reject(err)});       
    }

    shutDown(): Promise<any> {  
        return this.apiService.doGet(this.apiEndPoint+"ShutDown")
            .then(res => { return Promise.resolve(res)})
            .catch(err => { return Promise.reject(err)});
    } 

    confirmStep(): Promise<any> {  
        return this.apiService.doGet(this.apiEndPoint+"ConfirmAction")
            .then(res => { return Promise.resolve(res)})
            .catch(err => { return Promise.reject(err)});
    } 

    getNextStep(): Promise<any> {  
        return this.apiService.doGet(this.apiEndPoint+"NextStep" )
            .then(res => { return Promise.resolve(res)})
            .catch(err => { return Promise.reject(err)});
    } 

    getPreviousStep(): Promise<any> {  
        return this.apiService.doGet(this.apiEndPoint+"PreviousStep" )
            .then(res => { return Promise.resolve(res)})
            .catch(err => { return Promise.reject(err)});
    } 

    repeatStep(): Promise<any> {  
        return this.apiService.doGet(this.apiEndPoint+"RepeatStep" )
            .then(res => { return Promise.resolve(res)})
            .catch(err => { return Promise.reject(err)});
    } 

    goToStep(step: number): Promise<any> {  
        return this.apiService.doGet(this.apiEndPoint+"goToStep/" + step )
            .then(res => { return Promise.resolve(res)})
            .catch(err => { return Promise.reject(err)});
    } 

    getDataByModuleName(moduleName : string): Promise<any> {  
        return this.apiService.doGet(this.apiEndPoint + moduleName)
            .then(res => { return Promise.resolve(res)})
            .catch(err => { return Promise.reject(err)});
    } 

    getApiEndpoint() : string {
        return this.apiEndPoint;
    }

    getApplicationProperties(): Promise<any> {         
        return this.apiService.getApplicationProperties();
    } 
}