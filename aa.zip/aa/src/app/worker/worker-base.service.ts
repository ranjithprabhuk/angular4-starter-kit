import { Injectable,OnInit } from '@angular/core';
import { Headers, Http, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Observable';

import { ToastrService } from 'ngx-toastr';

import {ApiService} from '../app.service';
import { LoaderService } from '../shared/loader';
import 'rxjs/add/operator/toPromise';
import { environment } from '../../environments/environment';

@Injectable()

export class WorkerBaseService extends ApiService implements OnInit {    
    protected hostName: string = 'activeAssistService';

    protected static applicationProperties : any;
   
    constructor(protected http: Http, public loader: LoaderService, public notification: ToastrService) { 
      super(http,loader,notification);
      console.log("WorkerBaseService");     
    }

    ngOnInit() {

    }

    getHostName(): string {
        return this.hostName;
    }

    getApplicationProperties(): Promise<any> {              
        return super.getExternalApplicationProperties();            
    } 

    doGet(module: string, parameter?: URLSearchParams): Promise<any> {   
         return super.get(this.getHostName(),  module,parameter);
    }

    doPost(module: string, parameter: any): Promise<any> {
        return super.create(this.getHostName(), module,parameter);
    }

    //for successfull API response
    protected handleSuccess(response: any): Promise<any> {
        console.log(response);
        if (response.status === 200) {

            //convert the response body as JSON
            let res = response.json();

            if (res.status === "SUCCESS") {
                console.log(res);               
                this.enableLoader = false;
                this.loader.loader.emit(false);
                return Promise.resolve(res.data);
            }
            else {
                this.enableLoader = false;
                this.notification.error(res.message);
                this.loader.loader.emit(false);
                return Promise.reject(res);
            }
        }else{
            this.notification.error("Backend API is not Available");
        }

    }
}
