import { Injectable,OnInit } from '@angular/core';
import {StompConfig,StompService} from '@stomp/ng2-stompjs';
import * as Stomp from '@stomp/stompjs';

@Injectable()
export class WorkerStompService extends StompService {   

    constructor(protected config: StompConfig) { 
           super(config);
    }   


     /** Initialize STOMP Client */
    protected initStompClient(): void {
        // Attempt connection, passing in a callback
        this.client = Stomp.client(this.config.url,[]);

        if (this.client != null) {
            // Configure client heart-beating
            this.client.heartbeat.incoming = this.config.heartbeat_in;
            this.client.heartbeat.outgoing = this.config.heartbeat_out;

            // Auto reconnect
            this.client.reconnect_delay = this.config.reconnect_delay;

            if (!this.config.debug) {
                this.debug = function() {};
            }
            // Set function to debug print messages
            this.client.debug = this.debug;
        }
    }
}
