import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { WorkerAssemblyService } from './worker-assembly.service';
import { WorkerComponent } from './worker.component';

import { OrderTypeSelectionComponent } from './components/order-type-selection/order-type-selection.component';
import { ManualOrderComponent } from './components/manual-order/manual-order.component';
import { ProductionOrderComponent } from './components/production-order/production-order.component';
import { AssemblyAssistComponent } from './components/assembly-assist/assembly-assist.component';

const WorkerRoutes: Routes = [
  {
    path: 'worker',
    component: WorkerComponent,
    data: {
      title: 'worker'
    },
    children: [
      {
        path: '',
        redirectTo: 'order-type-selection',
        pathMatch: 'full',
      },
      {
        path :'order-type-selection',
        component: OrderTypeSelectionComponent,
        data: {
          title: "Order Type Selection"
        },
      },
      {
        path :'manual-order',
        component: ManualOrderComponent,
        data: {
          title: "Manual Order"
        },
      },
      {
        path :'production-order',
        component: ProductionOrderComponent,
        data: {
          title: "Production Order"
        },
      },
      {
        path :'assembly-assist/:steps/:quantity',
        component: AssemblyAssistComponent,
        data: {
          title: "Assembly Assist"
        },
      }

    ]
  },
];

@NgModule({
  imports: [
    RouterModule.forChild(WorkerRoutes)
  ],
  exports: [
    RouterModule
  ],
  providers: [WorkerAssemblyService]
})
export class WorkerRoutingModule { }
