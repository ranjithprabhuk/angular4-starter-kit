import { Component,ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService,TranslationChangeEvent } from '@ngx-translate/core';
import {StompConfig} from '@stomp/ng2-stompjs';
import {Message} from '@stomp/stompjs';
import { Subscription } from 'rxjs/Subscription';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../environments/environment';

import { stompConfig } from './worker.config';
import { AppConfig } from '../app.config';
import { WorkerAssemblyService } from './worker-assembly.service';
import { WorkerStompService } from './worker-stomp.service';
import { LoaderService } from '../shared/loader';
import { ToastrService } from 'ngx-toastr';


@Component({
  templateUrl: 'worker.component.html',
  styleUrls: ['./worker.component.css'],
  providers: [
        WorkerAssemblyService
  ]
})
export class WorkerComponent {
  private _stompService: WorkerStompService;

  // Stream of messages
  private subscription: Subscription;
  public messages: Observable<Message>;

  // Subscription status
  public subscribed: boolean; 
  
  public appConfig = new AppConfig();
  public selectedLanguage : String = this.appConfig.languageName;
  public selectedLanguageCode : String = this.appConfig.languageCode;

  constructor(private translate: TranslateService,
              private assemblyService: WorkerAssemblyService,
              private loader: LoaderService, 
              private notification: ToastrService,
              private router:Router) {
    translate.addLangs(["en", "de"]);
    translate.setDefaultLang(this.appConfig.languageCode);

    let browserLang = translate.getBrowserLang();
    translate.use(browserLang.match(/en|de/) ? browserLang : this.appConfig.languageCode);
  }

  public languagesList : Array<Object> = [];

  public disabled: boolean = false;
  public status: { isopen: boolean } = { isopen: false };
  private deviceErrorCount:number = 7;
  private deviceStatusList : Array<string> = ["Device 1: Running","Device 2: ERROR"];

  ngOnInit() {
    this.doTranslate();
    this.translate.onLangChange.subscribe((event: TranslationChangeEvent) => {
            this.doTranslate();
    });
    // Load port and host from application properties here
    this.assemblyService.getApplicationProperties().then(res => {                
                console.log("response",res);             
                stompConfig.url = res.stompServerUrl;
                console.log("stompConfig",stompConfig);
                this._stompService = new WorkerStompService(stompConfig);
                this.subscribed = false;            
                this.subscribe();
    }).catch(err => { console.log("Error: ", err); });   
  }

  public onLanguageToggled(open: boolean): void {
    console.log('Dropdown is now: ', open);
    this.doTranslate();
  }

  public toggleDropdown($event: MouseEvent): void {
    $event.preventDefault();
    $event.stopPropagation();
    this.status.isopen = !this.status.isopen;
  }

  doTranslate() {
    this.languagesList = [];
    this.languagesList.push({"key": "en","name":this.translate.instant("LANGUAGES.ENGLISH")}); 
    this.languagesList.push({"key": "de","name":this.translate.instant("LANGUAGES.GERMAN")}); 
    this.selectedLanguage = this.getSelectedLanguage(this.selectedLanguageCode);    
  }

  getSelectedLanguage(key) : string {
   for(let i = 0 ; i< this.languagesList.length;i++) {
     let language: any = this.languagesList[i];
     if (language.key == key) {
        return language.name;
     }
   }
  }

  //to logou from the system
  public logout(): void {
        localStorage.removeItem('auth_token');
        this.router.navigate(['/login']);
  }

  public subscribe() {
    if (this.subscribed) {
      return;
    }

    // Stream of messages
    this.messages = this._stompService.subscribe('/Stomp/ModuleStatus');

    // Subscribe a function to be run on_next message
    this.subscription = this.messages.subscribe(this.on_next);

    this.subscribed = true;
  }

  public unsubscribe() {
    console.log("calling unsubscribe");
    if (!this.subscribed) {
      return;
    }

    // This will internally unsubscribe from Stomp Broker
    // There are two subscriptions - one created explicitly, the other created in the template by use of 'async'
    this.subscription.unsubscribe();
    this.subscription = null;
    this.messages = null;

    this.subscribed = false;    
  }

  ngOnDestroy() {
    this.unsubscribe();
    this._stompService.disconnect();
  }

  /** Consume a message from the _stompService */
  public on_next = (message: Message) => {
    // Log it to the console
    console.log("Received message from server: ", message);
    let data: string = message.body;
    //this.deviceStatusList = data.split(",");
    this.deviceErrorCount = this.countErrorDevices(data.split(","));   
  }

  public togleDeviceStatus(open: boolean): void {
    console.log('Dropdown is now: ', open);
  }
    
  countErrorDevices(data) {
      let count: number = 0;
      this.deviceStatusList = [];
      data.forEach(element => {
          let deviceStatus = element.split(":");
          if (deviceStatus[1].trim().toUpperCase() == "ERROR") {
            this.deviceStatusList.push(element);
            count ++ ;
          }
      });

      return count;
  }
}
