import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';

import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '../shared/shared.module';
import { TabsModule,ModalModule, PaginationModule } from 'ng2-bootstrap';
import { Ng2SmartTableModule } from '../table';

import { WorkerComponent } from './worker.component';
import { WorkerRoutingModule } from './worker-routing.module';
import { WorkerAssemblyService } from './worker-assembly.service';
import { WorkerBaseService } from './worker-base.service';
import { UserProfileService } from './worker-userprofile.service';

//Components
import { OrderTypeSelectionComponent } from './components/order-type-selection/order-type-selection.component';
import { ManualOrderComponent } from './components/manual-order/manual-order.component';
import { ProductionOrderComponent } from './components/production-order/production-order.component';
import { AssemblyAssistComponent } from './components/assembly-assist/assembly-assist.component';

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    WorkerRoutingModule,
    TranslateModule,    
    RouterModule,
    Ng2SmartTableModule,
    ModalModule.forRoot(),
    TabsModule.forRoot(),
    PaginationModule.forRoot(),
    SharedModule
  ],
  exports: [ RouterModule ],
  providers: [WorkerBaseService,UserProfileService,WorkerAssemblyService],
  declarations: [ WorkerComponent,OrderTypeSelectionComponent,ManualOrderComponent,ProductionOrderComponent,AssemblyAssistComponent ]
})
export class WorkerModule { }