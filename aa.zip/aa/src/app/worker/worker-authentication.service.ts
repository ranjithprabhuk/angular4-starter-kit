import { Injectable } from '@angular/core';
import { ApiService } from '../app.service';
import { WorkerBaseService } from './worker-base.service';
import { UserProfileService } from './worker-userprofile.service';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/delay';

@Injectable()
export class WorkerAuthenticationService {
    //protected apiEndPoint: string = "/";

    protected hostName = "userManagementService";

    constructor(protected apiService: UserProfileService) {         
         console.log("WorkerAuthenticationService");
    }

    
    authenticateUser(parameter?: any): Promise<any> {        
        return this.apiService.doPost("authenticateUserAndFetchPermissionMatrix", parameter).
        then(res => {
                if (res.loginResult == "LOGIN_SUCCESS") {                   
                        return Promise.resolve(res);                   
                } else {                  
                    return Promise.reject(res);
                }
            })
            .catch(err => { return Promise.reject(err) });     
    }

    getUserProfile(id:number): Promise<any> {       
        return this.apiService.doGet("getUserProfile?id=" + id)
            .then(res => { return Promise.resolve(res)})
            .catch(err => { return Promise.reject(err)});
    }   
}